# -*- coding: utf-8 -*-
import clr
clr.AddReference("System")
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

import traceback

from Autodesk.Revit.DB import (
    FilteredElementCollector, BuiltInCategory, BuiltInParameter,
    FamilyInstance, LocationCurve, Options, ViewDetailLevel,
    Solid, GeometryInstance, XYZ, ElementId
)
from Autodesk.Revit.UI import IExternalEventHandler
from System.Collections.Generic import List

from pyrevit import script
import storage
import exporter

logger = script.get_logger()


def eid_to_int(eid):
    if eid is None:
        return -1
    for attr in ("IntegerValue", "Value"):
        try:
            return int(getattr(eid, attr))
        except:
            pass
    try:
        return int(eid.ToString())
    except:
        pass
    try:
        s = str(eid)
        digits = "".join(ch for ch in s if ch in "0123456789-")
        if digits:
            return int(digits)
    except:
        pass
    return -1


def make_element_id(value):
    try:
        return ElementId(int(value))
    except:
        try:
            from System import Int64
            return ElementId(Int64(int(value)))
        except:
            return None


def find_element_by_int_id(doc, target_id):
    try:
        target_id = int(target_id)
    except:
        return None

    try:
        els = (FilteredElementCollector(doc)
               .OfCategory(BuiltInCategory.OST_StructuralFraming)
               .WhereElementIsNotElementType()
               .ToElements())
        for el in els:
            try:
                if eid_to_int(el.Id) == target_id:
                    return el
            except:
                pass
    except:
        pass

    return None


def get_mark(el):
    try:
        p = el.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)
        if p:
            s = p.AsString() or p.AsValueString()
            if s:
                return s
    except:
        pass
    try:
        p = el.LookupParameter("Mark")
        if p:
            s = p.AsString() or p.AsValueString()
            if s:
                return s
    except:
        pass
    return ""


def get_family(el, doc):
    try:
        if el.Symbol and el.Symbol.Family:
            return el.Symbol.Family.Name or ""
    except:
        pass
    try:
        t = doc.GetElement(el.GetTypeId())
        return getattr(t, "FamilyName", "") or ""
    except:
        pass
    return ""


def get_type_name(el):
    try:
        if el.Symbol:
            return el.Symbol.Name or ""
    except:
        pass
    try:
        return el.Name or ""
    except:
        pass
    return ""


def get_length_mm(el):
    try:
        loc = el.Location
        if isinstance(loc, LocationCurve) and loc.Curve:
            return round(loc.Curve.Length * 304.8, 1)
    except:
        pass
    return ""


class BeamRow(object):
    def __init__(self, el, doc, origins):
        self.ElementId = eid_to_int(el.Id)
        self.Mark = get_mark(el)
        self.Family = get_family(el, doc)
        self.TypeName = get_type_name(el)
        self.LengthMM = get_length_mm(el)
        self.OriginStatus = "Set" if str(self.ElementId) in origins else "Not set"


def collect_beams(doc, origins):
    rows = []
    try:
        els = (FilteredElementCollector(doc)
               .OfCategory(BuiltInCategory.OST_StructuralFraming)
               .WhereElementIsNotElementType()
               .ToElements())
    except:
        els = []

    for el in els:
        try:
            if not isinstance(el, FamilyInstance):
                continue
            rows.append(BeamRow(el, doc, origins))
        except:
            pass

    rows.sort(key=lambda r: (str(r.Family), str(r.TypeName), str(r.ElementId)))
    return rows


def _add_vertex(xyz, verts, vmap):
    key = (round(float(xyz.X), 6), round(float(xyz.Y), 6), round(float(xyz.Z), 6))
    idx = vmap.get(key)
    if idx is None:
        idx = len(verts)
        verts.append([key[0], key[1], key[2]])
        vmap[key] = idx
    return idx


def _process_solid(solid, verts, tris, vmap):
    if solid is None:
        return
    try:
        if solid.Faces.IsEmpty:
            return
    except:
        pass

    try:
        for face in solid.Faces:
            mesh = face.Triangulate()
            for i in range(mesh.NumTriangles):
                tri = mesh.get_Triangle(i)
                i1 = _add_vertex(tri.get_Vertex(0), verts, vmap)
                i2 = _add_vertex(tri.get_Vertex(1), verts, vmap)
                i3 = _add_vertex(tri.get_Vertex(2), verts, vmap)
                tris.append([i1, i2, i3])
    except:
        pass


def build_preview_payload(el):
    opts = Options()
    opts.DetailLevel = ViewDetailLevel.Fine
    try:
        opts.IncludeNonVisibleObjects = True
    except:
        pass

    verts = []
    tris = []
    vmap = {}

    geom = el.get_Geometry(opts)
    if geom is None:
        return None

    for obj in geom:
        if isinstance(obj, Solid):
            _process_solid(obj, verts, tris, vmap)
        elif isinstance(obj, GeometryInstance):
            try:
                inst_geom = obj.GetInstanceGeometry()
                for inst_obj in inst_geom:
                    if isinstance(inst_obj, Solid):
                        _process_solid(inst_obj, verts, tris, vmap)
            except:
                pass

    if not verts or not tris:
        return None

    xs = [v[0] for v in verts]
    ys = [v[1] for v in verts]
    zs = [v[2] for v in verts]
    center = [
        (min(xs) + max(xs)) / 2.0,
        (min(ys) + max(ys)) / 2.0,
        (min(zs) + max(zs)) / 2.0
    ]
    dx = max(xs) - min(xs)
    dy = max(ys) - min(ys)
    dz = max(zs) - min(zs)
    radius = max(dx, dy, dz) / 2.0
    if radius <= 0.0001:
        radius = 1.0

    return {
        "vertices": verts,
        "triangles": tris,
        "center": center,
        "radius": radius
    }


class BeamExternalEventHandler(IExternalEventHandler):
    def __init__(self, ui):
        self.ui = ui
        self.request = None
        self.selected_id = None
        self.direct_origin = None

    def Execute(self, app):
        doc = app.ActiveUIDocument.Document

        try:
            if self.request == "refresh":
                self.ui.ui_after_refresh()
                return

            # IMPORTANT:
            # Export all must work even when no element is selected.
            # Therefore export is handled before the selected_id check.
            if self.request == "export":
                outdir, count = exporter.export_all_marked(doc)
                self.ui.ui_after_export("{} element(en) geëxporteerd naar {}.".format(count, outdir))
                return

            if self.selected_id is None:
                self.ui.ui_after_preview(None, "Geen balk geselecteerd.")
                return

            el = find_element_by_int_id(doc, self.selected_id)
            if el is None:
                self.ui.ui_after_preview(None, "Element niet gevonden.")
                return

            if self.request == "show_in_revit":
                try:
                    uidoc = app.ActiveUIDocument
                    elid = make_element_id(self.selected_id)
                    if elid:
                        ids = List[ElementId]()
                        ids.Add(elid)
                        uidoc.Selection.SetElementIds(ids)
                        uidoc.ShowElements(elid)
                        try:
                            self.ui.ui_after_show_in_revit("Element geselecteerd en getoond in Revit.")
                        except:
                            self.ui.set_status("Element geselecteerd en getoond in Revit.")
                    else:
                        self.ui.set_status("ElementId kon niet gemaakt worden.")
                except Exception as ex:
                    self.ui.set_status("Show in Revit mislukt: {}".format(ex))
                return

            if self.request == "preview":
                payload = build_preview_payload(el)
                self.ui.ui_after_preview(payload, "3D preview geladen." if payload else "Geen preview geometrie gevonden.")
                return

            if self.request == "save_direct_origin":
                if self.direct_origin and len(self.direct_origin) == 3:
                    p = XYZ(float(self.direct_origin[0]), float(self.direct_origin[1]), float(self.direct_origin[2]))
                    storage.save_origin(doc, self.selected_id, p)
                    self.ui.ui_after_pick_origin("Origin opgeslagen in plugin-preview.")
                elif self.direct_origin and len(self.direct_origin) >= 4:
                    p = XYZ(float(self.direct_origin[0]), float(self.direct_origin[1]), float(self.direct_origin[2]))
                    xy_rotation = int(self.direct_origin[4]) if len(self.direct_origin) >= 5 else 0
                    storage.save_origin(doc, self.selected_id, p, int(self.direct_origin[3]), xy_rotation)
                    self.ui.ui_after_pick_origin("Origin en CNC assen opgeslagen in plugin-preview.")
                else:
                    self.ui.ui_after_pick_origin("Origin opslaan mislukt.")
                return

            if self.request == "save_axes":
                storage.save_origin_axes(doc, self.selected_id, int(self.direct_origin or 0))
                self.ui.ui_after_pick_origin("CNC assen opgeslagen.")
                return

            if self.request == "save_xy_swap":
                storage.save_origin_xy_swap(doc, self.selected_id, bool(int(self.direct_origin or 0)))
                self.ui.ui_after_pick_origin("CNC X/Y instelling opgeslagen.")
                return

            if self.request == "save_xy_rotation":
                storage.save_origin_xy_rotation(doc, self.selected_id, int(self.direct_origin or 0))
                self.ui.ui_after_pick_origin("CNC X/Y rotatie opgeslagen.")
                return

            if self.request == "clear_origin":
                storage.clear_origin(doc, self.selected_id)
                if storage.has_origin(doc, self.selected_id):
                    self.ui.ui_after_clear_origin("Origin verwijderen mislukt.", self.selected_id, False)
                else:
                    self.ui.ui_after_clear_origin("Origin verwijderd.", self.selected_id, True)
                return

        except Exception as ex:
            logger.error(traceback.format_exc())
            try:
                self.ui.set_status("Fout: {}".format(ex))
            except:
                pass

    def GetName(self):
        return "Beam CNC External Event Handler"
