# -*- coding: utf-8 -*-
from __future__ import division

import json

import clr
clr.AddReference("System")
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")

from pyrevit import forms, script
from System.Drawing import Color, Font, FontStyle, Point, Size
from System.Windows.Forms import (
    Form, Label, TextBox, Button, DataGridView, DataGridViewSelectionMode,
    DataGridViewAutoSizeColumnsMode, FormStartPosition, FormBorderStyle,
    AnchorStyles, MessageBox, MessageBoxButtons, MessageBoxIcon, OpenFileDialog,
    SaveFileDialog, DialogResult
)


CNC_SETTINGS_SECTION = "PrefabAnalyserCNC"
PROJECT_SETTINGS_ATTR = "project_settings_json"

DEFAULT_TOOLS = [{
    "number": 1,
    "name": "Default end mill",
    "diameter": 10.0,
    "spindle": 12000.0,
    "feed_cut": 800.0,
    "feed_plunge": 250.0,
    "feed_travel": 3000.0,
    "safe_z": 50.0,
    "retract_z": 5.0
}]


def fval(value, default_value):
    try:
        return float(str(value).replace(",", "."))
    except:
        return float(default_value)


def ival(value, default_value):
    try:
        return int(float(str(value).replace(",", ".")))
    except:
        return int(default_value)


def _tool_number(tool):
    return ival(tool.get("number", 0), 0)


def _normalize_tool(tool):
    return {
        "number": ival(tool.get("number", 1), 1),
        "name": str(tool.get("name", "Tool")),
        "diameter": fval(tool.get("diameter", 10.0), 10.0),
        "spindle": fval(tool.get("spindle", 12000.0), 12000.0),
        "feed_cut": fval(tool.get("feed_cut", 800.0), 800.0),
        "feed_plunge": fval(tool.get("feed_plunge", 250.0), 250.0),
        "feed_travel": fval(tool.get("feed_travel", 3000.0), 3000.0),
        "safe_z": fval(tool.get("safe_z", 50.0), 50.0),
        "retract_z": fval(tool.get("retract_z", 5.0), 5.0)
    }


def get_project_key(doc):
    if doc is None:
        return "__no_project__"

    try:
        path = str(doc.PathName or "").strip()
        if path:
            return "path:" + path.lower()
    except:
        pass

    try:
        pi = doc.ProjectInformation
        uid = str(pi.UniqueId or "").strip()
        if uid:
            return "projectinfo:" + uid
    except:
        pass

    try:
        title = str(doc.Title or "").strip()
        if title:
            return "title:" + title
    except:
        pass

    return "__unknown_project__"


def _default_settings():
    return {
        "active_tool": 1,
        "tools": [_normalize_tool(t) for t in DEFAULT_TOOLS]
    }


def _load_project_settings_map():
    try:
        cfg = script.get_config(CNC_SETTINGS_SECTION)
        raw = getattr(cfg, PROJECT_SETTINGS_ATTR)
        data = json.loads(raw)
        if isinstance(data, dict):
            return data
    except:
        pass
    return {}


def _save_project_settings_map(data):
    cfg = script.get_config(CNC_SETTINGS_SECTION)
    setattr(cfg, PROJECT_SETTINGS_ATTR, json.dumps(data, indent=2, sort_keys=True))
    script.save_config()


def _load_project_settings(doc):
    key = get_project_key(doc)
    all_settings = _load_project_settings_map()
    settings = all_settings.get(key)

    if isinstance(settings, dict):
        tools = settings.get("tools")
        if isinstance(tools, list) and tools:
            return {
                "active_tool": ival(settings.get("active_tool"), 1),
                "tools": [_normalize_tool(t) for t in tools]
            }

    return _default_settings()


def _save_project_settings(doc, settings):
    key = get_project_key(doc)
    all_settings = _load_project_settings_map()
    all_settings[key] = {
        "active_tool": ival(settings.get("active_tool"), 1),
        "tools": [_normalize_tool(t) for t in settings.get("tools", [])]
    }
    _save_project_settings_map(all_settings)


def load_tools(doc=None):
    settings = _load_project_settings(doc)
    return settings["tools"]


def active_tool(doc=None):
    settings = _load_project_settings(doc)
    return ival(settings["active_tool"], 1)


def save_tools(tools, active=None, doc=None):
    cleaned = [_normalize_tool(t) for t in tools]
    cleaned.sort(key=_tool_number)

    if not cleaned:
        cleaned = [_normalize_tool(DEFAULT_TOOLS[0])]

    active_nr = ival(active if active is not None else active_tool(doc), 1)
    valid_numbers = [_tool_number(t) for t in cleaned]
    if active_nr not in valid_numbers:
        active_nr = valid_numbers[0]

    _save_project_settings(doc, {
        "active_tool": active_nr,
        "tools": cleaned
    })


def fmt_tool(tool):
    return "T{} | {} | Dia {}mm | S{} | Fcut {} | Fplunge {} | SafeZ {}".format(
        tool.get("number"),
        tool.get("name"),
        tool.get("diameter"),
        tool.get("spindle"),
        tool.get("feed_cut"),
        tool.get("feed_plunge"),
        tool.get("safe_z")
    )


class ToolSettingsForm(Form):
    def __init__(self, doc=None):
        self.doc = doc
        self.tools = load_tools(self.doc)
        self.active = active_tool(self.doc)
        self.selected_number = None
        self.loading_grid = False

        self.Text = "CNC Tool Settings"
        self.Size = Size(1180, 760)
        self.MinimumSize = Size(900, 620)
        self.StartPosition = FormStartPosition.CenterScreen
        self.FormBorderStyle = FormBorderStyle.Sizable
        self.MaximizeBox = True
        self.MinimizeBox = True
        self.AutoScroll = True
        self.AutoScrollMinSize = Size(1140, 720)
        self.BackColor = Color.FromArgb(245, 245, 245)

        self.font_title = Font("Segoe UI", 16, FontStyle.Bold)
        self.font_section = Font("Segoe UI", 10, FontStyle.Bold)
        self.font_label = Font("Segoe UI", 10, FontStyle.Regular)
        self.font_input = Font("Segoe UI", 10, FontStyle.Regular)

        self.fields = {}
        self._build_ui()
        self.refresh_grid()
        self.select_tool(self.active)

    def make_label(self, text, x, y, w, h, font=None, color=None):
        lbl = Label()
        lbl.Text = text
        lbl.Location = Point(x, y)
        lbl.Size = Size(w, h)
        lbl.Font = font or self.font_label
        if color:
            lbl.ForeColor = color
        self.Controls.Add(lbl)
        return lbl

    def make_field(self, key, label, x, y):
        self.make_label(label, x, y, 180, 28)
        txt = TextBox()
        txt.Font = self.font_input
        txt.Location = Point(x + 190, y - 2)
        txt.Size = Size(250, 28)
        self.Controls.Add(txt)
        self.fields[key] = txt
        return txt

    def make_button(self, text, x, y, w, handler):
        btn = Button()
        btn.Text = text
        btn.Font = self.font_label
        btn.Location = Point(x, y)
        btn.Size = Size(w, 36)
        btn.Click += handler
        self.Controls.Add(btn)
        return btn

    def _build_ui(self):
        self.make_label("CNC tool settings", 28, 24, 500, 34, self.font_title)
        self.active_label = self.make_label("", 28, 58, 760, 26, self.font_label, Color.FromArgb(70, 70, 70))

        self.grid = DataGridView()
        self.grid.Location = Point(28, 96)
        self.grid.Size = Size(640, 500)
        self.grid.ReadOnly = True
        self.grid.AllowUserToAddRows = False
        self.grid.AllowUserToDeleteRows = False
        self.grid.MultiSelect = False
        self.grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        self.grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        self.grid.BackgroundColor = Color.White
        self.grid.RowHeadersVisible = False
        self.grid.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom
        self.grid.Columns.Add("number", "Tool")
        self.grid.Columns.Add("name", "Name")
        self.grid.Columns.Add("diameter", "Dia")
        self.grid.Columns.Add("spindle", "RPM")
        self.grid.Columns.Add("feed_cut", "F cut")
        self.grid.Columns.Add("safe_z", "Safe Z")
        self.grid.SelectionChanged += self.on_grid_selection
        self.Controls.Add(self.grid)

        self.make_label("Selected tool", 710, 96, 360, 28, self.font_section)
        self.make_field("number", "Tool number", 710, 140)
        self.make_field("name", "Tool name", 710, 182)
        self.make_field("diameter", "Tool diameter mm", 710, 224)
        self.make_field("spindle", "Spindle RPM", 710, 266)
        self.make_field("feed_cut", "Cut feed mm/min", 710, 308)
        self.make_field("feed_plunge", "Plunge feed mm/min", 710, 350)
        self.make_field("feed_travel", "Travel feed mm/min", 710, 392)
        self.make_field("safe_z", "Safe Z mm", 710, 434)
        self.make_field("retract_z", "Drill retract R mm", 710, 476)

        self.make_label("Tool actions", 710, 528, 360, 24, self.font_section)
        self.make_button("New tool", 710, 558, 130, self.on_new_tool)
        self.make_button("Save tool", 850, 558, 130, self.on_save_tool)
        self.make_button("Delete tool", 990, 558, 130, self.on_delete_tool)
        self.make_button("Set selected active", 710, 604, 410, self.on_set_active)

        self.make_label("Project settings", 710, 652, 360, 24, self.font_section)
        self.make_button("Export settings", 710, 682, 200, self.on_export_settings)
        self.make_button("Import settings", 920, 682, 200, self.on_import_settings)

        self.status_label = self.make_label(
            "Settings are saved for this Revit project only. New projects start with defaults.",
            28, 660, 640, 32, self.font_label, Color.FromArgb(70, 70, 70)
        )
        self.status_label.Anchor = AnchorStyles.Left | AnchorStyles.Bottom

    def set_status(self, text):
        try:
            self.status_label.Text = text
        except:
            pass

    def _find_tool(self, number):
        nr = ival(number, 0)
        for tool in self.tools:
            if _tool_number(tool) == nr:
                return tool
        return None

    def _next_number(self):
        nums = [_tool_number(t) for t in self.tools]
        if not nums:
            return 1
        return max(nums) + 1

    def refresh_grid(self, select_number=None):
        self.loading_grid = True
        self.grid.Rows.Clear()

        self.tools.sort(key=_tool_number)
        valid_numbers = [_tool_number(t) for t in self.tools]
        if self.active not in valid_numbers and valid_numbers:
            self.active = valid_numbers[0]

        for tool in self.tools:
            idx = self.grid.Rows.Add()
            row = self.grid.Rows[idx]
            nr = _tool_number(tool)
            row.Cells[0].Value = "T{}".format(nr)
            row.Cells[1].Value = tool.get("name", "")
            row.Cells[2].Value = "{}".format(tool.get("diameter", ""))
            row.Cells[3].Value = "{}".format(tool.get("spindle", ""))
            row.Cells[4].Value = "{}".format(tool.get("feed_cut", ""))
            row.Cells[5].Value = "{}".format(tool.get("safe_z", ""))
            row.Tag = nr
            if nr == self.active:
                row.DefaultCellStyle.BackColor = Color.FromArgb(225, 242, 255)

        self.active_label.Text = "Active tool: T{}".format(self.active)
        self.loading_grid = False

        if select_number is not None:
            self.select_tool(select_number)

    def select_tool(self, number):
        nr = ival(number, 0)
        for row in self.grid.Rows:
            try:
                if ival(row.Tag, 0) == nr:
                    row.Selected = True
                    self.grid.CurrentCell = row.Cells[0]
                    self.load_tool(self._find_tool(nr))
                    return
            except:
                pass

        if self.grid.Rows.Count > 0:
            row = self.grid.Rows[0]
            row.Selected = True
            self.grid.CurrentCell = row.Cells[0]
            self.load_tool(self._find_tool(row.Tag))

    def get_selected_number(self):
        try:
            if self.grid.SelectedRows.Count > 0:
                return ival(self.grid.SelectedRows[0].Tag, 0)
        except:
            pass
        return self.selected_number

    def load_tool(self, tool):
        if not tool:
            return
        self.selected_number = _tool_number(tool)
        for key in self.fields:
            self.fields[key].Text = str(tool.get(key, ""))

    def on_grid_selection(self, sender, args):
        if self.loading_grid:
            return
        nr = self.get_selected_number()
        if nr:
            self.load_tool(self._find_tool(nr))

    def _read_text(self, key):
        try:
            return str(self.fields[key].Text).strip()
        except:
            return ""

    def _read_float(self, key, label, allow_zero=True):
        raw = self._read_text(key)
        try:
            value = float(raw.replace(",", "."))
        except:
            MessageBox.Show(label + " must be a valid number.", "CNC Tool Settings",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return None

        if value < 0 or (not allow_zero and value <= 0):
            MessageBox.Show(label + " has an invalid value.", "CNC Tool Settings",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return None
        return value

    def collect_form_tool(self):
        number_raw = self._read_text("number")
        try:
            number = int(float(number_raw.replace(",", ".")))
        except:
            MessageBox.Show("Tool number must be a valid whole number.", "CNC Tool Settings",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return None

        if number <= 0:
            MessageBox.Show("Tool number must be greater than 0.", "CNC Tool Settings",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return None

        name = self._read_text("name") or "Tool"
        diameter = self._read_float("diameter", "Tool diameter", False)
        spindle = self._read_float("spindle", "Spindle RPM")
        feed_cut = self._read_float("feed_cut", "Cut feed")
        feed_plunge = self._read_float("feed_plunge", "Plunge feed")
        feed_travel = self._read_float("feed_travel", "Travel feed")
        safe_z = self._read_float("safe_z", "Safe Z")
        retract_z = self._read_float("retract_z", "Drill retract R")

        values = [diameter, spindle, feed_cut, feed_plunge, feed_travel, safe_z, retract_z]
        if None in values:
            return None

        return {
            "number": number,
            "name": name,
            "diameter": diameter,
            "spindle": spindle,
            "feed_cut": feed_cut,
            "feed_plunge": feed_plunge,
            "feed_travel": feed_travel,
            "safe_z": safe_z,
            "retract_z": retract_z
        }

    def on_new_tool(self, sender, args):
        tool = _normalize_tool(DEFAULT_TOOLS[0])
        tool["number"] = self._next_number()
        tool["name"] = "Tool {}".format(tool["number"])
        self.selected_number = None
        try:
            self.grid.ClearSelection()
        except:
            pass
        self.load_tool(tool)
        self.set_status("New tool ready. Edit values and press Save tool.")

    def on_save_tool(self, sender, args):
        tool = self.collect_form_tool()
        if not tool:
            return

        nr = _tool_number(tool)
        self.tools = [t for t in self.tools if _tool_number(t) != nr]
        self.tools.append(tool)

        if not self.active:
            self.active = nr

        save_tools(self.tools, self.active, self.doc)
        self.refresh_grid(nr)
        self.set_status("Tool T{} saved.".format(nr))

    def on_delete_tool(self, sender, args):
        nr = self.get_selected_number()
        if not nr:
            self.set_status("Select a tool to delete.")
            return

        if len(self.tools) <= 1:
            self.set_status("At least one tool must remain.")
            return

        self.tools = [t for t in self.tools if _tool_number(t) != nr]
        if self.active == nr:
            self.active = _tool_number(self.tools[0])

        save_tools(self.tools, self.active, self.doc)
        self.refresh_grid(self.active)
        self.set_status("Tool T{} deleted.".format(nr))

    def on_set_active(self, sender, args):
        nr = self.get_selected_number()
        if not nr:
            self.set_status("Select a tool to set active.")
            return

        self.active = nr
        save_tools(self.tools, self.active, self.doc)
        self.refresh_grid(nr)
        self.set_status("Tool T{} is now active.".format(nr))

    def on_export_settings(self, sender, args):
        if export_tool_settings(self.doc):
            self.set_status("Tool settings export finished.")

    def on_import_settings(self, sender, args):
        if import_tool_settings(self.doc):
            self.tools = load_tools(self.doc)
            self.active = active_tool(self.doc)
            self.refresh_grid(self.active)
            self.set_status("Tool settings imported for this project.")

def show_tool_settings_dialog(doc=None):
    form = ToolSettingsForm(doc)
    try:
        return form.ShowDialog()
    finally:
        try:
            form.Dispose()
        except:
            pass


def export_tool_settings(doc=None):
    data = {
        "schema": "PrefabAnalyser_CNC_Tool_Settings_v1",
        "active_tool": active_tool(doc),
        "tools": load_tools(doc)
    }

    dlg = SaveFileDialog()
    dlg.Title = "Exporteer CNC tool settings"
    dlg.Filter = "JSON files (*.json)|*.json"
    dlg.FileName = "cnc_tool_settings.json"
    if dlg.ShowDialog() != DialogResult.OK:
        return False

    with open(str(dlg.FileName), "w") as f:
        f.write(json.dumps(data, indent=2, sort_keys=True))
    forms.alert("Tool settings geexporteerd.", title="CNC Tools")
    return True


def import_tool_settings(doc=None):
    dlg = OpenFileDialog()
    dlg.Title = "Importeer CNC tool settings"
    dlg.Filter = "JSON files (*.json)|*.json"
    if dlg.ShowDialog() != DialogResult.OK:
        return False

    with open(str(dlg.FileName), "r") as f:
        data = json.loads(f.read())

    tools = data.get("tools")
    if not isinstance(tools, list) or not tools:
        forms.alert("Ongeldig settingsbestand.", title="CNC Tools")
        return False

    save_tools(tools, ival(data.get("active_tool"), _tool_number(tools[0])), doc)
    forms.alert("Tool settings geimporteerd.", title="CNC Tools")
    return True
