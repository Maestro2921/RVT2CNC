# -*- coding: utf-8 -*-
from __future__ import division

import json

import clr
clr.AddReference("System")
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")

from pyrevit import forms, script
from System.Drawing import Color, Font, FontStyle, Point, Size, ContentAlignment
from System.Windows.Forms import (
    Form, Label, TextBox, Button, DataGridView, DataGridViewSelectionMode,
    DataGridViewAutoSizeColumnsMode, FormStartPosition, FormBorderStyle,
    AnchorStyles, MessageBox, MessageBoxButtons, MessageBoxIcon, OpenFileDialog,
    SaveFileDialog, DialogResult, TableLayoutPanel, FlowLayoutPanel, Panel,
    DockStyle, Padding, SizeType, RowStyle, ColumnStyle, AutoSizeMode,
    DataGridViewColumnSortMode
)


CNC_SETTINGS_SECTION = "PrefabAnalyserCNC"
PROJECT_SETTINGS_ATTR = "project_settings_json"

DEFAULT_TOOLS = [{
    "number": 1,
    "name": "Default end mill",
    "diameter": 10.0,
    "spindle": 12000.0,
    "feed_cut": 800.0,
    "feed_plunge": 250.0,
    "feed_travel": 3000.0,
    "safe_z": 50.0,
    "retract_z": 5.0
}]


def fval(value, default_value):
    try:
        return float(str(value).replace(",", "."))
    except:
        return float(default_value)


def ival(value, default_value):
    try:
        return int(float(str(value).replace(",", ".")))
    except:
        return int(default_value)


def _tool_number(tool):
    return ival(tool.get("number", 0), 0)


def _normalize_tool(tool):
    return {
        "number": ival(tool.get("number", 1), 1),
        "name": str(tool.get("name", "Tool")),
        "diameter": fval(tool.get("diameter", 10.0), 10.0),
        "spindle": fval(tool.get("spindle", 12000.0), 12000.0),
        "feed_cut": fval(tool.get("feed_cut", 800.0), 800.0),
        "feed_plunge": fval(tool.get("feed_plunge", 250.0), 250.0),
        "feed_travel": fval(tool.get("feed_travel", 3000.0), 3000.0),
        "safe_z": fval(tool.get("safe_z", 50.0), 50.0),
        "retract_z": fval(tool.get("retract_z", 5.0), 5.0)
    }


def get_project_key(doc):
    if doc is None:
        return "__no_project__"

    try:
        path = str(doc.PathName or "").strip()
        if path:
            return "path:" + path.lower()
    except:
        pass

    try:
        pi = doc.ProjectInformation
        uid = str(pi.UniqueId or "").strip()
        if uid:
            return "projectinfo:" + uid
    except:
        pass

    try:
        title = str(doc.Title or "").strip()
        if title:
            return "title:" + title
    except:
        pass

    return "__unknown_project__"


def _default_settings():
    return {
        "active_tool": 1,
        "tools": [_normalize_tool(t) for t in DEFAULT_TOOLS]
    }


def _load_project_settings_map():
    try:
        cfg = script.get_config(CNC_SETTINGS_SECTION)
        raw = getattr(cfg, PROJECT_SETTINGS_ATTR)
        data = json.loads(raw)
        if isinstance(data, dict):
            return data
    except:
        pass
    return {}


def _save_project_settings_map(data):
    cfg = script.get_config(CNC_SETTINGS_SECTION)
    setattr(cfg, PROJECT_SETTINGS_ATTR, json.dumps(data, indent=2, sort_keys=True))
    script.save_config()


def _load_project_settings(doc):
    key = get_project_key(doc)
    all_settings = _load_project_settings_map()
    settings = all_settings.get(key)

    if isinstance(settings, dict):
        tools = settings.get("tools")
        if isinstance(tools, list) and tools:
            return {
                "active_tool": ival(settings.get("active_tool"), 1),
                "tools": [_normalize_tool(t) for t in tools]
            }

    return _default_settings()


def _save_project_settings(doc, settings):
    key = get_project_key(doc)
    all_settings = _load_project_settings_map()
    all_settings[key] = {
        "active_tool": ival(settings.get("active_tool"), 1),
        "tools": [_normalize_tool(t) for t in settings.get("tools", [])]
    }
    _save_project_settings_map(all_settings)


def load_tools(doc=None):
    settings = _load_project_settings(doc)
    return settings["tools"]


def active_tool(doc=None):
    settings = _load_project_settings(doc)
    return ival(settings["active_tool"], 1)


def save_tools(tools, active=None, doc=None):
    cleaned = [_normalize_tool(t) for t in tools]
    cleaned.sort(key=_tool_number)

    if not cleaned:
        cleaned = [_normalize_tool(DEFAULT_TOOLS[0])]

    active_nr = ival(active if active is not None else active_tool(doc), 1)
    valid_numbers = [_tool_number(t) for t in cleaned]
    if active_nr not in valid_numbers:
        active_nr = valid_numbers[0]

    _save_project_settings(doc, {
        "active_tool": active_nr,
        "tools": cleaned
    })


def fmt_tool(tool):
    return "T{} | {} | Dia {}mm | S{} | Fcut {} | Fplunge {} | SafeZ {}".format(
        tool.get("number"),
        tool.get("name"),
        tool.get("diameter"),
        tool.get("spindle"),
        tool.get("feed_cut"),
        tool.get("feed_plunge"),
        tool.get("safe_z")
    )


class ToolSettingsForm(Form):
    def __init__(self, doc=None):
        self.doc = doc
        self.tools = load_tools(self.doc)
        self.active = active_tool(self.doc)
        self.selected_number = None
        self.loading_grid = False

        self.Text = "CNC Tool Settings"
        self.Size = Size(1240, 780)
        self.MinimumSize = Size(980, 640)
        self.StartPosition = FormStartPosition.CenterScreen
        self.FormBorderStyle = FormBorderStyle.Sizable
        self.MaximizeBox = True
        self.MinimizeBox = True
        self.BackColor = Color.FromArgb(245, 245, 245)

        self.font_title = Font("Segoe UI", 18, FontStyle.Bold)
        self.font_section = Font("Segoe UI", 11, FontStyle.Bold)
        self.font_label = Font("Segoe UI", 10, FontStyle.Regular)
        self.font_input = Font("Segoe UI", 10, FontStyle.Regular)

        self.fields = {}
        self._build_ui()
        self.refresh_grid()
        self.select_tool(self.active)

    # -----------------------------
    # UI helpers
    # -----------------------------

    def _label(self, text, font=None, color=None):
        lbl = Label()
        lbl.Text = text
        lbl.Font = font or self.font_label
        lbl.AutoSize = True
        lbl.Margin = Padding(0, 4, 8, 4)
        if color:
            lbl.ForeColor = color
        return lbl

    def _fill_label(self, text, font=None, color=None):
        lbl = Label()
        lbl.Text = text
        lbl.Font = font or self.font_label
        lbl.AutoSize = False
        lbl.Dock = DockStyle.Fill
        lbl.Margin = Padding(0, 4, 8, 4)
        lbl.TextAlign = ContentAlignment.MiddleLeft
        if color:
            lbl.ForeColor = color
        return lbl

    def _textbox(self):
        txt = TextBox()
        txt.Font = self.font_input
        txt.Dock = DockStyle.Fill
        txt.Margin = Padding(6, 3, 0, 3)
        return txt

    def _button(self, text, handler):
        btn = Button()
        btn.Text = text
        btn.Font = self.font_label
        btn.Height = 36
        btn.Width = 150
        btn.Margin = Padding(0, 0, 10, 10)
        btn.Click += handler
        return btn

    def _section(self, title):
        outer = TableLayoutPanel()
        outer.Dock = DockStyle.Fill
        outer.BackColor = Color.White
        outer.Padding = Padding(18)
        outer.Margin = Padding(0)
        outer.ColumnCount = 1
        outer.RowCount = 2
        outer.RowStyles.Add(RowStyle(SizeType.Absolute, 38))
        outer.RowStyles.Add(RowStyle(SizeType.Percent, 100))
        outer.ColumnStyles.Add(ColumnStyle(SizeType.Percent, 100))

        title_lbl = self._fill_label(title, self.font_section)
        outer.Controls.Add(title_lbl, 0, 0)
        return outer

    def _add_field(self, table, row, key, label):
        lbl = self._fill_label(label)
        txt = self._textbox()
        table.Controls.Add(lbl, 0, row)
        table.Controls.Add(txt, 1, row)
        self.fields[key] = txt

    def _build_ui(self):
        # Root layout: header / content / footer.
        self.root = TableLayoutPanel()
        self.root.Dock = DockStyle.Fill
        self.root.BackColor = Color.FromArgb(245, 245, 245)
        self.root.Padding = Padding(24)
        self.root.ColumnCount = 1
        self.root.RowCount = 3
        self.root.ColumnStyles.Add(ColumnStyle(SizeType.Percent, 100))
        self.root.RowStyles.Add(RowStyle(SizeType.Absolute, 88))
        self.root.RowStyles.Add(RowStyle(SizeType.Percent, 100))
        self.root.RowStyles.Add(RowStyle(SizeType.Absolute, 44))
        self.Controls.Add(self.root)

        # Header.
        header = TableLayoutPanel()
        header.Dock = DockStyle.Fill
        header.ColumnCount = 1
        header.RowCount = 2
        header.ColumnStyles.Add(ColumnStyle(SizeType.Percent, 100))
        header.RowStyles.Add(RowStyle(SizeType.Absolute, 48))
        header.RowStyles.Add(RowStyle(SizeType.Absolute, 30))
        header.Margin = Padding(0, 0, 0, 8)

        title = self._fill_label("CNC tool settings", self.font_title)
        title.Margin = Padding(0, 0, 0, 0)
        self.active_label = self._fill_label("", self.font_label, Color.FromArgb(70, 70, 70))
        self.active_label.Margin = Padding(0, 0, 0, 0)

        header.Controls.Add(title, 0, 0)
        header.Controls.Add(self.active_label, 0, 1)
        self.root.Controls.Add(header, 0, 0)

        # Main content: two columns.
        main = TableLayoutPanel()
        main.Dock = DockStyle.Fill
        main.ColumnCount = 2
        main.RowCount = 1
        main.ColumnStyles.Add(ColumnStyle(SizeType.Percent, 58))
        main.ColumnStyles.Add(ColumnStyle(SizeType.Percent, 42))
        main.RowStyles.Add(RowStyle(SizeType.Percent, 100))
        main.Margin = Padding(0)
        self.root.Controls.Add(main, 0, 1)

        # Left: tool list.
        left_section = self._section("Tool list")
        left_section.Margin = Padding(0, 0, 12, 0)
        main.Controls.Add(left_section, 0, 0)

        self.grid = DataGridView()
        self.grid.Dock = DockStyle.Fill
        self.grid.ReadOnly = True
        self.grid.AllowUserToAddRows = False
        self.grid.AllowUserToDeleteRows = False
        self.grid.MultiSelect = False
        self.grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        self.grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        self.grid.BackgroundColor = Color.White
        self.grid.RowHeadersVisible = False
        self.grid.Font = self.font_label
        self.grid.ColumnHeadersDefaultCellStyle.Font = self.font_label
        self.grid.RowTemplate.Height = 30
        self.grid.Margin = Padding(0)
        self.grid.Columns.Add("number", "Tool")
        self.grid.Columns.Add("name", "Name")
        self.grid.Columns.Add("diameter", "Diameter")
        self.grid.Columns.Add("spindle", "RPM")
        self.grid.Columns.Add("feed_cut", "Cut feed")
        self.grid.Columns.Add("safe_z", "Safe Z")
        try:
            for col in self.grid.Columns:
                col.SortMode = DataGridViewColumnSortMode.NotSortable
        except:
            pass
        self.grid.SelectionChanged += self.on_grid_selection
        left_section.Controls.Add(self.grid, 0, 1)

        # Right: selected tool + actions.
        right_section = self._section("Selected tool")
        right_section.Margin = Padding(12, 0, 0, 0)
        main.Controls.Add(right_section, 1, 0)

        right_body = TableLayoutPanel()
        right_body.Dock = DockStyle.Fill
        right_body.ColumnCount = 1
        right_body.RowCount = 4
        right_body.ColumnStyles.Add(ColumnStyle(SizeType.Percent, 100))
        right_body.RowStyles.Add(RowStyle(SizeType.AutoSize))
        right_body.RowStyles.Add(RowStyle(SizeType.Absolute, 18))
        right_body.RowStyles.Add(RowStyle(SizeType.AutoSize))
        right_body.RowStyles.Add(RowStyle(SizeType.Percent, 100))
        right_body.Margin = Padding(0)
        right_section.Controls.Add(right_body, 0, 1)

        # Fields.
        field_table = TableLayoutPanel()
        field_table.Dock = DockStyle.Top
        field_table.AutoSize = True
        field_table.AutoSizeMode = AutoSizeMode.GrowAndShrink
        field_table.ColumnCount = 2
        field_table.RowCount = 9
        field_table.ColumnStyles.Add(ColumnStyle(SizeType.Absolute, 210))
        field_table.ColumnStyles.Add(ColumnStyle(SizeType.Percent, 100))
        field_table.Margin = Padding(0, 0, 0, 0)

        for i in range(9):
            field_table.RowStyles.Add(RowStyle(SizeType.Absolute, 40))

        self._add_field(field_table, 0, "number", "Tool number")
        self._add_field(field_table, 1, "name", "Tool name")
        self._add_field(field_table, 2, "diameter", "Tool diameter mm")
        self._add_field(field_table, 3, "spindle", "Spindle RPM")
        self._add_field(field_table, 4, "feed_cut", "Cut feed mm/min")
        self._add_field(field_table, 5, "feed_plunge", "Plunge feed mm/min")
        self._add_field(field_table, 6, "feed_travel", "Travel feed mm/min")
        self._add_field(field_table, 7, "safe_z", "Safe Z mm")
        self._add_field(field_table, 8, "retract_z", "Drill retract R mm")
        right_body.Controls.Add(field_table, 0, 0)

        # Tool actions.
        actions_panel = TableLayoutPanel()
        actions_panel.Dock = DockStyle.Top
        actions_panel.AutoSize = True
        actions_panel.AutoSizeMode = AutoSizeMode.GrowAndShrink
        actions_panel.ColumnCount = 1
        actions_panel.RowCount = 3
        actions_panel.ColumnStyles.Add(ColumnStyle(SizeType.Percent, 100))
        actions_panel.RowStyles.Add(RowStyle(SizeType.Absolute, 34))
        actions_panel.RowStyles.Add(RowStyle(SizeType.AutoSize))
        actions_panel.RowStyles.Add(RowStyle(SizeType.AutoSize))
        actions_panel.Margin = Padding(0)

        actions_panel.Controls.Add(self._fill_label("Tool actions", self.font_section), 0, 0)

        button_row = FlowLayoutPanel()
        button_row.Dock = DockStyle.Fill
        button_row.AutoSize = True
        button_row.WrapContents = True
        button_row.Margin = Padding(0)
        button_row.Controls.Add(self._button("New tool", self.on_new_tool))
        button_row.Controls.Add(self._button("Save tool", self.on_save_tool))
        button_row.Controls.Add(self._button("Delete tool", self.on_delete_tool))
        actions_panel.Controls.Add(button_row, 0, 1)

        active_btn = Button()
        active_btn.Text = "Set selected active"
        active_btn.Font = self.font_label
        active_btn.Dock = DockStyle.Top
        active_btn.Height = 38
        active_btn.Margin = Padding(0, 0, 0, 14)
        active_btn.Click += self.on_set_active
        actions_panel.Controls.Add(active_btn, 0, 2)

        right_body.Controls.Add(actions_panel, 0, 2)

        # Project settings.
        project_panel = TableLayoutPanel()
        project_panel.Dock = DockStyle.Top
        project_panel.AutoSize = True
        project_panel.AutoSizeMode = AutoSizeMode.GrowAndShrink
        project_panel.ColumnCount = 1
        project_panel.RowCount = 2
        project_panel.ColumnStyles.Add(ColumnStyle(SizeType.Percent, 100))
        project_panel.RowStyles.Add(RowStyle(SizeType.Absolute, 34))
        project_panel.RowStyles.Add(RowStyle(SizeType.AutoSize))
        project_panel.Margin = Padding(0, 12, 0, 0)

        project_panel.Controls.Add(self._fill_label("Project settings", self.font_section), 0, 0)

        project_buttons = FlowLayoutPanel()
        project_buttons.Dock = DockStyle.Fill
        project_buttons.AutoSize = True
        project_buttons.WrapContents = True
        project_buttons.Margin = Padding(0)
        project_buttons.Controls.Add(self._button("Export settings", self.on_export_settings))
        project_buttons.Controls.Add(self._button("Import settings", self.on_import_settings))
        project_panel.Controls.Add(project_buttons, 0, 1)

        right_body.Controls.Add(project_panel, 0, 3)

        # Footer.
        self.status_label = self._fill_label(
            "Settings are saved for this Revit project only. New projects start with defaults.",
            self.font_label,
            Color.FromArgb(70, 70, 70)
        )
        self.status_label.Margin = Padding(0, 10, 0, 0)
        self.root.Controls.Add(self.status_label, 0, 2)

    # -----------------------------
    # Logic
    # -----------------------------

    def set_status(self, text):
        try:
            self.status_label.Text = text
        except:
            pass

    def _find_tool(self, number):
        nr = ival(number, 0)
        for tool in self.tools:
            if _tool_number(tool) == nr:
                return tool
        return None

    def _next_number(self):
        nums = [_tool_number(t) for t in self.tools]
        if not nums:
            return 1
        return max(nums) + 1

    def refresh_grid(self, select_number=None):
        self.loading_grid = True
        self.grid.Rows.Clear()

        self.tools.sort(key=_tool_number)
        valid_numbers = [_tool_number(t) for t in self.tools]
        if self.active not in valid_numbers and valid_numbers:
            self.active = valid_numbers[0]

        for tool in self.tools:
            idx = self.grid.Rows.Add()
            row = self.grid.Rows[idx]
            nr = _tool_number(tool)
            row.Cells[0].Value = "T{}".format(nr)
            row.Cells[1].Value = tool.get("name", "")
            row.Cells[2].Value = "{}".format(tool.get("diameter", ""))
            row.Cells[3].Value = "{}".format(tool.get("spindle", ""))
            row.Cells[4].Value = "{}".format(tool.get("feed_cut", ""))
            row.Cells[5].Value = "{}".format(tool.get("safe_z", ""))
            row.Tag = nr
            if nr == self.active:
                row.DefaultCellStyle.BackColor = Color.FromArgb(225, 242, 255)

        self.active_label.Text = "Active tool: T{}".format(self.active)
        self.loading_grid = False

        if select_number is not None:
            self.select_tool(select_number)

    def select_tool(self, number):
        nr = ival(number, 0)
        for row in self.grid.Rows:
            try:
                if ival(row.Tag, 0) == nr:
                    row.Selected = True
                    self.grid.CurrentCell = row.Cells[0]
                    self.load_tool(self._find_tool(nr))
                    return
            except:
                pass

        if self.grid.Rows.Count > 0:
            row = self.grid.Rows[0]
            row.Selected = True
            self.grid.CurrentCell = row.Cells[0]
            self.load_tool(self._find_tool(row.Tag))

    def get_selected_number(self):
        try:
            if self.grid.SelectedRows.Count > 0:
                return ival(self.grid.SelectedRows[0].Tag, 0)
        except:
            pass
        return self.selected_number

    def load_tool(self, tool):
        if not tool:
            return
        self.selected_number = _tool_number(tool)
        for key in self.fields:
            self.fields[key].Text = str(tool.get(key, ""))

    def on_grid_selection(self, sender, args):
        if self.loading_grid:
            return
        nr = self.get_selected_number()
        if nr:
            self.load_tool(self._find_tool(nr))

    def _read_text(self, key):
        try:
            return str(self.fields[key].Text).strip()
        except:
            return ""

    def _read_float(self, key, label, allow_zero=True):
        raw = self._read_text(key)
        try:
            value = float(raw.replace(",", "."))
        except:
            MessageBox.Show(label + " must be a valid number.", "CNC Tool Settings",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return None

        if value < 0 or (not allow_zero and value <= 0):
            MessageBox.Show(label + " has an invalid value.", "CNC Tool Settings",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return None
        return value

    def collect_form_tool(self):
        number_raw = self._read_text("number")
        try:
            number = int(float(number_raw.replace(",", ".")))
        except:
            MessageBox.Show("Tool number must be a valid whole number.", "CNC Tool Settings",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return None

        if number <= 0:
            MessageBox.Show("Tool number must be greater than 0.", "CNC Tool Settings",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return None

        name = self._read_text("name") or "Tool"
        diameter = self._read_float("diameter", "Tool diameter", False)
        spindle = self._read_float("spindle", "Spindle RPM")
        feed_cut = self._read_float("feed_cut", "Cut feed")
        feed_plunge = self._read_float("feed_plunge", "Plunge feed")
        feed_travel = self._read_float("feed_travel", "Travel feed")
        safe_z = self._read_float("safe_z", "Safe Z")
        retract_z = self._read_float("retract_z", "Drill retract R")

        values = [diameter, spindle, feed_cut, feed_plunge, feed_travel, safe_z, retract_z]
        if None in values:
            return None

        return {
            "number": number,
            "name": name,
            "diameter": diameter,
            "spindle": spindle,
            "feed_cut": feed_cut,
            "feed_plunge": feed_plunge,
            "feed_travel": feed_travel,
            "safe_z": safe_z,
            "retract_z": retract_z
        }

    def on_new_tool(self, sender, args):
        tool = _normalize_tool(DEFAULT_TOOLS[0])
        tool["number"] = self._next_number()
        tool["name"] = "Tool {}".format(tool["number"])
        self.selected_number = None
        try:
            self.grid.ClearSelection()
        except:
            pass
        self.load_tool(tool)
        self.set_status("New tool ready. Edit values and press Save tool.")

    def on_save_tool(self, sender, args):
        tool = self.collect_form_tool()
        if not tool:
            return

        nr = _tool_number(tool)
        self.tools = [t for t in self.tools if _tool_number(t) != nr]
        self.tools.append(tool)

        if not self.active:
            self.active = nr

        save_tools(self.tools, self.active, self.doc)
        self.refresh_grid(nr)
        self.set_status("Tool T{} saved.".format(nr))

    def on_delete_tool(self, sender, args):
        nr = self.get_selected_number()
        if not nr:
            self.set_status("Select a tool to delete.")
            return

        if len(self.tools) <= 1:
            self.set_status("At least one tool must remain.")
            return

        self.tools = [t for t in self.tools if _tool_number(t) != nr]
        if self.active == nr:
            self.active = _tool_number(self.tools[0])

        save_tools(self.tools, self.active, self.doc)
        self.refresh_grid(self.active)
        self.set_status("Tool T{} deleted.".format(nr))

    def on_set_active(self, sender, args):
        nr = self.get_selected_number()
        if not nr:
            self.set_status("Select a tool to set active.")
            return

        self.active = nr
        save_tools(self.tools, self.active, self.doc)
        self.refresh_grid(nr)
        self.set_status("Tool T{} is now active.".format(nr))

    def on_export_settings(self, sender, args):
        if export_tool_settings(self.doc):
            self.set_status("Tool settings export finished.")

    def on_import_settings(self, sender, args):
        if import_tool_settings(self.doc):
            self.tools = load_tools(self.doc)
            self.active = active_tool(self.doc)
            self.refresh_grid(self.active)
            self.set_status("Tool settings imported for this project.")


def show_tool_settings_dialog(doc=None):
    form = ToolSettingsForm(doc)
    try:
        return form.ShowDialog()
    finally:
        try:
            form.Dispose()
        except:
            pass


def export_tool_settings(doc=None):
    data = {
        "schema": "PrefabAnalyser_CNC_Tool_Settings_v1",
        "active_tool": active_tool(doc),
        "tools": load_tools(doc)
    }

    dlg = SaveFileDialog()
    dlg.Title = "Exporteer CNC tool settings"
    dlg.Filter = "JSON files (*.json)|*.json"
    dlg.FileName = "cnc_tool_settings.json"
    if dlg.ShowDialog() != DialogResult.OK:
        return False

    with open(str(dlg.FileName), "w") as f:
        f.write(json.dumps(data, indent=2, sort_keys=True))
    forms.alert("Tool settings geexporteerd.", title="CNC Tools")
    return True


def import_tool_settings(doc=None):
    dlg = OpenFileDialog()
    dlg.Title = "Importeer CNC tool settings"
    dlg.Filter = "JSON files (*.json)|*.json"
    if dlg.ShowDialog() != DialogResult.OK:
        return False

    with open(str(dlg.FileName), "r") as f:
        data = json.loads(f.read())

    tools = data.get("tools")
    if not isinstance(tools, list) or not tools:
        forms.alert("Ongeldig settingsbestand.", title="CNC Tools")
        return False

    save_tools(tools, ival(data.get("active_tool"), _tool_number(tools[0])), doc)
    forms.alert("Tool settings geimporteerd.", title="CNC Tools")
    return True
