# -*- coding: utf-8 -*-
import clr
clr.AddReference("System")
clr.AddReference("RevitAPI")

import json

from Autodesk.Revit.DB import Transaction
from Autodesk.Revit.DB.ExtensibleStorage import (
    Schema, SchemaBuilder, AccessLevel, Entity
)
from System import Guid

SCHEMA_GUID = Guid("6F9619FF-8B86-D011-B42D-00C04FC964FF")
SCHEMA_NAME = "PrefabAnalyserBeamOrigins"
FIELD_NAME = "JsonData"


def _get_schema():
    schema = Schema.Lookup(SCHEMA_GUID)
    if schema:
        return schema

    sb = SchemaBuilder(SCHEMA_GUID)
    sb.SetSchemaName(SCHEMA_NAME)
    sb.SetReadAccessLevel(AccessLevel.Public)
    sb.SetWriteAccessLevel(AccessLevel.Public)
    sb.AddSimpleField(FIELD_NAME, str)
    return sb.Finish()


def _get_project_info(doc):
    try:
        return doc.ProjectInformation
    except:
        return None


def load_origins(doc):
    schema = _get_schema()
    pi = _get_project_info(doc)
    if pi is None:
        return {}

    try:
        ent = pi.GetEntity(schema)
        if ent and ent.IsValid():
            txt = ent.Get[str](schema.GetField(FIELD_NAME))
            if txt:
                return json.loads(txt)
    except:
        pass

    return {}


def _write_origins(doc, data):
    schema = _get_schema()
    pi = _get_project_info(doc)
    if pi is None:
        return

    t = Transaction(doc, "Save CNC Origins")
    t.Start()
    ent = Entity(schema)
    ent.Set[str](schema.GetField(FIELD_NAME), json.dumps(data))
    pi.SetEntity(ent)
    t.Commit()


def _matching_origin_keys(data, element_id_int):
    keys = []
    try:
        target = int(element_id_int)
    except:
        return keys

    primary = str(target)
    if primary in data:
        keys.append(primary)

    for key in list(data.keys()):
        if key == primary:
            continue
        try:
            if int(key) == target:
                keys.append(key)
        except:
            pass

    return keys


def save_origin(doc, element_id_int, xyz, axis_index=None, xy_rotation=None):
    data = load_origins(doc)
    key = str(int(element_id_int))
    old = data.get(key, {})
    if axis_index is None:
        axis_index = old.get("axis_index", 0)
    if xy_rotation is None:
        xy_rotation = old.get("xy_rotation", None)
        if xy_rotation is None:
            xy_rotation = 1 if bool(old.get("xy_swapped", False)) else 0

    try:
        axis_index = int(axis_index)
    except:
        axis_index = 0
    try:
        xy_rotation = int(xy_rotation) % 4
    except:
        xy_rotation = 0

    data[key] = {
        "x": float(xyz.X),
        "y": float(xyz.Y),
        "z": float(xyz.Z),
        "axis_index": axis_index,
        "xy_rotation": xy_rotation
    }
    _write_origins(doc, data)


def save_origin_axes(doc, element_id_int, axis_index):
    data = load_origins(doc)
    key = str(int(element_id_int))
    if key not in data:
        return

    try:
        axis_index = int(axis_index)
    except:
        axis_index = 0

    data[key]["axis_index"] = axis_index
    _write_origins(doc, data)


def save_origin_xy_rotation(doc, element_id_int, xy_rotation):
    data = load_origins(doc)
    key = str(int(element_id_int))
    if key not in data:
        return

    try:
        xy_rotation = int(xy_rotation) % 4
    except:
        xy_rotation = 0

    data[key]["xy_rotation"] = xy_rotation
    _write_origins(doc, data)


def save_origin_xy_swap(doc, element_id_int, xy_swapped):
    save_origin_xy_rotation(doc, element_id_int, 1 if xy_swapped else 0)


def has_origin(doc, element_id_int):
    data = load_origins(doc)
    return len(_matching_origin_keys(data, element_id_int)) > 0


def clear_origin(doc, element_id_int):
    data = load_origins(doc)
    keys = _matching_origin_keys(data, element_id_int)
    if keys:
        for key in keys:
            try:
                del data[key]
            except:
                pass
        _write_origins(doc, data)
        return True
    return False
