# -*- coding: utf-8 -*-
__title__ = "CNC Export"
__persistentengine__ = True

import clr
clr.AddReference("System")
clr.AddReference("WindowsBase")
clr.AddReference("PresentationCore")
clr.AddReference("PresentationFramework")
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

import os
import math

from pyrevit import forms
from Autodesk.Revit.UI import ExternalEvent
from System.Windows import Visibility
from System.Windows.Media import Brushes
from System.Windows.Media import VisualTreeHelper

import event_handler
import storage

uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document


class UI(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)

        self.doc = doc

        self.BeamGrid = self.FindName("BeamGrid")
        self.SearchBox = self.FindName("SearchBox")
        self.StatusText = self.FindName("StatusText")
        self.SelectedBeamText = self.FindName("SelectedBeamText")
        self.OriginText = self.FindName("OriginText")
        self.RefreshButton = self.FindName("RefreshButton")
        self.ShowInRevitButton = self.FindName("ShowInRevitButton")
        self.PickOriginButton = self.FindName("PickOriginButton")
        self.ClearOriginButton = self.FindName("ClearOriginButton")
        self.ExportButton = self.FindName("ExportButton")
        self.ToolSettingsButton = self.FindName("ToolSettingsButton")
        self.PreviewViewport = self.FindName("PreviewViewport")
        self.RotateXSlider = self.FindName("RotateXSlider")
        self.RotateYSlider = self.FindName("RotateYSlider")
        self.RotateZSlider = self.FindName("RotateZSlider")
        self.ResetViewButton = self.FindName("ResetViewButton")
        self.RotateCncXYButton = self.FindName("RotateCncXYButton")

        self._rows = []
        self._origins = storage.load_origins(self.doc)
        self._payload = None
        self._mesh_model = None
        self._edge_model = None
        self._origin_model = None
        self._axis_model = None
        self._origin_real_point = None
        self._cnc_axes_rotation_index = 0
        self._cnc_xy_rotation = 0
        self._root_group = None
        self._suppress_selection_event = False

        self._handler = event_handler.BeamExternalEventHandler(self)
        self._ext_event = ExternalEvent.Create(self._handler)

        self._cam_target = [0.0, 0.0, 0.0]
        self._cam_distance = 8.0
        self._cam_yaw = -18.0
        self._cam_pitch = 16.0
        self._cam_zoom = 3.2
        self._mouse_mode = None
        self._last_mouse = None
        self._drag_started = False

        if self.BeamGrid:
            self.BeamGrid.SelectionChanged += self.on_select
        if self.SearchBox:
            self.SearchBox.TextChanged += self.on_search
        if self.RefreshButton:
            self.RefreshButton.Click += self.on_refresh
        if self.ShowInRevitButton:
            self.ShowInRevitButton.Click += self.on_show_in_revit
        if self.PickOriginButton:
            self.PickOriginButton.Visibility = Visibility.Collapsed
        if self.ClearOriginButton:
            self.ClearOriginButton.Click += self.on_clear_origin
        if self.ExportButton:
            self.ExportButton.Click += self.on_export
        if self.ToolSettingsButton:
            self.ToolSettingsButton.Click += self.on_tool_settings
        if self.ResetViewButton:
            self.ResetViewButton.Click += self.on_reset_view
        if self.RotateCncXYButton:
            self.RotateCncXYButton.Click += self.on_rotate_cnc_xy

        if self.RotateXSlider:
            self.RotateXSlider.Visibility = Visibility.Collapsed
        if self.RotateYSlider:
            self.RotateYSlider.Visibility = Visibility.Collapsed
        if self.RotateZSlider:
            self.RotateZSlider.Visibility = Visibility.Collapsed

        self.setup_preview()
        self._hook_navigation_surface()
        self.refresh_rows()

    def _hook_navigation_surface(self):
        target = self.PreviewViewport
        try:
            parent = VisualTreeHelper.GetParent(self.PreviewViewport)
            if parent is not None:
                target = parent
                try:
                    if hasattr(target, "Background"):
                        target.Background = Brushes.Transparent
                except:
                    pass
        except:
            pass

        self._nav_surface = target

        try:
            target.MouseWheel += self.on_nav_mouse_wheel
            target.MouseDown += self.on_nav_mouse_down
            target.MouseMove += self.on_nav_mouse_move
            target.MouseUp += self.on_nav_mouse_up
            target.MouseLeftButtonUp += self.on_preview_click
        except:
            pass

        try:
            self.PreviewViewport.MouseWheel += self.on_nav_mouse_wheel
            self.PreviewViewport.MouseDown += self.on_nav_mouse_down
            self.PreviewViewport.MouseMove += self.on_nav_mouse_move
            self.PreviewViewport.MouseUp += self.on_nav_mouse_up
            self.PreviewViewport.MouseLeftButtonUp += self.on_preview_click
        except:
            pass

    def set_status(self, text):
        try:
            self.StatusText.Text = text
        except:
            pass

    def setup_preview(self):
        if not self.PreviewViewport:
            return

        from System.Windows.Media import Color
        from System.Windows.Media.Media3D import (
            OrthographicCamera, Model3DGroup, ModelVisual3D,
            AmbientLight, DirectionalLight, Vector3D
        )

        self.PreviewViewport.Children.Clear()

        cam = OrthographicCamera()
        cam.Width = 3.2
        self.PreviewViewport.Camera = cam

        group = Model3DGroup()
        group.Children.Add(AmbientLight(Color.FromRgb(230, 230, 230)))
        group.Children.Add(DirectionalLight(Color.FromRgb(240, 240, 240), Vector3D(-1, 1, -1)))
        group.Children.Add(DirectionalLight(Color.FromRgb(220, 220, 220), Vector3D(1, -1, -0.2)))

        visual = ModelVisual3D()
        visual.Content = group
        self.PreviewViewport.Children.Add(visual)

        self._root_group = group

        try:
            parent = VisualTreeHelper.GetParent(self.PreviewViewport)
            if parent is not None and hasattr(parent, "Background"):
                parent.Background = Brushes.Gainsboro
        except:
            pass

        self.fit_camera()

    def clear_preview(self):
        for model in [self._mesh_model, self._edge_model, self._origin_model, self._axis_model]:
            try:
                if self._root_group and model:
                    self._root_group.Children.Remove(model)
            except:
                pass
        self._mesh_model = None
        self._edge_model = None
        self._origin_model = None
        self._axis_model = None
        self._origin_real_point = None
        self._payload = None

    def _build_display_payload(self, payload):
        verts = payload["vertices"]
        center = payload["center"]
        radius = payload["radius"]
        r = float(radius) if float(radius) > 0.0001 else 1.0

        disp = []
        for v in verts:
            disp.append([
                (float(v[0]) - float(center[0])) / r,
                (float(v[1]) - float(center[1])) / r,
                (float(v[2]) - float(center[2])) / r
            ])

        out = dict(payload)
        out["_display_vertices"] = disp
        out["_display_radius"] = r
        return out

    def _vec_sub(self, a, b):
        return [a[0]-b[0], a[1]-b[1], a[2]-b[2]]

    def _vec_add(self, a, b):
        return [a[0]+b[0], a[1]+b[1], a[2]+b[2]]

    def _vec_mul(self, a, s):
        return [a[0]*s, a[1]*s, a[2]*s]

    def _dot(self, a, b):
        return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

    def _cross(self, a, b):
        return [
            a[1]*b[2] - a[2]*b[1],
            a[2]*b[0] - a[0]*b[2],
            a[0]*b[1] - a[1]*b[0]
        ]

    def _norm(self, a):
        import math
        l = math.sqrt(max(1e-12, self._dot(a, a)))
        return [a[0]/l, a[1]/l, a[2]/l]

    def _triangle_normal(self, p1, p2, p3):
        n = self._cross(self._vec_sub(p2, p1), self._vec_sub(p3, p1))
        return self._norm(n)

    def _append_prism_edge(self, positions, indices, p1, p2, thickness):
        d = self._vec_sub(p2, p1)
        if self._dot(d, d) < 1e-10:
            return
        d = self._norm(d)
        up = [0.0, 0.0, 1.0]
        if abs(self._dot(d, up)) > 0.95:
            up = [0.0, 1.0, 0.0]

        n1 = self._norm(self._cross(d, up))
        n2 = self._norm(self._cross(d, n1))
        n1 = self._vec_mul(n1, thickness)
        n2 = self._vec_mul(n2, thickness)

        c = []
        for base in [p1, p2]:
            c.append(self._vec_add(self._vec_add(base, n1), n2))
            c.append(self._vec_add(self._vec_sub(base, n1), n2))
            c.append(self._vec_sub(self._vec_sub(base, n1), n2))
            c.append(self._vec_add(self._vec_sub(base, n2), n1))

        start = len(positions)
        positions.extend(c)
        faces = [
            [0,1,2],[0,2,3],[4,6,5],[4,7,6],[0,4,5],[0,5,1],
            [1,5,6],[1,6,2],[2,6,7],[2,7,3],[3,7,4],[3,4,0],
        ]
        for f in faces:
            indices.extend([start + f[0], start + f[1], start + f[2]])

    def _build_edge_model(self, disp_vertices, triangles):
        import math
        from System.Windows.Media import Color, SolidColorBrush, Int32Collection
        from System.Windows.Media.Media3D import (
            MeshGeometry3D, Point3D, Point3DCollection,
            GeometryModel3D, DiffuseMaterial
        )

        tri_normals = []
        for tri in triangles:
            p1 = disp_vertices[tri[0]]
            p2 = disp_vertices[tri[1]]
            p3 = disp_vertices[tri[2]]
            tri_normals.append(self._triangle_normal(p1, p2, p3))

        edge_to_faces = {}
        for i, tri in enumerate(triangles):
            for a, b in [(tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0])]:
                if a > b:
                    a, b = b, a
                edge_to_faces.setdefault((a, b), []).append(i)

        positions = []
        indices = []
        crease_cos = math.cos(math.radians(18.0))

        for (a, b), faces in edge_to_faces.items():
            keep = False
            if len(faces) == 1:
                keep = True
            elif len(faces) >= 2:
                n1 = tri_normals[faces[0]]
                n2 = tri_normals[faces[1]]
                if self._dot(n1, n2) < crease_cos:
                    keep = True

            if keep:
                self._append_prism_edge(positions, indices, disp_vertices[a], disp_vertices[b], 0.0035)

        if not positions:
            return None

        mesh = MeshGeometry3D()
        pts = Point3DCollection()
        for v in positions:
            pts.Add(Point3D(v[0], v[1], v[2]))
        mesh.Positions = pts

        idx = Int32Collection()
        for i in indices:
            idx.Add(int(i))
        mesh.TriangleIndices = idx

        mat = DiffuseMaterial(SolidColorBrush(Color.FromRgb(25, 25, 25)))
        model = GeometryModel3D()
        model.Geometry = mesh
        model.Material = mat
        model.BackMaterial = mat
        return model

    def _build_origin_marker_model(self, vx, vy, vz, size):
        from System.Windows.Media import Color, SolidColorBrush, Int32Collection
        from System.Windows.Media.Media3D import (
            MeshGeometry3D, Point3D, Point3DCollection,
            GeometryModel3D, DiffuseMaterial
        )

        p = [
            [vx-size, vy-size, vz-size], [vx+size, vy-size, vz-size], [vx+size, vy+size, vz-size], [vx-size, vy+size, vz-size],
            [vx-size, vy-size, vz+size], [vx+size, vy-size, vz+size], [vx+size, vy+size, vz+size], [vx-size, vy+size, vz+size],
        ]
        faces = [
            [0,1,2],[0,2,3],[4,6,5],[4,7,6],[0,4,5],[0,5,1],
            [1,5,6],[1,6,2],[2,6,7],[2,7,3],[3,7,4],[3,4,0]
        ]

        mesh = MeshGeometry3D()
        pts = Point3DCollection()
        for v in p:
            pts.Add(Point3D(v[0], v[1], v[2]))
        mesh.Positions = pts

        idx = Int32Collection()
        for tri in faces:
            idx.Add(tri[0]); idx.Add(tri[1]); idx.Add(tri[2])
        mesh.TriangleIndices = idx

        mat = DiffuseMaterial(SolidColorBrush(Color.FromRgb(220, 30, 30)))
        model = GeometryModel3D()
        model.Geometry = mesh
        model.Material = mat
        model.BackMaterial = mat
        return model


    def _axis_name(self, v):
        names = ["Revit X", "Revit Y", "Revit Z"]
        vals = [float(v[0]), float(v[1]), float(v[2])]
        idx = max(range(3), key=lambda i: abs(vals[i]))
        return names[idx] if vals[idx] >= 0 else "-" + names[idx]

    def _get_cnc_axis_vectors(self):
        """
        CNC assen rond het gekozen origin.
        CNC-Z loopt automatisch parallel met de kortste globale balkmaat.
        Kleuren:
        - X = rood
        - Y = groen
        - Z/diepte = blauw
        """
        idx = int(self._cnc_axes_rotation_index) % 6

        if idx == 0:
            xaxis = [1.0, 0.0, 0.0]
            yaxis = [0.0, 1.0, 0.0]
            zaxis = [0.0, 0.0, 1.0]
            label = "CNC Z = Revit Z"
        elif idx == 1:
            xaxis = [1.0, 0.0, 0.0]
            yaxis = [0.0, 0.0, -1.0]
            zaxis = [0.0, 1.0, 0.0]
            label = "CNC Z = Revit Y"
        elif idx == 2:
            xaxis = [1.0, 0.0, 0.0]
            yaxis = [0.0, -1.0, 0.0]
            zaxis = [0.0, 0.0, -1.0]
            label = "CNC Z = -Revit Z"
        elif idx == 3:
            xaxis = [1.0, 0.0, 0.0]
            yaxis = [0.0, 0.0, 1.0]
            zaxis = [0.0, -1.0, 0.0]
            label = "CNC Z = -Revit Y"
        elif idx == 4:
            xaxis = [0.0, 1.0, 0.0]
            yaxis = [0.0, 0.0, 1.0]
            zaxis = [1.0, 0.0, 0.0]
            label = "CNC Z = Revit X"
        else:
            xaxis = [0.0, 1.0, 0.0]
            yaxis = [0.0, 0.0, -1.0]
            zaxis = [-1.0, 0.0, 0.0]
            label = "CNC Z = -Revit X"

        rot = int(self._cnc_xy_rotation) % 4
        if rot == 1:
            xaxis, yaxis = yaxis, self._vec_mul(xaxis, -1.0)
        elif rot == 2:
            xaxis, yaxis = self._vec_mul(xaxis, -1.0), self._vec_mul(yaxis, -1.0)
        elif rot == 3:
            xaxis, yaxis = self._vec_mul(yaxis, -1.0), xaxis

        depth_axis = self._vec_mul(zaxis, -1.0)
        label = "{} | Diepte={} | X={} | Y={}".format(
            label,
            self._axis_name(depth_axis),
            self._axis_name(xaxis),
            self._axis_name(yaxis)
        )

        return xaxis, yaxis, zaxis, label

    def _auto_cnc_axis_index(self, real_point=None):
        if not self._payload or not self._payload.get("vertices"):
            return int(self._cnc_axes_rotation_index) % 6

        origin = real_point or self._origin_real_point
        if not origin:
            return int(self._cnc_axes_rotation_index) % 6

        verts = self._payload["vertices"]
        ranges = []
        for name, pos_idx, neg_idx, axis_i in [
            ("X", 4, 5, 0),
            ("Y", 1, 3, 1),
            ("Z", 0, 2, 2),
        ]:
            values = [float(v[axis_i]) for v in verts]
            ranges.append((max(values) - min(values), name, pos_idx, neg_idx, axis_i))

        ranges.sort(key=lambda item: item[0])
        dim, name, pos_idx, neg_idx, axis_i = ranges[0]

        rel_values = [float(v[axis_i]) - float(origin[axis_i]) for v in verts]
        min_rel = min(rel_values)
        max_rel = max(rel_values)

        # Pick the sign that makes most/all stock depth negative from the chosen origin.
        if abs(max_rel) <= abs(min_rel):
            return pos_idx
        return neg_idx

    def _append_axis_prism(self, positions, indices, p1, p2, thickness):
        d = self._vec_sub(p2, p1)
        if self._dot(d, d) < 1e-10:
            return

        d = self._norm(d)
        up = [0.0, 0.0, 1.0]
        if abs(self._dot(d, up)) > 0.95:
            up = [0.0, 1.0, 0.0]

        n1 = self._norm(self._cross(d, up))
        n2 = self._norm(self._cross(d, n1))
        n1 = self._vec_mul(n1, thickness)
        n2 = self._vec_mul(n2, thickness)

        c = []
        for base in [p1, p2]:
            c.append(self._vec_add(self._vec_add(base, n1), n2))
            c.append(self._vec_add(self._vec_sub(base, n1), n2))
            c.append(self._vec_sub(self._vec_sub(base, n1), n2))
            c.append(self._vec_add(self._vec_sub(base, n2), n1))

        start = len(positions)
        positions.extend(c)
        faces = [
            [0,1,2],[0,2,3],
            [4,6,5],[4,7,6],
            [0,4,5],[0,5,1],
            [1,5,6],[1,6,2],
            [2,6,7],[2,7,3],
            [3,7,4],[3,4,0],
        ]
        for f in faces:
            indices.extend([start + f[0], start + f[1], start + f[2]])

    def _build_axis_line_model(self, p1, p2, rgb, thickness):
        from System.Windows.Media import Color, SolidColorBrush, Int32Collection
        from System.Windows.Media.Media3D import (
            MeshGeometry3D, Point3D, Point3DCollection,
            GeometryModel3D, DiffuseMaterial
        )

        positions = []
        indices = []
        self._append_axis_prism(positions, indices, p1, p2, thickness)

        mesh = MeshGeometry3D()
        pts = Point3DCollection()
        for v in positions:
            pts.Add(Point3D(v[0], v[1], v[2]))
        mesh.Positions = pts

        idx = Int32Collection()
        for i in indices:
            idx.Add(int(i))
        mesh.TriangleIndices = idx

        mat = DiffuseMaterial(SolidColorBrush(Color.FromRgb(rgb[0], rgb[1], rgb[2])))
        model = GeometryModel3D()
        model.Geometry = mesh
        model.Material = mat
        model.BackMaterial = mat
        return model

    def _build_cnc_axes_model(self, vx, vy, vz):
        from System.Windows.Media.Media3D import Model3DGroup

        xaxis, yaxis, zaxis, label = self._get_cnc_axis_vectors()

        group = Model3DGroup()
        origin = [vx, vy, vz]
        length = 0.32
        thickness = 0.010
        depth_axis = self._vec_mul(zaxis, -1.0)

        group.Children.Add(self._build_axis_line_model(origin, self._vec_add(origin, self._vec_mul(xaxis, length)), [220, 40, 40], thickness))
        group.Children.Add(self._build_axis_line_model(origin, self._vec_add(origin, self._vec_mul(yaxis, length)), [40, 160, 60], thickness))
        group.Children.Add(self._build_axis_line_model(origin, self._vec_add(origin, self._vec_mul(depth_axis, length)), [40, 80, 220], thickness * 1.2))

        return group

    def _redraw_cnc_axes(self):
        if not self._payload or not self._origin_real_point:
            return

        center = self._payload["center"]
        r = self._payload["_display_radius"]
        real_point = self._origin_real_point

        vx = (float(real_point[0]) - float(center[0])) / r
        vy = (float(real_point[1]) - float(center[1])) / r
        vz = (float(real_point[2]) - float(center[2])) / r

        try:
            if self._axis_model:
                self._root_group.Children.Remove(self._axis_model)
        except:
            pass

        self._axis_model = self._build_cnc_axes_model(vx, vy, vz)
        try:
            self._root_group.Children.Add(self._axis_model)
        except:
            pass

    def _draw_origin_marker_from_real(self, real_point):
        if not self._payload:
            return
        center = self._payload["center"]
        r = self._payload["_display_radius"]
        vx = (float(real_point[0]) - float(center[0])) / r
        vy = (float(real_point[1]) - float(center[1])) / r
        vz = (float(real_point[2]) - float(center[2])) / r

        self._origin_real_point = [float(real_point[0]), float(real_point[1]), float(real_point[2])]
        self._cnc_axes_rotation_index = self._auto_cnc_axis_index(self._origin_real_point)

        try:
            if self._origin_model:
                self._root_group.Children.Remove(self._origin_model)
        except:
            pass

        self._origin_model = self._build_origin_marker_model(vx, vy, vz, 0.012)
        try:
            self._root_group.Children.Add(self._origin_model)
        except:
            pass

        self._redraw_cnc_axes()

    def _get_saved_origin(self):
        eid = self.get_selected_element_id_int()
        if eid is None:
            return None
        return self._origins.get(str(eid))

    def render(self, payload):
        from System.Windows.Media import Color, SolidColorBrush, Int32Collection
        from System.Windows.Media.Media3D import (
            MeshGeometry3D, Point3D, Point3DCollection,
            GeometryModel3D, DiffuseMaterial
        )

        self.clear_preview()

        if not payload or not payload.get("vertices") or not payload.get("triangles"):
            self.set_status("Geen preview geometrie gevonden voor deze balk.")
            return

        payload = self._build_display_payload(payload)
        self._payload = payload

        mesh = MeshGeometry3D()
        pts = Point3DCollection()
        for v in payload["_display_vertices"]:
            pts.Add(Point3D(v[0], v[1], v[2]))
        mesh.Positions = pts

        idx = Int32Collection()
        for tri in payload["triangles"]:
            idx.Add(int(tri[0]))
            idx.Add(int(tri[1]))
            idx.Add(int(tri[2]))
        mesh.TriangleIndices = idx

        mat = DiffuseMaterial(SolidColorBrush(Color.FromRgb(248, 248, 248)))
        model = GeometryModel3D()
        model.Geometry = mesh
        model.Material = mat
        model.BackMaterial = mat

        self._mesh_model = model
        self._root_group.Children.Add(model)

        self._edge_model = self._build_edge_model(payload["_display_vertices"], payload["triangles"])
        if self._edge_model:
            self._root_group.Children.Add(self._edge_model)

        saved = self._get_saved_origin()
        if saved:
            try:
                self._cnc_xy_rotation = int(saved.get("xy_rotation", 1 if saved.get("xy_swapped", False) else 0)) % 4
            except:
                self._cnc_xy_rotation = 0
            self._draw_origin_marker_from_real([saved["x"], saved["y"], saved["z"]])

        self.fit_camera()

    def fit_camera(self):
        import math
        from System.Windows.Media.Media3D import Point3D, Vector3D

        if not self.PreviewViewport or not self.PreviewViewport.Camera:
            return

        yaw = math.radians(float(self._cam_yaw))
        pitch = math.radians(float(self._cam_pitch))
        x = self._cam_target[0] + self._cam_distance * math.cos(pitch) * math.sin(yaw)
        y = self._cam_target[1] - self._cam_distance * math.cos(pitch) * math.cos(yaw)
        z = self._cam_target[2] + self._cam_distance * math.sin(pitch)

        cam = self.PreviewViewport.Camera
        cam.Position = Point3D(x, y, z)
        cam.LookDirection = Vector3D(self._cam_target[0] - x, self._cam_target[1] - y, self._cam_target[2] - z)
        cam.UpDirection = Vector3D(0, 0, 1)
        try:
            cam.Width = float(self._cam_zoom)
        except:
            pass

    def _world_to_camera(self, p):
        import math
        # Returns camera-space coordinates (x right, y up, z forward)
        yaw = math.radians(float(self._cam_yaw))
        pitch = math.radians(float(self._cam_pitch))

        cam_x = self._cam_target[0] + self._cam_distance * math.cos(pitch) * math.sin(yaw)
        cam_y = self._cam_target[1] - self._cam_distance * math.cos(pitch) * math.cos(yaw)
        cam_z = self._cam_target[2] + self._cam_distance * math.sin(pitch)

        cam_pos = [cam_x, cam_y, cam_z]
        target = self._cam_target

        forward = self._norm(self._vec_sub(target, cam_pos))
        world_up = [0.0, 0.0, 1.0]
        right = self._norm(self._cross(forward, world_up))
        up = self._norm(self._cross(right, forward))

        rel = self._vec_sub(p, cam_pos)
        return [
            self._dot(rel, right),
            self._dot(rel, up),
            self._dot(rel, forward)
        ]

    def _project_display_vertex_to_viewport(self, v):
        # Orthographic projection using current camera frame and Width
        if not self.PreviewViewport or not self.PreviewViewport.Camera:
            return None

        w = float(self.PreviewViewport.ActualWidth)
        h = float(self.PreviewViewport.ActualHeight)
        if w <= 1 or h <= 1:
            return None

        cam_p = self._world_to_camera(v)
        width = float(self.PreviewViewport.Camera.Width)
        if width <= 1e-9:
            return None
        height = width * (h / w)

        sx = (cam_p[0] / (width * 0.5)) * (w * 0.5) + (w * 0.5)
        sy = (-cam_p[1] / (height * 0.5)) * (h * 0.5) + (h * 0.5)
        return [sx, sy, cam_p[2]]

    def refresh_rows(self, selected_id=None):
        import event_handler
        import storage

        if selected_id is None:
            selected_id = self.get_selected_element_id_int()
        self._origins = storage.load_origins(self.doc)
        self._rows = event_handler.collect_beams(self.doc, self._origins)
        if self.BeamGrid:
            self._suppress_selection_event = True
            try:
                try:
                    self.BeamGrid.ItemsSource = None
                except:
                    pass
                self.BeamGrid.ItemsSource = self._rows
                if selected_id is not None:
                    for row in self._rows:
                        try:
                            if int(row.ElementId) == int(selected_id):
                                self.BeamGrid.SelectedItem = row
                                try:
                                    self.BeamGrid.ScrollIntoView(row)
                                except:
                                    pass
                                break
                        except:
                            pass
            except:
                pass
            self._suppress_selection_event = False
        self.set_status("{} balk(en) gevonden".format(len(self._rows)))
        self.update_selection_text()

    def get_selected_row(self):
        try:
            return self.BeamGrid.SelectedItem
        except:
            return None

    def get_selected_element_id_int(self):
        row = self.get_selected_row()
        if not row:
            return None
        try:
            return int(row.ElementId)
        except:
            return None

    def update_selection_text(self):
        row = self.get_selected_row()
        if not row:
            try:
                self.SelectedBeamText.Text = "Nog geen balk geselecteerd."
                self.OriginText.Text = "Origin: niet ingesteld"
            except:
                pass
            return

        try:
            self.SelectedBeamText.Text = "[{}] {} | {} | {}".format(
                row.ElementId, row.Mark, row.Family, row.TypeName
            )
        except:
            pass

        origin = self._origins.get(str(row.ElementId))
        if origin:
            try:
                axis_idx = self._auto_cnc_axis_index([origin["x"], origin["y"], origin["z"]])
                old_idx = self._cnc_axes_rotation_index
                old_rot = self._cnc_xy_rotation
                self._cnc_axes_rotation_index = axis_idx
                self._cnc_xy_rotation = int(origin.get("xy_rotation", 1 if origin.get("xy_swapped", False) else 0)) % 4
                xaxis, yaxis, zaxis, label = self._get_cnc_axis_vectors()
                self._cnc_axes_rotation_index = old_idx
                self._cnc_xy_rotation = old_rot
                self.OriginText.Text = "Origin: X={:.3f}, Y={:.3f}, Z={:.3f} | {}".format(
                    origin["x"], origin["y"], origin["z"], label
                )
            except:
                self.OriginText.Text = "Origin: ingesteld"
        else:
            self.OriginText.Text = "Origin: niet ingesteld"

    def raise_action(self, action, direct_origin=None):
        self._handler.request = action
        self._handler.selected_id = self.get_selected_element_id_int()
        self._handler.direct_origin = direct_origin
        self._ext_event.Raise()

    def on_select(self, sender, args):
        if self._suppress_selection_event:
            return
        self.update_selection_text()
        self.raise_action("preview")

    def on_search(self, sender, args):
        txt = ""
        try:
            txt = (self.SearchBox.Text or "").strip().lower()
        except:
            pass
        if not txt:
            self.BeamGrid.ItemsSource = self._rows
            self.set_status("{} balk(en) gevonden".format(len(self._rows)))
            return

        filtered = []
        for r in self._rows:
            hay = " | ".join([str(r.Mark), str(r.Family), str(r.TypeName), str(r.LengthMM), str(r.OriginStatus), str(r.ElementId)]).lower()
            if txt in hay:
                filtered.append(r)
        self.BeamGrid.ItemsSource = filtered
        self.set_status("{} balk(en) na filter".format(len(filtered)))

    def on_refresh(self, sender, args):
        self.raise_action("refresh")

    def on_show_in_revit(self, sender, args):
        if self.get_selected_row() is None:
            self.set_status("Selecteer eerst een balk.")
            return
        self.raise_action("show_in_revit")

    def on_clear_origin(self, sender, args):
        if self.get_selected_row() is None:
            self.set_status("Selecteer eerst een balk.")
            return
        self.raise_action("clear_origin")

    def on_export(self, sender, args):
        self.raise_action("export")

    def on_tool_settings(self, sender, args):
        try:
            import tool_settings
            tool_settings.show_tool_settings_dialog(self.doc)
            self.set_status("CNC tool settings gesloten.")
        except Exception as ex:
            self.set_status("Tool settings openen mislukt: {}".format(ex))

    def on_rotate_cnc_xy(self, sender, args):
        if not self._origin_real_point:
            self.set_status("Kies eerst een origin point in de 3D preview.")
            return
        self._cnc_xy_rotation = (int(self._cnc_xy_rotation) + 1) % 4
        self._redraw_cnc_axes()
        xaxis, yaxis, zaxis, label = self._get_cnc_axis_vectors()
        self.raise_action("save_xy_rotation", int(self._cnc_xy_rotation))
        self.set_status("CNC X/Y geroteerd en opgeslagen: {}".format(label))

    def on_reset_view(self, sender, args):
        self._cam_target = [0.0, 0.0, 0.0]
        self._cam_distance = 8.0
        self._cam_yaw = -18.0
        self._cam_pitch = 16.0
        self._cam_zoom = 3.2
        self.fit_camera()

    def on_nav_mouse_wheel(self, sender, args):
        try:
            delta = args.Delta
        except:
            return
        factor = 0.9 if delta > 0 else 1.1
        self._cam_zoom = max(0.4, min(20.0, self._cam_zoom * factor))
        self.fit_camera()
        try:
            args.Handled = True
        except:
            pass

    def on_nav_mouse_down(self, sender, args):
        try:
            import System
            mb = str(args.ChangedButton)
            self._last_mouse = args.GetPosition(self._nav_surface)
            mods = str(System.Windows.Input.Keyboard.Modifiers)
            self._drag_started = False
        except:
            return

        if mb == "Middle" and "Shift" in mods:
            self._mouse_mode = "orbit"
        elif mb == "Middle":
            self._mouse_mode = "pan"
        elif mb == "Right":
            self._mouse_mode = "orbit"
        else:
            return

        try:
            self._nav_surface.CaptureMouse()
            args.Handled = True
        except:
            pass

    def on_nav_mouse_move(self, sender, args):
        import math
        if not self._mouse_mode or self._last_mouse is None:
            return
        try:
            p = args.GetPosition(self._nav_surface)
        except:
            return

        dx = p.X - self._last_mouse.X
        dy = p.Y - self._last_mouse.Y
        self._last_mouse = p

        if abs(dx) > 2 or abs(dy) > 2:
            self._drag_started = True

        if self._mouse_mode == "orbit":
            self._cam_yaw += dx * 0.45
            self._cam_pitch -= dy * 0.45
            if self._cam_pitch > 89:
                self._cam_pitch = 89
            if self._cam_pitch < -89:
                self._cam_pitch = -89
            self.fit_camera()
        else:
            yaw = math.radians(float(self._cam_yaw))
            scale = self._cam_zoom * 0.0025
            right_x = math.cos(yaw)
            right_y = math.sin(yaw)
            self._cam_target[0] -= right_x * dx * scale
            self._cam_target[1] -= right_y * dx * scale
            self._cam_target[2] += dy * scale
            self.fit_camera()

        try:
            args.Handled = True
        except:
            pass

    def on_nav_mouse_up(self, sender, args):
        if self._mouse_mode:
            self._mouse_mode = None
            self._last_mouse = None
            try:
                self._nav_surface.ReleaseMouseCapture()
                args.Handled = True
            except:
                pass

    def _pick_origin_from_click(self, sender, args):
        if not self._payload or not self.PreviewViewport:
            return

        try:
            pos = args.GetPosition(self.PreviewViewport)
            click_x = float(pos.X)
            click_y = float(pos.Y)

            disp = self._payload["_display_vertices"]
            best_i = None
            best_d = None

            for i, v in enumerate(disp):
                proj = self._project_display_vertex_to_viewport(v)
                if proj is None:
                    continue
                dx = float(proj[0]) - click_x
                dy = float(proj[1]) - click_y
                # Prefer front-most when distances tie
                d = dx*dx + dy*dy + max(0.0, -float(proj[2])) * 0.0001
                if best_d is None or d < best_d:
                    best_d = d
                    best_i = i

            if best_i is None:
                return

            real_v = self._payload["vertices"][best_i]
            self._draw_origin_marker_from_real(real_v)
            self.raise_action("save_direct_origin", [
                float(real_v[0]),
                float(real_v[1]),
                float(real_v[2]),
                int(self._cnc_axes_rotation_index),
                int(self._cnc_xy_rotation)
            ])
            import storage
            self._origins = storage.load_origins(self.doc)
            self.update_selection_text()
            self.set_status("Origin gekozen op dichtstbijzijnde zichtbare hoek.")
        except:
            self.set_status("Origin kiezen mislukt.")

    def on_preview_click(self, sender, args):
        if self._drag_started:
            self._drag_started = False
            return
        self._pick_origin_from_click(sender, args)

    def ui_after_refresh(self):
        self.refresh_rows()

    def ui_after_preview(self, payload, msg):
        self.render(payload)
        self.update_selection_text()
        self.set_status(msg)

    def ui_after_pick_origin(self, msg):
        self.refresh_rows(self.get_selected_element_id_int())
        self.set_status(msg)

    def ui_after_clear_origin(self, msg, selected_id=None, remove_marker=True):
        if selected_id is None:
            selected_id = self.get_selected_element_id_int()
        self.refresh_rows(selected_id)
        if not remove_marker:
            self.set_status(msg)
            return
        if self._origin_model:
            try:
                self._root_group.Children.Remove(self._origin_model)
            except:
                pass
            self._origin_model = None
        if self._axis_model:
            try:
                self._root_group.Children.Remove(self._axis_model)
            except:
                pass
            self._axis_model = None
        self._origin_real_point = None
        self._cnc_xy_rotation = 0
        self.set_status(msg)

    def ui_after_show_in_revit(self, msg):
        self.set_status(msg)

    def ui_after_export(self, msg):
        self.set_status(msg)


def main():
    xaml = os.path.join(os.path.dirname(__file__), "ui.xaml")
    win = UI(xaml)
    win.show()


if __name__ == "__main__":
    main()
