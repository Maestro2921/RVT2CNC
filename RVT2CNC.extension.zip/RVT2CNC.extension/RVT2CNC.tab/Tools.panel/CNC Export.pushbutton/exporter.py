# -*- coding: utf-8 -*-
"""
CNC-ready exporter for Beam CNC Exporter.

Exports one .json and one .nc file for every beam that has an origin.
- .json = debug/data package
- .nc   = G-code style CNC output

IMPORTANT:
This is a configurable baseline. Check FEED rates, SAFE_Z, tool diameter,
postprocessor dialect and zero point with your CNC machine supplier before production.
"""

import clr
clr.AddReference("System")
clr.AddReference("System.Windows.Forms")
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

import os
import json
import math
import traceback

from Autodesk.Revit.DB import (
    FilteredElementCollector,
    BuiltInCategory,
    BuiltInParameter,
    FamilyInstance,
    LocationCurve,
    Options,
    ViewDetailLevel,
    Solid,
    GeometryInstance,
    XYZ,
    ElementId,
)

from pyrevit import forms, script
import storage
import tool_settings

logger = script.get_logger()


# -----------------------------
# CNC CONFIG - ADJUST IF NEEDED
# -----------------------------

UNITS = "MM"

# Safe travel height above stock/origin
SAFE_Z = 50.0

# Cutting/drilling bottom in normalized stock-thickness Z.
DEFAULT_CUT_DEPTH = 0.0

# Feeds
FEED_TRAVEL = 3000.0
FEED_PLUNGE = 250.0
FEED_CUT = 800.0

# Tool
TOOL_NUMBER = 1
TOOL_DIAMETER = 10.0

# Round pockets are exported as G1 line segments, not G2/G3 arcs.
# This makes the cutter visibly follow the circle contour on controllers that misread I/J arcs.
CIRCLE_SEGMENTS = 96

# Hole detection
MIN_HOLE_DIAMETER = 5.0
MAX_HOLE_DIAMETER = 1000.0

# If an opening axis is not perpendicular to the machining face / CNC XY plane,
# the exporter stops with an error instead of creating wrong G-code.
PERPENDICULAR_TOLERANCE_DEG = 2.0

# File extension
NC_EXT = ".nc"
CAM_JSON_SCHEMA = "prefab_cam_export_v1_exact_revit_geometry"
GENERIC_5X_WARNING = True
ROUND_VOID_FAMILY_NAME = "PrefabAnalyser_Void_Round"
RECT_VOID_FAMILY_NAME = "PrefabAnalyser_Void_Rect"



# CNC TOOL SETTINGS
CNC_SETTINGS_SECTION = "PrefabAnalyserCNC"

DEFAULT_TOOLS = [{
    "number": 1,
    "name": "Default end mill",
    "diameter": TOOL_DIAMETER,
    "spindle": 12000.0,
    "feed_cut": FEED_CUT,
    "feed_plunge": FEED_PLUNGE,
    "feed_travel": FEED_TRAVEL,
    "safe_z": SAFE_Z,
    "retract_z": 5.0
}]

def _tool_float(value, default_value):
    try:
        return float(str(value).replace(",", "."))
    except:
        return float(default_value)

def _tool_int(value, default_value):
    try:
        return int(float(str(value).replace(",", ".")))
    except:
        return int(default_value)

def get_saved_cnc_tools(doc=None):
    return tool_settings.load_tools(doc)

def get_active_tool_number(doc=None):
    return tool_settings.active_tool(doc)

def get_active_cnc_tool(doc=None):
    tools = get_saved_cnc_tools(doc)
    active = get_active_tool_number(doc)
    for t in tools:
        if _tool_int(t.get("number", 0), 0) == active:
            return t
    return tools[0] if tools else DEFAULT_TOOLS[0]

def get_cnc_runtime_config(doc=None):
    tool = get_active_cnc_tool(doc)
    return {
        "units": UNITS,
        "active_tool": {
            "number": _tool_int(tool.get("number", TOOL_NUMBER), TOOL_NUMBER),
            "name": str(tool.get("name", "Tool")),
            "diameter": _tool_float(tool.get("diameter", TOOL_DIAMETER), TOOL_DIAMETER),
            "spindle": _tool_float(tool.get("spindle", 12000.0), 12000.0),
            "feed_cut": _tool_float(tool.get("feed_cut", FEED_CUT), FEED_CUT),
            "feed_plunge": _tool_float(tool.get("feed_plunge", FEED_PLUNGE), FEED_PLUNGE),
            "feed_travel": _tool_float(tool.get("feed_travel", FEED_TRAVEL), FEED_TRAVEL),
            "safe_z": _tool_float(tool.get("safe_z", SAFE_Z), SAFE_Z),
            "retract_z": _tool_float(tool.get("retract_z", 5.0), 5.0)
        }
    }

# -----------------------------
# BASIC HELPERS
# -----------------------------

def eid_to_int(eid):
    if eid is None:
        return -1
    for attr in ("IntegerValue", "Value"):
        try:
            return int(getattr(eid, attr))
        except:
            pass
    try:
        return int(eid.ToString())
    except:
        pass
    try:
        s = str(eid)
        digits = "".join(ch for ch in s if ch in "0123456789-")
        if digits:
            return int(digits)
    except:
        pass
    return -1


def safe_name(txt):
    txt = str(txt or "").strip()
    if not txt:
        txt = "beam"
    bad = '\\/:*?"<>|'
    for ch in bad:
        txt = txt.replace(ch, "_")
    txt = txt.replace(" ", "_")
    return txt


def mm(ft):
    return float(ft) * 304.8


def get_mark(el):
    try:
        p = el.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)
        if p:
            s = p.AsString() or p.AsValueString()
            if s:
                return s
    except:
        pass
    try:
        p = el.LookupParameter("Mark")
        if p:
            s = p.AsString() or p.AsValueString()
            if s:
                return s
    except:
        pass
    return ""


def get_family(el, doc):
    try:
        if el.Symbol and el.Symbol.Family:
            return el.Symbol.Family.Name or ""
    except:
        pass
    try:
        t = doc.GetElement(el.GetTypeId())
        return getattr(t, "FamilyName", "") or ""
    except:
        pass
    return ""


def get_type_name(el):
    try:
        if el.Symbol:
            return el.Symbol.Name or ""
    except:
        pass
    try:
        return el.Name or ""
    except:
        pass
    return ""


def get_length_mm(el):
    try:
        loc = el.Location
        if isinstance(loc, LocationCurve) and loc.Curve:
            return round(mm(loc.Curve.Length), 3)
    except:
        pass
    return None


def make_output_folder(doc):
    try:
        title = safe_name(doc.Title)
    except:
        title = "Revit_Project"

    default_dir = os.path.join(os.path.expanduser("~"), "Desktop", "CNC_Export_{}".format(title))
    if not os.path.exists(default_dir):
        try:
            os.makedirs(default_dir)
        except:
            pass

    # Use native Windows dialog because pyRevit forms.pick_folder can fail inside ExternalEvent.
    outdir = None
    try:
        from System.Windows.Forms import FolderBrowserDialog, DialogResult
        dlg = FolderBrowserDialog()
        dlg.Description = "Kies exportmap voor CNC bestanden"
        dlg.SelectedPath = default_dir
        dlg.ShowNewFolderButton = True

        result = dlg.ShowDialog()
        if result == DialogResult.OK and dlg.SelectedPath:
            outdir = str(dlg.SelectedPath)
    except:
        outdir = None

    # If the dialog was cancelled, stop export without throwing an error.
    if not outdir:
        return None

    if not os.path.exists(outdir):
        os.makedirs(outdir)

    return outdir

def collect_export_beams(doc):
    try:
        els = (FilteredElementCollector(doc)
               .OfCategory(BuiltInCategory.OST_StructuralFraming)
               .WhereElementIsNotElementType()
               .ToElements())
    except:
        els = []

    beams = []
    for el in els:
        try:
            if isinstance(el, FamilyInstance):
                beams.append(el)
        except:
            pass
    return beams


def get_solid_geometry(el):
    opts = Options()
    opts.DetailLevel = ViewDetailLevel.Fine
    try:
        opts.IncludeNonVisibleObjects = True
    except:
        pass

    solids = []
    try:
        geom = el.get_Geometry(opts)
    except:
        geom = None

    if geom is None:
        return solids

    for obj in geom:
        try:
            if isinstance(obj, Solid):
                try:
                    if obj.Volume > 0:
                        solids.append(obj)
                except:
                    solids.append(obj)
            elif isinstance(obj, GeometryInstance):
                try:
                    inst_geom = obj.GetInstanceGeometry()
                    for inst_obj in inst_geom:
                        if isinstance(inst_obj, Solid):
                            try:
                                if inst_obj.Volume > 0:
                                    solids.append(inst_obj)
                            except:
                                solids.append(inst_obj)
                except:
                    pass
        except:
            pass

    return solids


def triangulate_solids(solids):
    verts = []
    tris = []
    vmap = {}

    def add_vertex(xyz):
        key = (round(float(xyz.X), 6), round(float(xyz.Y), 6), round(float(xyz.Z), 6))
        if key not in vmap:
            vmap[key] = len(verts)
            verts.append([key[0], key[1], key[2]])
        return vmap[key]

    for solid in solids:
        try:
            for face in solid.Faces:
                mesh = face.Triangulate()
                for i in range(mesh.NumTriangles):
                    tri = mesh.get_Triangle(i)
                    a = add_vertex(tri.get_Vertex(0))
                    b = add_vertex(tri.get_Vertex(1))
                    c = add_vertex(tri.get_Vertex(2))
                    tris.append([a, b, c])
        except:
            pass

    return verts, tris


def get_axis_index(origin):
    try:
        return int(origin.get("axis_index", 0)) % 6
    except:
        return 0


def _axis_name(v):
    names = ["Revit X", "Revit Y", "Revit Z"]
    vals = [float(v[0]), float(v[1]), float(v[2])]
    idx = max(range(3), key=lambda i: abs(vals[i]))
    return names[idx] if vals[idx] >= 0 else "-" + names[idx]


def _mul_vec(v, scalar):
    return [float(v[0]) * scalar, float(v[1]) * scalar, float(v[2]) * scalar]


def get_cnc_axis_vectors(axis_index, xy_rotation=0):
    idx = int(axis_index) % 6

    if idx == 0:
        xaxis, yaxis, zaxis, label = [1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0], "CNC Z = Revit Z"
    elif idx == 1:
        xaxis, yaxis, zaxis, label = [1.0, 0.0, 0.0], [0.0, 0.0, -1.0], [0.0, 1.0, 0.0], "CNC Z = Revit Y"
    elif idx == 2:
        xaxis, yaxis, zaxis, label = [1.0, 0.0, 0.0], [0.0, -1.0, 0.0], [0.0, 0.0, -1.0], "CNC Z = -Revit Z"
    elif idx == 3:
        xaxis, yaxis, zaxis, label = [1.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, -1.0, 0.0], "CNC Z = -Revit Y"
    elif idx == 4:
        xaxis, yaxis, zaxis, label = [0.0, 1.0, 0.0], [0.0, 0.0, 1.0], [1.0, 0.0, 0.0], "CNC Z = Revit X"
    else:
        xaxis, yaxis, zaxis, label = [0.0, 1.0, 0.0], [0.0, 0.0, -1.0], [-1.0, 0.0, 0.0], "CNC Z = -Revit X"

    try:
        xy_rotation = int(xy_rotation) % 4
    except:
        xy_rotation = 0

    if xy_rotation == 1:
        xaxis, yaxis = yaxis, _mul_vec(xaxis, -1.0)
    elif xy_rotation == 2:
        xaxis, yaxis = _mul_vec(xaxis, -1.0), _mul_vec(yaxis, -1.0)
    elif xy_rotation == 3:
        xaxis, yaxis = _mul_vec(yaxis, -1.0), xaxis

    label = "{} | X={} | Y={}".format(label, _axis_name(xaxis), _axis_name(yaxis))

    return xaxis, yaxis, zaxis, label


def auto_cnc_axis_index(vertices_ft, origin_ft):
    if not vertices_ft or not origin_ft:
        return 0

    ranges = []
    for name, pos_idx, neg_idx, coord_idx in [
        ("X", 4, 5, 0),
        ("Y", 1, 3, 1),
        ("Z", 0, 2, 2),
    ]:
        vals = [float(v[coord_idx]) for v in vertices_ft]
        ranges.append((max(vals) - min(vals), name, pos_idx, neg_idx, coord_idx))

    ranges.sort(key=lambda item: item[0])
    dim, name, pos_idx, neg_idx, coord_idx = ranges[0]

    rel_vals = [float(v[coord_idx]) - float(origin_ft[coord_idx]) for v in vertices_ft]
    min_rel = min(rel_vals)
    max_rel = max(rel_vals)

    # Pick the sign that makes the stock depth negative from the selected origin.
    if abs(max_rel) <= abs(min_rel):
        return pos_idx
    return neg_idx


def _axis_dot(a, b):
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def point_to_cnc_mm(point_ft, origin_ft, axis_index, xy_rotation=0):
    xaxis, yaxis, zaxis, label = get_cnc_axis_vectors(axis_index, xy_rotation)
    rel = [
        float(point_ft[0]) - float(origin_ft[0]),
        float(point_ft[1]) - float(origin_ft[1]),
        float(point_ft[2]) - float(origin_ft[2])
    ]
    return [
        mm(_axis_dot(rel, xaxis)),
        mm(_axis_dot(rel, yaxis)),
        mm(_axis_dot(rel, zaxis))
    ]


def vector_to_cnc(vector, axis_index, xy_rotation=0):
    xaxis, yaxis, zaxis, label = get_cnc_axis_vectors(axis_index, xy_rotation)
    return [
        _axis_dot(vector, xaxis),
        _axis_dot(vector, yaxis),
        _axis_dot(vector, zaxis)
    ]


def bbox_from_vertices_mm(vertices_ft, origin_ft, axis_index=0, xy_rotation=0):
    if not vertices_ft:
        return None

    pts = []
    for v in vertices_ft:
        pts.append(point_to_cnc_mm(v, origin_ft, axis_index, xy_rotation))

    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    zs = [p[2] for p in pts]

    return {
        "min_x": min(xs),
        "max_x": max(xs),
        "min_y": min(ys),
        "max_y": max(ys),
        "min_z": min(zs),
        "max_z": max(zs),
        "length_x": max(xs) - min(xs),
        "width_y": max(ys) - min(ys),
        "height_z": max(zs) - min(zs)
    }


def apply_z_output_offset_to_bbox(bbox, z_offset):
    if not bbox:
        return bbox

    shifted = {}
    for key in bbox:
        shifted[key] = bbox[key]

    for key in ["min_z", "max_z"]:
        try:
            shifted[key] = float(shifted.get(key, 0.0)) + float(z_offset)
        except:
            pass

    try:
        shifted["height_z"] = float(shifted.get("max_z", 0.0)) - float(shifted.get("min_z", 0.0))
    except:
        pass

    return shifted


def apply_z_output_offset_to_items(items, z_offset):
    for item in items or []:
        for key in ["z", "min_z", "max_z"]:
            if key in item:
                try:
                    item[key] = round(float(item[key]) + float(z_offset), 3)
                except:
                    pass


# -----------------------------
# HOLE DETECTION
# -----------------------------

def get_face_vertices(face):
    pts = []
    try:
        mesh = face.Triangulate()
        for i in range(mesh.NumTriangles):
            tri = mesh.get_Triangle(i)
            for j in range(3):
                v = tri.get_Vertex(j)
                key = (round(float(v.X), 6), round(float(v.Y), 6), round(float(v.Z), 6))
                if key not in pts:
                    pts.append(key)
    except:
        pass
    return pts


def try_get_cylindrical_face_data(face):
    """
    Best effort detection of cylindrical/round cut faces.
    Revit API face classes vary by version, so this uses duck typing.
    """
    radius = None
    origin = None
    axis = None

    # Common cylindrical face properties
    for attr in ["Radius", "radius"]:
        try:
            radius = float(getattr(face, attr))
            break
        except:
            pass

    for attr in ["Origin", "origin"]:
        try:
            o = getattr(face, attr)
            origin = [float(o.X), float(o.Y), float(o.Z)]
            break
        except:
            pass

    for attr in ["Axis", "axis"]:
        try:
            a = getattr(face, attr)
            axis = [float(a.X), float(a.Y), float(a.Z)]
            break
        except:
            pass

    # Fallback: if Radius exists but no origin/axis, estimate center from face mesh
    if radius is not None:
        pts = get_face_vertices(face)
        if pts and origin is None:
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            zs = [p[2] for p in pts]
            origin = [
                (min(xs) + max(xs)) / 2.0,
                (min(ys) + max(ys)) / 2.0,
                (min(zs) + max(zs)) / 2.0
            ]

        if axis is None:
            # Default unknown axis. CNC output will still include the hole center.
            axis = [0.0, 0.0, 1.0]

        return {
            "center_ft": origin,
            "axis": axis,
            "radius_ft": radius,
            "diameter_mm": mm(radius * 2.0)
        }

    return None


def detect_round_holes(solids, origin_ft, axis_index=0, xy_rotation=0):
    """
    Detect cylindrical faces and return de-duplicated hole centers.
    This works for many round voids/openings, but machine verification is still required.
    """
    holes = []
    seen = set()

    for solid in solids:
        try:
            faces = solid.Faces
        except:
            continue

        for face in faces:
            data = try_get_cylindrical_face_data(face)
            if not data:
                continue

            dia = data.get("diameter_mm", 0.0)
            if dia < MIN_HOLE_DIAMETER or dia > MAX_HOLE_DIAMETER:
                continue

            c = data.get("center_ft")
            if not c:
                continue

            cx, cy, cz = point_to_cnc_mm(c, origin_ft, axis_index, xy_rotation)

            # Dedupe by approximate center + diameter
            key = (round(cx, 1), round(cy, 1), round(cz, 1), round(dia, 1))
            if key in seen:
                continue
            seen.add(key)

            holes.append({
                "x": round(cx, 3),
                "y": round(cy, 3),
                "z": round(cz, 3),
                "diameter": round(dia, 3),
                "axis": vector_to_cnc(data.get("axis", [0.0, 0.0, 1.0]), axis_index, xy_rotation),
                "type": "round_hole_detected"
            })

    return holes



def _sub(a, b):
    return [a[0]-b[0], a[1]-b[1], a[2]-b[2]]


def _dot(a, b):
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def _cross(a, b):
    return [
        a[1]*b[2] - a[2]*b[1],
        a[2]*b[0] - a[0]*b[2],
        a[0]*b[1] - a[1]*b[0],
    ]


def _len(a):
    return math.sqrt(max(1e-12, _dot(a, a)))


def _norm(a):
    l = _len(a)
    return [a[0]/l, a[1]/l, a[2]/l]


def _dist(a, b):
    return _len(_sub(a, b))


def _avg(points):
    n = float(len(points))
    return [
        sum(p[0] for p in points) / n,
        sum(p[1] for p in points) / n,
        sum(p[2] for p in points) / n,
    ]


def _principal_axis_from_points(points):
    """
    Lightweight PCA fallback for hole boundary points.
    Returns normal-ish axis of the best-fit plane.
    """
    if len(points) < 3:
        return [0.0, 0.0, 1.0]

    c = _avg(points)
    # Pick two far points to approximate plane directions
    p0 = max(points, key=lambda p: _dist(p, c))
    p1 = max(points, key=lambda p: _dist(p, p0))
    u = _norm(_sub(p1, p0))

    # point farthest from line p0-p1
    def line_dist(p):
        v = _sub(p, p0)
        proj = _dot(v, u)
        q = [p0[0] + u[0]*proj, p0[1] + u[1]*proj, p0[2] + u[2]*proj]
        return _dist(p, q)

    p2 = max(points, key=line_dist)
    v = _norm(_sub(p2, p0))
    n = _cross(u, v)
    if _len(n) < 1e-9:
        return [0.0, 0.0, 1.0]
    return _norm(n)


def detect_holes_from_mesh_edges(vertices_ft, triangles, origin_ft):
    """
    Detecteert ronde openingen via boundary/crease edges in de triangulated mesh.

    Waarom:
    Revit geeft bij family void cuts niet altijd herkenbare cylindrical faces terug.
    De gat-opening verschijnt wel als ring/rand in de mesh. Deze functie zoekt zulke
    ringen en zet ze om naar centers + diameter.
    """
    if not vertices_ft or not triangles:
        return []

    edge_count = {}
    for tri in triangles:
        for a, b in [(tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0])]:
            if a > b:
                a, b = b, a
            edge_count[(a, b)] = edge_count.get((a, b), 0) + 1

    # Boundary edges are ideal. If cuts are closed/manifold, still use short crease-like edges
    # by starting with edges shared once.
    boundary_edges = [e for e, c in edge_count.items() if c == 1]

    if not boundary_edges:
        return []

    adjacency = {}
    for a, b in boundary_edges:
        adjacency.setdefault(a, set()).add(b)
        adjacency.setdefault(b, set()).add(a)

    visited = set()
    loops = []

    for start in adjacency.keys():
        if start in visited:
            continue

        stack = [start]
        comp = set()
        visited.add(start)

        while stack:
            cur = stack.pop()
            comp.add(cur)
            for nb in adjacency.get(cur, []):
                if nb not in visited:
                    visited.add(nb)
                    stack.append(nb)

        if len(comp) >= 8:
            loops.append(list(comp))

    holes = []
    seen = set()

    for comp in loops:
        pts = [vertices_ft[i] for i in comp]
        if len(pts) < 8:
            continue

        c = _avg(pts)
        ds = [_dist(p, c) for p in pts]
        r_avg = sum(ds) / float(len(ds))
        if r_avg <= 0:
            continue

        dia_mm = mm(2.0 * r_avg)
        if dia_mm < MIN_HOLE_DIAMETER or dia_mm > MAX_HOLE_DIAMETER:
            continue

        # Roundness check: skip rectangular/irregular boundaries
        r_min = min(ds)
        r_max = max(ds)
        if r_min <= 0:
            continue
        roundness = r_max / r_min
        if roundness > 1.35:
            continue

        # Also skip huge outer boundary loops by requiring a reasonable point count/diameter.
        axis = _principal_axis_from_points(pts)

        cx = mm(c[0] - origin_ft[0])
        cy = mm(c[1] - origin_ft[1])
        cz = mm(c[2] - origin_ft[2])

        key = (round(cx, 1), round(cy, 1), round(cz, 1), round(dia_mm, 1))
        if key in seen:
            continue
        seen.add(key)

        holes.append({
            "x": round(cx, 3),
            "y": round(cy, 3),
            "z": round(cz, 3),
            "diameter": round(dia_mm, 3),
            "axis": axis,
            "type": "round_hole_mesh_edge_detected"
        })

    return holes


def merge_hole_lists(primary, secondary):
    result = []
    seen = set()

    for h in list(primary or []) + list(secondary or []):
        key = (
            round(float(h.get("x", 0.0)), 1),
            round(float(h.get("y", 0.0)), 1),
            round(float(h.get("diameter", 0.0)), 1),
        )
        if key in seen:
            continue
        seen.add(key)
        result.append(h)

    return result


def merge_opening_lists(primary, secondary):
    result = []
    seen = set()

    for op in list(primary or []) + list(secondary or []):
        key = (
            round(float(op.get("x", 0.0)), 1),
            round(float(op.get("y", 0.0)), 1),
            round(float(op.get("width", 0.0)), 1),
            round(float(op.get("height", 0.0)), 1),
        )
        if key in seen:
            continue
        seen.add(key)
        result.append(op)

    return result


def get_param(elem, name):
    try:
        p = elem.LookupParameter(name)
        if p:
            return p
    except:
        pass

    try:
        if hasattr(elem, "Symbol") and elem.Symbol:
            return elem.Symbol.LookupParameter(name)
    except:
        pass

    return None


def get_param_string(elem, name):
    p = get_param(elem, name)
    if not p:
        return ""

    try:
        val = p.AsString()
        if val:
            return str(val)
    except:
        pass

    try:
        val = p.AsValueString()
        if val:
            return str(val)
    except:
        pass

    try:
        return str(p.AsInteger())
    except:
        pass

    try:
        return str(int(p.AsDouble()))
    except:
        pass

    return ""


def get_param_double(elem, name, default=0.0):
    p = get_param(elem, name)
    if not p:
        return default

    try:
        return float(p.AsDouble())
    except:
        return default


def parse_int_text(value):
    try:
        return int(float(str(value).strip()))
    except:
        pass

    try:
        digits = "".join(ch for ch in str(value) if ch in "0123456789-")
        if digits:
            return int(digits)
    except:
        pass

    return None


def get_location_point_ft(elem):
    try:
        loc = elem.Location
        if hasattr(loc, "Point") and loc.Point:
            p = loc.Point
            return [float(p.X), float(p.Y), float(p.Z)]
    except:
        pass

    try:
        bb = elem.get_BoundingBox(None)
        if bb:
            return [
                (float(bb.Min.X) + float(bb.Max.X)) / 2.0,
                (float(bb.Min.Y) + float(bb.Max.Y)) / 2.0,
                (float(bb.Min.Z) + float(bb.Max.Z)) / 2.0
            ]
    except:
        pass

    return None


def bbox_corners_ft(bb):
    if not bb:
        return []

    mn = bb.Min
    mx = bb.Max
    return [
        [mn.X, mn.Y, mn.Z],
        [mx.X, mn.Y, mn.Z],
        [mx.X, mx.Y, mn.Z],
        [mn.X, mx.Y, mn.Z],
        [mn.X, mn.Y, mx.Z],
        [mx.X, mn.Y, mx.Z],
        [mx.X, mx.Y, mx.Z],
        [mn.X, mx.Y, mx.Z],
    ]


def bbox_intersects(a, b, margin=0.01):
    if not a or not b:
        return False

    try:
        return (
            float(a.Min.X) <= float(b.Max.X) + margin and float(a.Max.X) + margin >= float(b.Min.X) and
            float(a.Min.Y) <= float(b.Max.Y) + margin and float(a.Max.Y) + margin >= float(b.Min.Y) and
            float(a.Min.Z) <= float(b.Max.Z) + margin and float(a.Max.Z) + margin >= float(b.Min.Z)
        )
    except:
        return False


def collect_prefab_voids_for_beam(doc, beam, origin_ft, axis_index, xy_rotation, stock_bbox):
    beam_id = eid_to_int(beam.Id)
    holes = []
    openings = []

    try:
        voids = (FilteredElementCollector(doc)
                 .OfClass(FamilyInstance)
                 .WhereElementIsNotElementType()
                 .ToElements())
    except:
        return holes, openings

    stock_x = abs(float((stock_bbox or {}).get("length_x", 0.0)))
    stock_y = abs(float((stock_bbox or {}).get("width_y", 0.0)))

    try:
        beam_bb = beam.get_BoundingBox(None)
    except:
        beam_bb = None

    for inst in voids:
        fam = get_family(inst, doc)
        is_round_void = fam == ROUND_VOID_FAMILY_NAME or str(fam).startswith(ROUND_VOID_FAMILY_NAME)
        is_rect_void = fam == RECT_VOID_FAMILY_NAME or str(fam).startswith(RECT_VOID_FAMILY_NAME)
        if not is_round_void and not is_rect_void:
            continue

        try:
            void_bb = inst.get_BoundingBox(None)
        except:
            void_bb = None

        source_host = parse_int_text(get_param_string(inst, "SourceHostId"))
        if source_host is not None:
            if int(source_host) != int(beam_id) and not bbox_intersects(beam_bb, void_bb):
                continue
        else:
            if not bbox_intersects(beam_bb, void_bb):
                continue

        center_ft = get_location_point_ft(inst)
        if not center_ft:
            continue

        cx, cy, cz = point_to_cnc_mm(center_ft, origin_ft, axis_index, xy_rotation)
        clearance_ft = get_param_double(inst, "Clearance", 0.0)

        if is_round_void:
            host_diameter_ft = get_param_double(inst, "HostDiameter", 0.0)
            dia_mm = mm(host_diameter_ft + 2.0 * clearance_ft)
            if dia_mm < MIN_HOLE_DIAMETER or dia_mm > MAX_HOLE_DIAMETER:
                continue

            holes.append({
                "x": round(cx, 3),
                "y": round(cy, 3),
                "z": round(cz, 3),
                "diameter": round(dia_mm, 3),
                "axis": [0.0, 0.0, 1.0],
                "type": "round_hole_prefab_void_family"
            })
            continue

        host_width_ft = get_param_double(inst, "HostWidth", 0.0)
        host_height_ft = get_param_double(inst, "HostHeight", 0.0)
        width_mm = mm(host_width_ft + 2.0 * clearance_ft)
        height_mm = mm(host_height_ft + 2.0 * clearance_ft)

        # Prefer the actual instance bounding box projection when it gives a sane profile.
        try:
            local_pts = [point_to_cnc_mm(p, origin_ft, axis_index, xy_rotation) for p in bbox_corners_ft(void_bb)]
            if local_pts:
                pbb = _bbox_from_points(local_pts)
                bx = abs(pbb["width_x"])
                by = abs(pbb["height_y"])
                if bx >= MIN_HOLE_DIAMETER and by >= MIN_HOLE_DIAMETER:
                    if (stock_x <= 0 or bx <= stock_x * 1.05) and (stock_y <= 0 or by <= stock_y * 1.05):
                        width_mm = bx
                        height_mm = by
        except:
            pass

        if width_mm < MIN_HOLE_DIAMETER or height_mm < MIN_HOLE_DIAMETER:
            continue

        min_x = cx - (width_mm / 2.0)
        max_x = cx + (width_mm / 2.0)
        min_y = cy - (height_mm / 2.0)
        max_y = cy + (height_mm / 2.0)

        openings.append({
            "x": round(cx, 3),
            "y": round(cy, 3),
            "z": round(cz, 3),
            "min_x": round(min_x, 3),
            "max_x": round(max_x, 3),
            "min_y": round(min_y, 3),
            "max_y": round(max_y, 3),
            "width": round(width_mm, 3),
            "height": round(height_mm, 3),
            "type": "rectangular_void_prefab_void_family"
        })

    return holes, openings


def _triangle_normal(vertices, tri):
    try:
        p0 = vertices[tri[0]]
        p1 = vertices[tri[1]]
        p2 = vertices[tri[2]]
        return _norm(_cross(_sub(p1, p0), _sub(p2, p0)))
    except:
        return [0.0, 0.0, 1.0]


def _bbox_from_points(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    zs = [p[2] for p in points]
    return {
        "min_x": min(xs),
        "max_x": max(xs),
        "min_y": min(ys),
        "max_y": max(ys),
        "min_z": min(zs),
        "max_z": max(zs),
        "width_x": max(xs) - min(xs),
        "height_y": max(ys) - min(ys),
        "depth_z": max(zs) - min(zs)
    }


def detect_voids_from_mesh_creases(vertices_ft, triangles, origin_ft, axis_index, stock_bbox, xy_rotation=0):
    """
    Detect round and rectangular/non-round voids from crease edges.
    Boundary edges alone miss many Revit family void cuts because those cuts are
    often closed/manifold geometry. Crease edges catch the sharp edge between
    beam faces and opening faces.
    """
    if not vertices_ft or not triangles:
        return [], []

    tri_normals = []
    edge_faces = {}

    for i, tri in enumerate(triangles):
        tri_normals.append(_triangle_normal(vertices_ft, tri))
        for a, b in [(tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0])]:
            if a > b:
                a, b = b, a
            edge_faces.setdefault((a, b), []).append(i)

    crease_edges = []
    crease_limit = math.cos(math.radians(35.0))

    for edge, faces in edge_faces.items():
        if len(faces) == 1:
            crease_edges.append(edge)
        elif len(faces) == 2:
            n1 = tri_normals[faces[0]]
            n2 = tri_normals[faces[1]]
            if abs(_dot(n1, n2)) < crease_limit:
                crease_edges.append(edge)

    if not crease_edges:
        return [], []

    adjacency = {}
    for a, b in crease_edges:
        adjacency.setdefault(a, set()).add(b)
        adjacency.setdefault(b, set()).add(a)

    visited = set()
    components = []

    for start in adjacency.keys():
        if start in visited:
            continue

        stack = [start]
        comp = set()
        visited.add(start)

        while stack:
            cur = stack.pop()
            comp.add(cur)
            for nb in adjacency.get(cur, []):
                if nb not in visited:
                    visited.add(nb)
                    stack.append(nb)

        if len(comp) >= 4:
            components.append(list(comp))

    holes = []
    openings = []
    seen = set()

    stock_x = abs(float((stock_bbox or {}).get("length_x", 0.0)))
    stock_y = abs(float((stock_bbox or {}).get("width_y", 0.0)))

    for comp in components:
        local_pts = [point_to_cnc_mm(vertices_ft[i], origin_ft, axis_index, xy_rotation) for i in comp]
        if len(local_pts) < 4:
            continue

        bb = _bbox_from_points(local_pts)
        dx = abs(bb["width_x"])
        dy = abs(bb["height_y"])

        if dx < MIN_HOLE_DIAMETER or dy < MIN_HOLE_DIAMETER:
            continue

        # Skip the outside beam outline. Voids should be clearly smaller than stock.
        if stock_x > 0 and stock_y > 0:
            if dx > stock_x * 0.85 and dy > stock_y * 0.85:
                continue
            if dx > stock_x * 1.05 or dy > stock_y * 1.05:
                continue

        cx = (bb["min_x"] + bb["max_x"]) / 2.0
        cy = (bb["min_y"] + bb["max_y"]) / 2.0
        cz = (bb["min_z"] + bb["max_z"]) / 2.0

        key = (round(cx, 1), round(cy, 1), round(dx, 1), round(dy, 1))
        if key in seen:
            continue
        seen.add(key)

        ds = []
        for p in local_pts:
            ds.append(math.sqrt((p[0] - cx) * (p[0] - cx) + (p[1] - cy) * (p[1] - cy)))

        r_min = min(ds) if ds else 0.0
        r_max = max(ds) if ds else 0.0
        roundish = False
        if r_min > 0:
            roundish = len(local_pts) >= 8 and (r_max / r_min) <= 1.30 and abs(dx - dy) <= max(dx, dy) * 0.20

        if roundish:
            dia = (dx + dy) / 2.0
            holes.append({
                "x": round(cx, 3),
                "y": round(cy, 3),
                "z": round(cz, 3),
                "diameter": round(dia, 3),
                "axis": [0.0, 0.0, 1.0],
                "type": "round_hole_mesh_crease_detected"
            })
        else:
            openings.append({
                "x": round(cx, 3),
                "y": round(cy, 3),
                "z": round(cz, 3),
                "min_x": round(bb["min_x"], 3),
                "max_x": round(bb["max_x"], 3),
                "min_y": round(bb["min_y"], 3),
                "max_y": round(bb["max_y"], 3),
                "width": round(dx, 3),
                "height": round(dy, 3),
                "type": "rectangular_or_nonround_void_mesh_crease_detected"
            })

    return holes, openings




# -----------------------------
# NEUTRAL CAM EXPORT HELPERS
# -----------------------------

def get_element_by_int_id(doc, int_id):
    try:
        return doc.GetElement(ElementId(int(int_id)))
    except:
        return None


def xyz_to_list(p):
    try:
        return [float(p.X), float(p.Y), float(p.Z)]
    except:
        try:
            return [float(p[0]), float(p[1]), float(p[2])]
        except:
            return [0.0, 0.0, 0.0]


def get_location_curve_axis_ft(elem):
    try:
        loc = elem.Location
        if isinstance(loc, LocationCurve) and loc.Curve:
            p0 = loc.Curve.GetEndPoint(0)
            p1 = loc.Curve.GetEndPoint(1)
            return _norm([float(p1.X - p0.X), float(p1.Y - p0.Y), float(p1.Z - p0.Z)])
    except:
        pass
    return None


def get_element_mesh_package(elem):
    solids = get_solid_geometry(elem)
    verts, tris = triangulate_solids(solids)
    return {
        "vertices_ft": verts,
        "triangles": tris,
        "solid_count": len(solids)
    }


def get_instance_transform_package(inst):
    try:
        tr = inst.GetTransform()
        return {
            "origin_ft": xyz_to_list(tr.Origin),
            "basis_x": xyz_to_list(tr.BasisX),
            "basis_y": xyz_to_list(tr.BasisY),
            "basis_z": xyz_to_list(tr.BasisZ)
        }
    except:
        return None


def bbox_package(elem):
    try:
        bb = elem.get_BoundingBox(None)
        if not bb:
            return None
        return {
            "min_ft": xyz_to_list(bb.Min),
            "max_ft": xyz_to_list(bb.Max),
            "center_ft": [
                (float(bb.Min.X) + float(bb.Max.X)) / 2.0,
                (float(bb.Min.Y) + float(bb.Max.Y)) / 2.0,
                (float(bb.Min.Z) + float(bb.Max.Z)) / 2.0,
            ],
            "size_mm": [
                mm(float(bb.Max.X) - float(bb.Min.X)),
                mm(float(bb.Max.Y) - float(bb.Min.Y)),
                mm(float(bb.Max.Z) - float(bb.Min.Z)),
            ]
        }
    except:
        return None


def collect_explicit_prefab_voids_for_beam_cam(doc, beam):
    """
    Returns exact Revit data for PrefabAnalyser void family instances.

    Important:
    This does not replace CAM. It exports the actual Revit mesh + parameters so
    CAM/postprocessor software can compute the true stock/void boolean and real
    3D contours instead of guessing from a bounding box.
    """
    beam_id = eid_to_int(beam.Id)
    result = []

    try:
        beam_bb = beam.get_BoundingBox(None)
    except:
        beam_bb = None

    try:
        voids = (FilteredElementCollector(doc)
                 .OfClass(FamilyInstance)
                 .WhereElementIsNotElementType()
                 .ToElements())
    except:
        return result

    for inst in voids:
        fam = get_family(inst, doc)
        is_round_void = fam == ROUND_VOID_FAMILY_NAME or str(fam).startswith(ROUND_VOID_FAMILY_NAME)
        is_rect_void = fam == RECT_VOID_FAMILY_NAME or str(fam).startswith(RECT_VOID_FAMILY_NAME)
        if not is_round_void and not is_rect_void:
            continue

        try:
            void_bb = inst.get_BoundingBox(None)
        except:
            void_bb = None

        source_host = parse_int_text(get_param_string(inst, "SourceHostId"))
        if source_host is not None:
            if int(source_host) != int(beam_id) and not bbox_intersects(beam_bb, void_bb):
                continue
        else:
            if not bbox_intersects(beam_bb, void_bb):
                continue

        source_mep = parse_int_text(get_param_string(inst, "SourceMEPId"))
        mep_elem = get_element_by_int_id(doc, source_mep) if source_mep is not None else None
        mep_axis_ft = get_location_curve_axis_ft(mep_elem) if mep_elem else None

        center_ft = get_location_point_ft(inst)
        clearance_ft = get_param_double(inst, "Clearance", 0.0)

        void_data = {
            "void_element_id": eid_to_int(inst.Id),
            "family": fam,
            "type": get_type_name(inst),
            "kind": "round" if is_round_void else "rectangular",
            "source_host_id": source_host,
            "source_mep_id": source_mep,
            "center_ft": center_ft,
            "center_mm_from_revit_origin": [mm(center_ft[0]), mm(center_ft[1]), mm(center_ft[2])] if center_ft else None,
            "mep_axis_ft": mep_axis_ft,
            "mep_axis_cnc_hint": mep_axis_ft,
            "clearance_mm": round(mm(clearance_ft), 6),
            "bbox": bbox_package(inst),
            "transform": get_instance_transform_package(inst),
            "mesh": get_element_mesh_package(inst),
            "parameters": {}
        }

        if is_round_void:
            host_diameter_ft = get_param_double(inst, "HostDiameter", 0.0)
            depth_ft = get_param_double(inst, "Depth", 0.0)
            void_data["parameters"] = {
                "host_diameter_mm": round(mm(host_diameter_ft), 6),
                "clearance_mm": round(mm(clearance_ft), 6),
                "final_diameter_mm": round(mm(host_diameter_ft + 2.0 * clearance_ft), 6),
                "depth_mm": round(mm(depth_ft), 6)
            }
        else:
            host_width_ft = get_param_double(inst, "HostWidth", 0.0)
            host_height_ft = get_param_double(inst, "HostHeight", 0.0)
            depth_ft = get_param_double(inst, "Depth", 0.0)
            void_data["parameters"] = {
                "host_width_mm": round(mm(host_width_ft), 6),
                "host_height_mm": round(mm(host_height_ft), 6),
                "clearance_mm": round(mm(clearance_ft), 6),
                "final_width_mm": round(mm(host_width_ft + 2.0 * clearance_ft), 6),
                "final_height_mm": round(mm(host_height_ft + 2.0 * clearance_ft), 6),
                "depth_mm": round(mm(depth_ft), 6)
            }

        result.append(void_data)

    return result


def build_neutral_cam_data(doc, el, origin, beam_data):
    """
    Neutral CAM package:
    - stock mesh from the actual Revit beam
    - explicit void family meshes
    - MEP axis direction
    - tool settings
    - zero point
    """
    origin_ft = [float(origin["x"]), float(origin["y"]), float(origin["z"])]

    try:
        xy_rotation = int(origin.get("xy_rotation", 1 if origin.get("xy_swapped", False) else 0)) % 4
    except:
        xy_rotation = 0

    axis_index = beam_data.get("axis_index", 0)

    stock_mesh = {
        "vertices_ft": beam_data.get("mesh", {}).get("vertices_ft", []),
        "triangles": beam_data.get("mesh", {}).get("triangles", [])
    }

    openings = collect_explicit_prefab_voids_for_beam_cam(doc, el)

    return {
        "schema": CAM_JSON_SCHEMA,
        "units": {
            "revit_internal": "feet",
            "cam_output": "millimeter"
        },
        "beam": {
            "element_id": eid_to_int(el.Id),
            "mark": get_mark(el),
            "family": get_family(el, doc),
            "type": get_type_name(el),
            "length_mm": get_length_mm(el),
            "bbox": bbox_package(el),
            "stock_mesh": stock_mesh
        },
        "zero": {
            "description": "Selected Revit origin",
            "origin_ft": origin_ft,
            "origin_cnc_mm": beam_data.get("origin_cnc_mm"),
            "axis_index": axis_index,
            "xy_rotation": xy_rotation,
            "axis_label": beam_data.get("axis_label", "")
        },
        "openings": openings,
        "tooling": beam_data.get("cnc_config", {}),
        "postprocessor": {
            "status": "generic_5axis_placeholder",
            "warning": "Machine/controller-specific postprocessor is still required for production.",
            "required_from_user": [
                "controller",
                "allowed_gcodes",
                "5_axis_format_ABC_or_IJK",
                "TCP_RTCP_mode",
                "zero_point_convention",
                "machining_side"
            ]
        }
    }


def axis_to_generic_abc(axis):
    """
    Generic placeholder only.
    A = tilt around X, C = rotation around Z.
    Real mapping depends on machine kinematics.
    """
    try:
        a = _norm([float(axis[0]), float(axis[1]), float(axis[2])])
        tilt = math.degrees(math.acos(max(-1.0, min(1.0, a[2]))))
        rotz = math.degrees(math.atan2(a[1], a[0]))
        return tilt, 0.0, rotz
    except:
        return 0.0, 0.0, 0.0


def generate_generic_5axis_nc_from_cam(cam_data):
    """
    Generic illustrative 5-axis G-code.

    This intentionally uses comments and generic A/B/C placeholders because the
    actual 5-axis output depends on the controller and machine kinematics.
    It is useful for debugging data flow, not direct production.
    """
    tool = (cam_data.get("tooling", {}) or {}).get("active_tool", {}) or {}
    tool_number = _tool_int(tool.get("number", TOOL_NUMBER), TOOL_NUMBER)
    tool_diameter = _tool_float(tool.get("diameter", TOOL_DIAMETER), TOOL_DIAMETER)
    spindle = _tool_float(tool.get("spindle", 12000.0), 12000.0)
    feed_cut = _tool_float(tool.get("feed_cut", FEED_CUT), FEED_CUT)
    safe_z = _tool_float(tool.get("safe_z", SAFE_Z), SAFE_Z)

    lines = []
    lines.append("%")
    lines.append("(PREFABANALYSER GENERIC 5-AXIS PLACEHOLDER)")
    lines.append("(NOT FINAL PRODUCTION CODE WITHOUT MACHINE POSTPROCESSOR)")
    lines.append("(BEAM ID: {})".format(cam_data.get("beam", {}).get("element_id", "")))
    lines.append("(MARK: {})".format(cam_data.get("beam", {}).get("mark", "")))
    lines.append("G21")
    lines.append("G90")
    lines.append("G54")
    lines.append("G17")
    lines.append("T{} M6".format(tool_number))
    lines.append("S{} M3".format(fmt(spindle)))
    lines.append("G0 Z{}".format(fmt(safe_z)))
    lines.append("")

    for idx, op in enumerate(cam_data.get("openings", []) or [], start=1):
        kind = op.get("kind", "")
        axis = op.get("mep_axis_ft") or [0.0, 0.0, 1.0]
        A, B, C = axis_to_generic_abc(axis)
        p = op.get("parameters", {})
        c = op.get("center_mm_from_revit_origin") or [0.0, 0.0, 0.0]

        lines.append("(OPENING {} | KIND {} | VOID ID {} | MEP ID {})".format(
            idx, kind, op.get("void_element_id", ""), op.get("source_mep_id", "")
        ))
        lines.append("(AXIS FT: {} | GENERIC ABC: A{} B{} C{})".format(
            axis, fmt(A), fmt(B), fmt(C)
        ))
        lines.append("(PARAMETERS: {})".format(p))
        lines.append("(WARNING: Replace ABC/TCP syntax with your real machine postprocessor.)")
        lines.append("G0 Z{}".format(fmt(safe_z)))
        lines.append("G0 X{} Y{} A{} B{} C{}".format(fmt(c[0]), fmt(c[1]), fmt(A), fmt(B), fmt(C)))
        lines.append("(CAM SHOULD BOOLEAN stock_mesh - void_mesh AND GENERATE TRUE 3D CONTOURS HERE)")
        lines.append("(For round void: tool axis follows MEP axis; for rectangular void: contour comes from void mesh intersection)")
        lines.append("F{}".format(fmt(feed_cut)))
        lines.append("")

    lines.append("G0 Z{}".format(fmt(safe_z)))
    lines.append("M5")
    lines.append("M30")
    lines.append("%")
    return "\n".join(lines)



# -----------------------------
# PERPENDICULARITY CHECKS
# -----------------------------

def _axis_angle_from_cnc_z_deg(axis):
    """
    Returns the smallest angle in degrees between the opening axis and CNC Z.
    0° = perfectly perpendicular to CNC XY machining plane.
    """
    try:
        a = _norm([float(axis[0]), float(axis[1]), float(axis[2])])
        c = abs(float(a[2]))
        c = max(-1.0, min(1.0, c))
        return math.degrees(math.acos(c))
    except:
        return 0.0


def _opening_axis_is_perpendicular(axis, tolerance_deg=None):
    if tolerance_deg is None:
        tolerance_deg = PERPENDICULAR_TOLERANCE_DEG
    return _axis_angle_from_cnc_z_deg(axis) <= float(tolerance_deg)


def validate_openings_are_perpendicular(beam_data):
    """
    Stop export if a hole/opening goes through the beam at an angle.

    The current exporter is a vertical 2.5D pocket exporter. If a Revit opening
    is not perpendicular to the selected machining plane, exporting it anyway
    creates wrong toolpaths. Therefore this function raises an error instead.
    """
    bad = []

    for h in beam_data.get("holes", []) or []:
        axis = h.get("axis", [0.0, 0.0, 1.0])
        angle = _axis_angle_from_cnc_z_deg(axis)
        if not _opening_axis_is_perpendicular(axis):
            bad.append({
                "kind": "round",
                "x": h.get("x", 0.0),
                "y": h.get("y", 0.0),
                "diameter": h.get("diameter", 0.0),
                "angle": angle,
                "type": h.get("type", "")
            })

    for op in beam_data.get("openings", []) or []:
        axis = op.get("axis", [0.0, 0.0, 1.0])
        angle = _axis_angle_from_cnc_z_deg(axis)
        if not _opening_axis_is_perpendicular(axis):
            bad.append({
                "kind": "rectangular/non-round",
                "x": op.get("x", 0.0),
                "y": op.get("y", 0.0),
                "width": op.get("width", 0.0),
                "height": op.get("height", 0.0),
                "angle": angle,
                "type": op.get("type", "")
            })

    if bad:
        lines = []
        lines.append("Export gestopt: er zijn gaten/openingen die niet loodrecht door de balk gaan.")
        lines.append("")
        lines.append("Deze exporter maakt enkel correcte G-code voor openingen die loodrecht staan op het CNC-bewerkingsvlak.")
        lines.append("Schuine gaten moeten met een aparte 5-assige CAM/postprocessor verwerkt worden.")
        lines.append("")
        lines.append("Tolerantie: {} graden".format(PERPENDICULAR_TOLERANCE_DEG))
        lines.append("")
        for i, b in enumerate(bad, start=1):
            lines.append("{}: {} opening | X={} Y={} | hoek t.o.v. loodrecht = {:.2f}° | bron={}".format(
                i,
                b.get("kind", ""),
                fmt(b.get("x", 0.0)),
                fmt(b.get("y", 0.0)),
                float(b.get("angle", 0.0)),
                b.get("type", "")
            ))

        raise Exception("\\n".join(lines))



# -----------------------------
# STRONG PERPENDICULARITY CHECKS FROM REVIT SOURCE MEP
# -----------------------------

def get_element_by_int_id(doc, int_id):
    try:
        return doc.GetElement(ElementId(int(int_id)))
    except:
        return None


def get_location_curve_axis_ft(elem):
    try:
        loc = elem.Location
        if isinstance(loc, LocationCurve) and loc.Curve:
            p0 = loc.Curve.GetEndPoint(0)
            p1 = loc.Curve.GetEndPoint(1)
            return _norm([float(p1.X - p0.X), float(p1.Y - p0.Y), float(p1.Z - p0.Z)])
    except:
        pass
    return None


def _axis_angle_from_cnc_z_deg(axis):
    """
    Returns the smallest angle in degrees between the opening axis and CNC Z.
    0° = perpendicular to the machining face.
    """
    try:
        a = _norm([float(axis[0]), float(axis[1]), float(axis[2])])
        c = abs(float(a[2]))
        c = max(-1.0, min(1.0, c))
        return math.degrees(math.acos(c))
    except:
        return 0.0


def _opening_axis_is_perpendicular(axis, tolerance_deg=None):
    if tolerance_deg is None:
        tolerance_deg = PERPENDICULAR_TOLERANCE_DEG
    return _axis_angle_from_cnc_z_deg(axis) <= float(tolerance_deg)


def collect_non_perpendicular_prefab_voids(doc, beam, origin_ft, axis_index, xy_rotation):
    """
    Checks the actual SourceMEPId direction stored on the PrefabAnalyser voids.
    This is stronger than checking the already-exported hole list, because mesh
    fallback detections may not contain the real MEP axis and otherwise look
    falsely perpendicular.
    """
    bad = []
    beam_id = eid_to_int(beam.Id)

    try:
        beam_bb = beam.get_BoundingBox(None)
    except:
        beam_bb = None

    try:
        voids = (FilteredElementCollector(doc)
                 .OfClass(FamilyInstance)
                 .WhereElementIsNotElementType()
                 .ToElements())
    except:
        return bad

    for inst in voids:
        fam = get_family(inst, doc)
        is_round_void = fam == ROUND_VOID_FAMILY_NAME or str(fam).startswith(ROUND_VOID_FAMILY_NAME)
        is_rect_void = fam == RECT_VOID_FAMILY_NAME or str(fam).startswith(RECT_VOID_FAMILY_NAME)
        if not is_round_void and not is_rect_void:
            continue

        try:
            void_bb = inst.get_BoundingBox(None)
        except:
            void_bb = None

        source_host = parse_int_text(get_param_string(inst, "SourceHostId"))
        if source_host is not None:
            if int(source_host) != int(beam_id) and not bbox_intersects(beam_bb, void_bb):
                continue
        else:
            if not bbox_intersects(beam_bb, void_bb):
                continue

        source_mep = parse_int_text(get_param_string(inst, "SourceMEPId"))
        if source_mep is None:
            # If we cannot verify the MEP direction, do not block here.
            continue

        mep_elem = get_element_by_int_id(doc, source_mep)
        mep_axis_ft = get_location_curve_axis_ft(mep_elem) if mep_elem else None
        if not mep_axis_ft:
            continue

        mep_axis_cnc = vector_to_cnc(mep_axis_ft, axis_index, xy_rotation)
        angle = _axis_angle_from_cnc_z_deg(mep_axis_cnc)

        if not _opening_axis_is_perpendicular(mep_axis_cnc):
            center_ft = get_location_point_ft(inst)
            if center_ft:
                cx, cy, cz = point_to_cnc_mm(center_ft, origin_ft, axis_index, xy_rotation)
            else:
                cx, cy, cz = 0.0, 0.0, 0.0

            bad.append({
                "void_id": eid_to_int(inst.Id),
                "mep_id": source_mep,
                "host_id": source_host,
                "kind": "round" if is_round_void else "rectangular",
                "x": cx,
                "y": cy,
                "z": cz,
                "angle": angle,
                "axis": mep_axis_cnc
            })

    return bad


def raise_non_perpendicular_error(bad):
    if not bad:
        return

    lines = []
    lines.append("CNC export stopped")
    lines.append("")
    lines.append("Reason")
    lines.append("One or more openings are not perpendicular to the machining plane.")
    lines.append("")
    lines.append("Detected issue")
    lines.append("Tolerance: {}°".format(PERPENDICULAR_TOLERANCE_DEG))
    lines.append("Number of non-perpendicular openings: {}".format(len(bad)))
    lines.append("")

    lines.append("Elements")
    for i, b in enumerate(bad, start=1):
        lines.append(
            "{}. {} opening | X={}  Y={} | deviation from perpendicular: {:.2f}° | source={}".format(
                i,
                b.get("kind", ""),
                fmt(b.get("x", 0.0)),
                fmt(b.get("y", 0.0)),
                float(b.get("angle", 0.0)),
                b.get("type", "")
            )
        )

    lines.append("")
    lines.append("How to fix")
    lines.append("- Make the opening perpendicular to the beam/machining plane, or")
    lines.append("- Use a dedicated 5-axis CAM/postprocessor for angled openings.")
    lines.append("")
    lines.append("No NC file was generated for this beam to prevent incorrect machining.")

    raise Exception("\\n".join(lines))




# -----------------------------
# STRONG MEP-BEAM ANGLE CHECK
# -----------------------------

MEP_CATEGORIES_FOR_PERP_CHECK = [
    BuiltInCategory.OST_DuctCurves,
    BuiltInCategory.OST_PipeCurves,
    BuiltInCategory.OST_Conduit,
    BuiltInCategory.OST_CableTray,
    BuiltInCategory.OST_DuctFitting,
    BuiltInCategory.OST_PipeFitting,
    BuiltInCategory.OST_ConduitFitting,
    BuiltInCategory.OST_CableTrayFitting,
]


def _cat_name(elem):
    try:
        return elem.Category.Name
    except:
        return ""


def get_location_curve_axis_ft(elem):
    try:
        loc = elem.Location
        if isinstance(loc, LocationCurve) and loc.Curve:
            p0 = loc.Curve.GetEndPoint(0)
            p1 = loc.Curve.GetEndPoint(1)
            v = [float(p1.X - p0.X), float(p1.Y - p0.Y), float(p1.Z - p0.Z)]
            if _len(v) > 1e-9:
                return _norm(v)
    except:
        pass
    return None


def get_bbox_center_ft_from_elem(elem):
    try:
        bb = elem.get_BoundingBox(None)
        if bb:
            return [
                (float(bb.Min.X) + float(bb.Max.X)) / 2.0,
                (float(bb.Min.Y) + float(bb.Max.Y)) / 2.0,
                (float(bb.Min.Z) + float(bb.Max.Z)) / 2.0
            ]
    except:
        pass
    return None


def _axis_angle_from_cnc_z_deg(axis):
    """
    Returns the smallest angle in degrees between the MEP/opening axis and CNC Z.
    0° means the opening is perpendicular to the selected machining plane.
    """
    try:
        a = _norm([float(axis[0]), float(axis[1]), float(axis[2])])
        c = abs(float(a[2]))
        c = max(-1.0, min(1.0, c))
        return math.degrees(math.acos(c))
    except:
        return 0.0


def _opening_axis_is_perpendicular(axis, tolerance_deg=None):
    if tolerance_deg is None:
        tolerance_deg = PERPENDICULAR_TOLERANCE_DEG
    return _axis_angle_from_cnc_z_deg(axis) <= float(tolerance_deg)


def collect_mep_elements_for_angle_check(doc):
    result = []
    seen = set()

    for bic in MEP_CATEGORIES_FOR_PERP_CHECK:
        try:
            elems = (FilteredElementCollector(doc)
                     .OfCategory(bic)
                     .WhereElementIsNotElementType()
                     .ToElements())
        except:
            elems = []

        for e in elems:
            eid = eid_to_int(e.Id)
            if eid in seen:
                continue
            seen.add(eid)
            result.append(e)

    return result


def collect_non_perpendicular_mep_crossings(doc, beam, origin_ft, axis_index, xy_rotation):
    """
    Detect MEP elements that physically intersect the beam and are not
    perpendicular to the selected CNC machining plane.
    """
    bad = []

    try:
        beam_bb = beam.get_BoundingBox(None)
    except:
        beam_bb = None

    if not beam_bb:
        return bad

    for mep in collect_mep_elements_for_angle_check(doc):
        try:
            mep_bb = mep.get_BoundingBox(None)
        except:
            mep_bb = None

        if not bbox_intersects(beam_bb, mep_bb, margin=0.02):
            continue

        axis_ft = get_location_curve_axis_ft(mep)
        if not axis_ft:
            continue

        axis_cnc = vector_to_cnc(axis_ft, axis_index, xy_rotation)
        angle = _axis_angle_from_cnc_z_deg(axis_cnc)

        if not _opening_axis_is_perpendicular(axis_cnc):
            center_ft = get_bbox_center_ft_from_elem(mep)
            if center_ft:
                try:
                    cx, cy, cz = point_to_cnc_mm(center_ft, origin_ft, axis_index, xy_rotation)
                except:
                    cx, cy, cz = 0.0, 0.0, 0.0
            else:
                cx, cy, cz = 0.0, 0.0, 0.0

            bad.append({
                "beam_id": eid_to_int(beam.Id),
                "mep_id": eid_to_int(mep.Id),
                "category": _cat_name(mep),
                "x": cx,
                "y": cy,
                "z": cz,
                "angle": angle,
                "axis_cnc": axis_cnc
            })

    return bad


def raise_non_perpendicular_mep_error(bad):
    if not bad:
        return

    # Use the first detected issue for the main readable error message.
    first = bad[0]

    message = []
    message.append("CNC export stopped")
    message.append("")
    message.append("This beam contains an opening that is not perpendicular to the machining plane.")
    message.append("")
    message.append("Detected")
    message.append("Beam: {}".format(first.get("beam_id", "")))
    message.append("MEP: {} — {}".format(first.get("mep_id", ""), first.get("category", "")))
    message.append("Deviation from perpendicular: {:.2f}°".format(float(first.get("angle", 0.0))))
    message.append("Allowed tolerance: {:.2f}°".format(float(PERPENDICULAR_TOLERANCE_DEG)))
    message.append("")
    message.append("How to fix")
    message.append("Make the MEP element perpendicular to the beam, or process this opening with a dedicated 5-axis CAM/postprocessor.")
    message.append("")
    message.append("No NC file was generated for this beam to prevent incorrect machining.")

    # If multiple crossings are found, add a compact overview below the requested text.
    if len(bad) > 1:
        message.append("")
        message.append("Additional detected crossings")
        for i, b in enumerate(bad[1:], start=2):
            message.append(
                "{}. Beam: {} | MEP: {} — {} | Deviation: {:.2f}°".format(
                    i,
                    b.get("beam_id", ""),
                    b.get("mep_id", ""),
                    b.get("category", ""),
                    float(b.get("angle", 0.0))
                )
            )

    raise Exception("\n".join(message))


# -----------------------------
# G-CODE GENERATION
# -----------------------------

def fmt(n):
    value = float(n)
    if abs(value) < 0.0005:
        value = 0.0
    return "{:.3f}".format(value)



def _frange_down(start, stop, step):
    """Return Z levels from start down to stop, always including stop."""
    levels = []
    try:
        start = float(start)
        stop = float(stop)
        step = abs(float(step))
    except:
        return [stop]

    if step <= 0.001:
        step = 5.0

    z = start
    guard = 0
    while z - step > stop and guard < 1000:
        z -= step
        levels.append(z)
        guard += 1
    levels.append(stop)
    return levels


def _opening_is_duplicate_of_round_hole(op, holes, tol_center=2.0, tol_size=2.0):
    """
    True when a rectangular/non-round mesh detection duplicates an already trusted
    ROUND void. This is only safe when the round source is stronger than the
    opening source, e.g. round prefab family vs. rectangular mesh crease.
    """
    try:
        ox = float(op.get("x", 0.0))
        oy = float(op.get("y", 0.0))
        ow = abs(float(op.get("width", 0.0)))
        oh = abs(float(op.get("height", 0.0)))
        op_type = str(op.get("type", "")).lower()
    except:
        return False

    # A rectangular prefab void is intentional. Never remove it just because
    # mesh analysis also found a 70x70 round-ish crease at the same place.
    if "rectangular_void_prefab_void_family" in op_type:
        return False

    for h in holes or []:
        try:
            h_type = str(h.get("type", "")).lower()
            # Only trusted round sources can override a weak rectangular mesh source.
            if "round_hole_prefab_void_family" not in h_type and "round_hole_face_detected" not in h_type:
                continue
            hx = float(h.get("x", 0.0))
            hy = float(h.get("y", 0.0))
            hd = abs(float(h.get("diameter", 0.0)))
            if abs(ox - hx) <= tol_center and abs(oy - hy) <= tol_center:
                if abs(ow - hd) <= tol_size and abs(oh - hd) <= tol_size:
                    return True
        except:
            pass
    return False


def _hole_is_duplicate_of_rect_opening(hole, openings, tol_center=2.0, tol_size=2.0):
    """
    True when a ROUND mesh/crease detection is actually the square envelope of a
    rectangular prefab void. Rectangular prefab voids have priority because they
    are explicit Revit family data; mesh/crease roundness is only a fallback.
    """
    try:
        h_type = str(hole.get("type", "")).lower()
        hx = float(hole.get("x", 0.0))
        hy = float(hole.get("y", 0.0))
        hd = abs(float(hole.get("diameter", 0.0)))
    except:
        return False

    # Never remove explicit round prefab voids.
    if "round_hole_prefab_void_family" in h_type:
        return False

    # Only weak/derived round detections may be replaced by explicit rectangles.
    if "mesh" not in h_type and "crease" not in h_type and "edge" not in h_type:
        return False

    for op in openings or []:
        try:
            op_type = str(op.get("type", "")).lower()
            # Prefer actual Revit rectangular void families over mesh round guesses.
            if "rectangular_void_prefab_void_family" not in op_type:
                continue
            ox = float(op.get("x", 0.0))
            oy = float(op.get("y", 0.0))
            ow = abs(float(op.get("width", 0.0)))
            oh = abs(float(op.get("height", 0.0)))
            if abs(hx - ox) <= tol_center and abs(hy - oy) <= tol_center:
                if abs(ow - hd) <= tol_size and abs(oh - hd) <= tol_size:
                    return True
        except:
            pass
    return False


def filter_void_detection_conflicts(holes, openings):
    """
    Resolve detection conflicts before JSON/NC export.

    Priority:
    1. Explicit Revit prefab void families.
    2. Face detection.
    3. Mesh/crease fallback detection.

    This prevents a square 70x70 prefab void from being exported as a second
    round Ø70 hole when the mesh boundary looks circular/round-ish.
    """
    cleaned_holes = []
    removed_rounds = 0
    for h in holes or []:
        if _hole_is_duplicate_of_rect_opening(h, openings):
            removed_rounds += 1
            continue
        cleaned_holes.append(h)

    cleaned_openings = []
    removed_openings = 0
    for op in openings or []:
        if _opening_is_duplicate_of_round_hole(op, cleaned_holes):
            removed_openings += 1
            continue
        cleaned_openings.append(op)

    return cleaned_holes, cleaned_openings, removed_rounds, removed_openings


def _append_safe_header(lines, beam_data, tool_number, tool_name, tool_diameter, spindle,
                        stock_bottom_z, stock_top_z, stock_depth, travel_z):
    mark = beam_data.get("mark", "")
    eid = beam_data.get("element_id", "")

    lines.append("%")
    lines.append("(BEAM CNC EXPORT - POCKETING VERSION)")
    lines.append("(MARK: {})".format(mark))
    lines.append("(ELEMENT ID: {})".format(eid))
    lines.append("(FAMILY: {})".format(beam_data.get("family", "")))
    lines.append("(TYPE: {})".format(beam_data.get("type", "")))
    lines.append("(TOOL: T{} | {} | DIA {} MM)".format(tool_number, tool_name, fmt(tool_diameter)))
    lines.append("(PROGRAM ZERO: SELECTED REVIT ORIGIN SETS X0/Y0)")
    lines.append("(PROGRAM Z: BOTTOM Z{} TOP Z{} THICKNESS {})".format(
        fmt(stock_bottom_z), fmt(stock_top_z), fmt(stock_depth)))
    lines.append("(SAFE TRAVEL Z: {})".format(fmt(travel_z)))
    lines.append("(AXES: {})".format(beam_data.get("axis_label", "CNC Z = Revit Z")))
    lines.append("(VERIFY TOOL, ZERO, CLAMPS, FEEDS, SPINDLE AND POSTPROCESSOR BEFORE RUNNING)")
    lines.append("(ROUND POCKETS USE G1 SEGMENTS TO FOLLOW THE CIRCLE CONTOUR)")
    lines.append("")
    lines.append("G21 (UNITS MM)")
    lines.append("G90 (ABSOLUTE)")
    lines.append("G54 (WORK OFFSET ZERO = SELECTED REVIT ORIGIN)")
    lines.append("G17 (XY PLANE)")
    lines.append("G40 G49 G80")
    lines.append("T{} M6".format(tool_number))
    lines.append("S{} M3".format(fmt(spindle)))
    lines.append("G0 Z{}".format(fmt(travel_z)))
    lines.append("G0 X0 Y0 (SELECTED ORIGIN)")
    lines.append("")


def _append_reference_outline(lines, bbox, travel_z):
    min_x = bbox.get("min_x", 0.0)
    max_x = bbox.get("max_x", 0.0)
    min_y = bbox.get("min_y", 0.0)
    max_y = bbox.get("max_y", 0.0)

    lines.append("(STOCK / BOUNDING BOX RELATIVE TO ORIGIN)")
    lines.append("(X MIN {} MAX {})".format(fmt(min_x), fmt(max_x)))
    lines.append("(Y MIN {} MAX {})".format(fmt(min_y), fmt(max_y)))
    lines.append("(REFERENCE OUTLINE - AIR MOVE ONLY)")
    lines.append("G0 Z{}".format(fmt(travel_z)))
    lines.append("G0 X{} Y{}".format(fmt(min_x), fmt(min_y)))
    lines.append("G0 X{} Y{}".format(fmt(max_x), fmt(min_y)))
    lines.append("G0 X{} Y{}".format(fmt(max_x), fmt(max_y)))
    lines.append("G0 X{} Y{}".format(fmt(min_x), fmt(max_y)))
    lines.append("G0 X{} Y{}".format(fmt(min_x), fmt(min_y)))
    lines.append("")


def _append_circle_at_current_z(lines, x, y, r, feed_cut):
    """
    Follow the circular contour with many short G1 moves.

    This avoids G2/G3 arc problems where the CNC preview shows the tool moving
    only left-to-right instead of following the actual circle.
    """
    if r <= 0.001:
        return

    try:
        segments = int(CIRCLE_SEGMENTS)
    except:
        segments = 96

    # More segments = smoother circle.
    if segments < 48:
        segments = 48

    # Start at right side of the circle.
    start_x = x + r
    start_y = y
    lines.append("G1 X{} Y{} F{}".format(fmt(start_x), fmt(start_y), fmt(feed_cut)))

    for i in range(1, segments + 1):
        angle = (2.0 * math.pi * float(i)) / float(segments)
        px = x + math.cos(angle) * r
        py = y + math.sin(angle) * r
        lines.append("G1 X{} Y{} F{}".format(fmt(px), fmt(py), fmt(feed_cut)))


def _append_round_pocket(lines, index, hole, tool_diameter, stock_top_z, cut_depth,
                         through_extra, step_down, step_over, travel_z, retract_z,
                         feed_plunge, feed_cut):
    x = float(hole.get("x", 0.0))
    y = float(hole.get("y", 0.0))
    dia = abs(float(hole.get("diameter", 0.0)))
    tool_radius = abs(float(tool_diameter)) / 2.0
    path_radius = (dia / 2.0) - tool_radius

    lines.append("")
    lines.append("(ROUND POCKET {} - DIA {})".format(index, fmt(dia)))
    lines.append("(CENTER X{} Y{} | SOURCE: {})".format(fmt(x), fmt(y), hole.get("type", "")))

    if dia <= 0.001:
        lines.append("(SKIPPED: invalid diameter)")
        return

    if path_radius <= 0.001:
        lines.append("(SKIPPED: tool diameter {} is too large for hole diameter {})".format(fmt(tool_diameter), fmt(dia)))
        return

    final_z = float(cut_depth) - abs(float(through_extra))
    start_z = float(stock_top_z)
    levels = _frange_down(start_z, final_z, step_down)

    lines.append("G0 Z{}".format(fmt(travel_z)))
    lines.append("G0 X{} Y{}".format(fmt(x), fmt(y)))

    ring_step = max(0.5, min(float(step_over), max(0.5, path_radius)))
    rings = []
    r = ring_step
    guard = 0
    while r < path_radius and guard < 500:
        rings.append(r)
        r += ring_step
        guard += 1
    if not rings or abs(rings[-1] - path_radius) > 0.001:
        rings.append(path_radius)

    for zi, z in enumerate(levels):
        lines.append("G1 X{} Y{} F{}".format(fmt(x), fmt(y), fmt(feed_cut)))
        lines.append("G1 Z{} F{}".format(fmt(z), fmt(feed_plunge)))
        for rr in rings:
            _append_circle_at_current_z(lines, x, y, rr, feed_cut)
        # Finishing circle at final radius for each level; final level repeats as clean finish.
        if zi == len(levels) - 1:
            lines.append("(FINISH PASS)")
            _append_circle_at_current_z(lines, x, y, path_radius, feed_cut)

    lines.append("G0 Z{}".format(fmt(retract_z)))
    lines.append("G0 Z{}".format(fmt(travel_z)))


def _append_rect_pocket(lines, index, op, tool_diameter, stock_top_z, cut_depth,
                        through_extra, step_down, step_over, travel_z, retract_z,
                        feed_plunge, feed_cut):
    min_x = float(op.get("min_x", op.get("x", 0.0)))
    max_x = float(op.get("max_x", op.get("x", 0.0)))
    min_y = float(op.get("min_y", op.get("y", 0.0)))
    max_y = float(op.get("max_y", op.get("y", 0.0)))

    if max_x < min_x:
        min_x, max_x = max_x, min_x
    if max_y < min_y:
        min_y, max_y = max_y, min_y

    width = max_x - min_x
    height = max_y - min_y
    tool_radius = abs(float(tool_diameter)) / 2.0

    lines.append("")
    lines.append("(RECTANGULAR POCKET {} - W {} H {})".format(index, fmt(width), fmt(height)))
    lines.append("(SOURCE: {})".format(op.get("type", "")))

    if width <= tool_diameter or height <= tool_diameter:
        lines.append("(SKIPPED: opening is too small for tool diameter {})".format(fmt(tool_diameter)))
        return

    final_z = float(cut_depth) - abs(float(through_extra))
    levels = _frange_down(float(stock_top_z), final_z, step_down)

    # Tool center must stay inside the opening edge by tool radius.
    outer_min_x = min_x + tool_radius
    outer_max_x = max_x - tool_radius
    outer_min_y = min_y + tool_radius
    outer_max_y = max_y - tool_radius

    if outer_max_x <= outer_min_x or outer_max_y <= outer_min_y:
        lines.append("(SKIPPED: no valid tool-center path inside opening)")
        return

    lines.append("G0 Z{}".format(fmt(travel_z)))
    lines.append("G0 X{} Y{}".format(fmt(outer_min_x), fmt(outer_min_y)))

    loop_step = max(0.5, float(step_over))
    for z in levels:
        lines.append("G1 Z{} F{}".format(fmt(z), fmt(feed_plunge)))

        ox1 = outer_min_x
        ox2 = outer_max_x
        oy1 = outer_min_y
        oy2 = outer_max_y
        guard = 0
        while ox2 >= ox1 and oy2 >= oy1 and guard < 500:
            lines.append("G1 X{} Y{} F{}".format(fmt(ox1), fmt(oy1), fmt(feed_cut)))
            lines.append("G1 X{} Y{} F{}".format(fmt(ox2), fmt(oy1), fmt(feed_cut)))
            lines.append("G1 X{} Y{} F{}".format(fmt(ox2), fmt(oy2), fmt(feed_cut)))
            lines.append("G1 X{} Y{} F{}".format(fmt(ox1), fmt(oy2), fmt(feed_cut)))
            lines.append("G1 X{} Y{} F{}".format(fmt(ox1), fmt(oy1), fmt(feed_cut)))

            ox1 += loop_step
            ox2 -= loop_step
            oy1 += loop_step
            oy2 -= loop_step
            if ox2 < ox1 or oy2 < oy1:
                break
            lines.append("G1 X{} Y{} F{}".format(fmt(ox1), fmt(oy1), fmt(feed_cut)))
            guard += 1

    lines.append("G0 Z{}".format(fmt(retract_z)))
    lines.append("G0 Z{}".format(fmt(travel_z)))


def generate_nc(beam_data):
    bbox = beam_data.get("bbox_mm") or {}
    holes = beam_data.get("holes", []) or []
    openings_raw = beam_data.get("openings", []) or []

    cfg = beam_data.get("cnc_config", {})
    tool = cfg.get("active_tool", {})
    tool_number = _tool_int(tool.get("number", TOOL_NUMBER), TOOL_NUMBER)
    tool_name = str(tool.get("name", "Tool"))
    tool_diameter = _tool_float(tool.get("diameter", TOOL_DIAMETER), TOOL_DIAMETER)
    spindle = _tool_float(tool.get("spindle", 12000.0), 12000.0)
    feed_cut = _tool_float(tool.get("feed_cut", FEED_CUT), FEED_CUT)
    feed_plunge = _tool_float(tool.get("feed_plunge", FEED_PLUNGE), FEED_PLUNGE)
    feed_travel = _tool_float(tool.get("feed_travel", FEED_TRAVEL), FEED_TRAVEL)

    # In the UI these values are stored as safe/retract clearances. Use them ABOVE stock top,
    # because using safe_z equal to stock thickness makes travel happen on the top surface.
    safe_clearance = abs(_tool_float(tool.get("safe_z", SAFE_Z), SAFE_Z))
    retract_clearance = abs(_tool_float(tool.get("retract_z", 5.0), 5.0))

    min_z = float(bbox.get("min_z", 0.0))
    max_z = float(bbox.get("max_z", 0.0))
    stock_depth = abs(max_z - min_z)
    if stock_depth <= 0.001:
        stock_depth = abs(float(beam_data.get("stock_thickness_mm", 0.0)))

    # The plugin normalizes exported Z so bottom is usually 0 and top is thickness.
    stock_bottom_z = 0.0
    stock_top_z = stock_depth if stock_depth > 0.001 else max_z
    cut_depth = stock_bottom_z

    through_extra = 0.5   # mm below bottom to guarantee through cut. Adjust if your spoilboard/fixture requires otherwise.
    step_down = min(5.0, max(1.0, tool_diameter * 0.5))
    step_over = max(0.5, tool_diameter * 0.40)
    retract_z = stock_top_z + max(1.0, retract_clearance)
    travel_z = stock_top_z + max(retract_clearance + 5.0, safe_clearance)

    holes, openings, skipped_round_duplicates, skipped_opening_duplicates = filter_void_detection_conflicts(holes, openings_raw)

    # Safety: do not create wrong G-code for sloped/non-perpendicular holes.
    tmp_check_data = dict(beam_data)
    tmp_check_data["holes"] = holes
    tmp_check_data["openings"] = openings
    validate_openings_are_perpendicular(tmp_check_data)

    lines = []
    _append_safe_header(lines, beam_data, tool_number, tool_name, tool_diameter, spindle,
                        stock_bottom_z, stock_top_z, stock_depth, travel_z)
    _append_reference_outline(lines, bbox, travel_z)

    lines.append("F{}".format(fmt(feed_cut)))
    lines.append("(CUT SETTINGS: STEP_DOWN {} | STEP_OVER {} | THROUGH_EXTRA {})".format(
        fmt(step_down), fmt(step_over), fmt(through_extra)))
    lines.append("")

    if holes:
        lines.append("(ROUND HOLES - MACHINED AS G1 SEGMENTED CIRCULAR POCKETS, NOT G2/G3 ARCS)")
        for i, h in enumerate(holes, start=1):
            _append_round_pocket(lines, i, h, tool_diameter, stock_top_z, cut_depth,
                                 through_extra, step_down, step_over, travel_z, retract_z,
                                 feed_plunge, feed_cut)
    else:
        lines.append("(NO ROUND HOLES DETECTED)")

    lines.append("")
    if skipped_round_duplicates:
        lines.append("({} ROUND MESH DETECTION(S) SKIPPED BECAUSE THEY DUPLICATED RECTANGULAR PREFAB VOIDS)".format(skipped_round_duplicates))
    if skipped_opening_duplicates:
        lines.append("({} RECTANGULAR MESH DETECTION(S) SKIPPED BECAUSE THEY DUPLICATED TRUSTED ROUND HOLES)".format(skipped_opening_duplicates))

    if openings:
        lines.append("(RECTANGULAR / NON-ROUND VOIDS - MACHINED AS POCKETS WITH TOOL RADIUS OFFSET)")
        for i, op in enumerate(openings, start=1):
            _append_rect_pocket(lines, i, op, tool_diameter, stock_top_z, cut_depth,
                                through_extra, step_down, step_over, travel_z, retract_z,
                                feed_plunge, feed_cut)
    else:
        lines.append("(NO RECTANGULAR / NON-ROUND VOIDS TO MACHINE)")

    lines.append("")
    lines.append("G0 Z{}".format(fmt(travel_z)))
    lines.append("M5")
    lines.append("G0 X0 Y0")
    lines.append("M30")
    lines.append("%")

    return "\n".join(lines)

def build_beam_data(doc, el, origin):
    eid = eid_to_int(el.Id)
    solids = get_solid_geometry(el)
    verts, tris = triangulate_solids(solids)

    origin_ft = [float(origin["x"]), float(origin["y"]), float(origin["z"])]
    try:
        xy_rotation = int(origin.get("xy_rotation", 1 if origin.get("xy_swapped", False) else 0)) % 4
    except:
        xy_rotation = 0
    axis_index = auto_cnc_axis_index(verts, origin_ft)
    xaxis, yaxis, zaxis, axis_label = get_cnc_axis_vectors(axis_index, xy_rotation)

    origin_cnc = point_to_cnc_mm(origin_ft, origin_ft, axis_index, xy_rotation)
    raw_bbox = bbox_from_vertices_mm(verts, origin_ft, axis_index, xy_rotation)

    # Stop immediately if any MEP physically crossing this beam is not perpendicular
    # to the selected CNC machining plane.
    bad_mep_crossings = collect_non_perpendicular_mep_crossings(doc, el, origin_ft, axis_index, xy_rotation)
    raise_non_perpendicular_mep_error(bad_mep_crossings)
    holes_family, openings_family = collect_prefab_voids_for_beam(doc, el, origin_ft, axis_index, xy_rotation, raw_bbox)
    holes_face = detect_round_holes(solids, origin_ft, axis_index, xy_rotation)
    holes_mesh, openings_mesh = detect_voids_from_mesh_creases(verts, tris, origin_ft, axis_index, raw_bbox, xy_rotation)
    holes = merge_hole_lists(merge_hole_lists(holes_family, holes_face), holes_mesh)
    openings = merge_opening_lists(openings_family, openings_mesh)
    holes, openings, removed_rounds, removed_openings = filter_void_detection_conflicts(holes, openings)

    # Strong safety check: use the original Revit void -> SourceMEPId direction.
    bad_non_perpendicular = collect_non_perpendicular_prefab_voids(doc, el, origin_ft, axis_index, xy_rotation)
    raise_non_perpendicular_error(bad_non_perpendicular)

    z_output_offset = 0.0
    if raw_bbox:
        try:
            z_output_offset = -float(raw_bbox.get("min_z", 0.0))
        except:
            z_output_offset = 0.0

    bbox = apply_z_output_offset_to_bbox(raw_bbox, z_output_offset)
    apply_z_output_offset_to_items(holes, z_output_offset)
    apply_z_output_offset_to_items(openings, z_output_offset)
    origin_cnc_output = [
        origin_cnc[0],
        origin_cnc[1],
        origin_cnc[2] + z_output_offset
    ]

    data = {
        "schema": "beam_cnc_export_v2",
        "element_id": eid,
        "mark": get_mark(el),
        "family": get_family(el, doc),
        "type": get_type_name(el),
        "length_mm": get_length_mm(el),
        "origin_ft": {
            "x": origin_ft[0],
            "y": origin_ft[1],
            "z": origin_ft[2]
        },
        "origin_cnc_mm": {
            "x": round(origin_cnc_output[0], 6),
            "y": round(origin_cnc_output[1], 6),
            "z": round(origin_cnc_output[2], 6)
        },
        "z_output_offset_mm": round(z_output_offset, 6),
        "stock_thickness_mm": round(abs(float((bbox or {}).get("max_z", 0.0)) - float((bbox or {}).get("min_z", 0.0))), 6),
        "axis_index": axis_index,
        "xy_rotation": xy_rotation,
        "axis_label": axis_label,
        "bbox_mm": bbox,
        "holes": holes,
        "openings": openings,
        "mesh": {
            "vertices_ft": verts,
            "triangles": tris
        },
        "cnc_config": get_cnc_runtime_config(doc)
    }

    return data


def write_files(outdir, beam_data, cam_data=None):
    """
    Export exactly:
    - one neutral CAM JSON
    - one populated NC file

    The NC file is generated from the current machining logic so it is not empty.
    The JSON keeps the exact Revit/CAM data for verification or future CAM/postprocessing.
    """
    mark = safe_name(beam_data.get("mark") or "beam")
    eid = beam_data.get("element_id")
    base = "{}_{}".format(mark, eid)

    json_path = os.path.join(outdir, base + "_neutral_cam.json")
    nc_path = os.path.join(outdir, base + NC_EXT)

    if cam_data is None:
        cam_data = {
            "schema": CAM_JSON_SCHEMA if "CAM_JSON_SCHEMA" in globals() else "prefab_cam_export",
            "beam_data": beam_data
        }

    with open(json_path, "w") as f:
        f.write(json.dumps(cam_data, indent=2, sort_keys=True))

    # IMPORTANT:
    # Use the actual G-code generator so the .nc file contains toolpaths.
    # The neutral CAM JSON is for exact Revit geometry/CAM verification.
    nc = generate_nc(beam_data)

    # Add a short note at the top if neutral CAM data is present.
    try:
        note = []
        note.append("(NEUTRAL CAM JSON EXPORTED NEXT TO THIS NC FILE)")
        note.append("(JSON FILE: {})".format(os.path.basename(json_path)))
        note.append("(USE JSON FOR EXACT REVIT STOCK/VOID GEOMETRY VERIFICATION)")
        note.append("")
        nc = nc.replace("(BEAM CNC EXPORT - POCKETING VERSION)", "(BEAM CNC EXPORT - POCKETING VERSION)\n" + "\n".join(note), 1)
    except:
        pass

    with open(nc_path, "w") as f:
        f.write(nc)

    return json_path, nc_path


def export_all_marked(doc):
    """
    Called from event_handler.py.
    Exports all Structural Framing beams that have an origin saved.
    """
    origins = storage.load_origins(doc)
    outdir = make_output_folder(doc)

    if not outdir:
        return "Export geannuleerd", 0

    count = 0
    errors = []

    beams = collect_export_beams(doc)
    for el in beams:
        eid = eid_to_int(el.Id)
        origin = origins.get(str(eid))
        if not origin:
            continue

        try:
            data = build_beam_data(doc, el, origin)
            try:
                cam_data = build_neutral_cam_data(doc, el, origin, data)
            except Exception:
                cam_data = {
                    "schema": "neutral_cam_fallback",
                    "beam_data": data
                }
            write_files(outdir, data, cam_data)
            count += 1
        except Exception as ex:
            errors.append(str(ex))
            logger.error(traceback.format_exc())

    if errors:
        try:
            err_path = os.path.join(outdir, "_export_errors.txt")
            with open(err_path, "w") as f:
                f.write("\n\n".join(errors))
        except:
            pass

        try:
            forms.alert("\n\n".join(errors), title="PrefabAnalyser - CNC export stopped", warn_icon=True)
        except:
            pass

    return outdir, count
