# -*- coding: utf-8 -*-
from __future__ import division

from pyrevit import script
import clr

clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")

from System.Windows.Forms import *
from System.Drawing import Size, Point, Font, FontStyle, Color, ContentAlignment

# ============================================================
# PREFABANALYSER SETTINGS - MEP-SPECIFIC CLEARANCES
# ============================================================
# No XAML, no Project Information parameters.
# Settings are saved in the pyRevit config.
# ============================================================

CONFIG_SECTION = "PrefabAnalyser"

DEFAULT_HOSTS = "Structural Framing"
DEFAULT_RULE_MODE = "MEP"
DEFAULT_EDGE_MODE = "MOVE"
DEFAULT_AUTO_CLOSE_OUTPUT = "False"

# Default clearances in mm, per MEP type
DEFAULT_CLEARANCES = {
    "round_duct": "30",
    "rectangular_duct": "30",
    "pipe": "30",
    "conduit": "30",
    "cable_tray": "30",
    "other_mep": "30",
}

HOSTS = [
    "Structural Framing",
    "Structural Columns",
    "Walls",
]

RULE_ITEMS = [
    ("Automatically reduce MEP", "MEP"),
    ("Resize beam to 3 x void height", "BEAM"),
    ("No automatic action", "NONE"),
]

EDGE_ITEMS = [
    ("Automatically move MEP + void", "MOVE"),
    ("No automatic action", "NONE"),
]

CLEARANCE_ROWS = [
    ("Round duct clearance", "clearance_round_duct_mm", "round_duct"),
    ("Rectangular duct clearance", "clearance_rectangular_duct_mm", "rectangular_duct"),
    ("Pipe clearance", "clearance_pipe_mm", "pipe"),
    ("Conduit clearance", "clearance_conduit_mm", "conduit"),
    ("Cable tray clearance", "clearance_cable_tray_mm", "cable_tray"),
    ("Other MEP clearance", "clearance_other_mep_mm", "other_mep"),
]


def get_config():
    return script.get_config(CONFIG_SECTION)


def cfg_get(cfg, name, default_value):
    try:
        value = getattr(cfg, name)
        if value is None or str(value).strip() == "":
            return default_value
        return str(value)
    except Exception:
        return default_value


def cfg_set(cfg, name, value):
    setattr(cfg, name, str(value))


def parse_hosts(value):
    if not value:
        return []
    return [x.strip() for x in str(value).split(",") if x.strip()]


def validate_mm(text, field_name):
    try:
        value = float(str(text).replace(",", "."))
        if value < 0:
            MessageBox.Show(field_name + " cannot be negative.", "PrefabAnalyser",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return None
        return value
    except Exception:
        MessageBox.Show(field_name + " must be a valid number in mm.", "PrefabAnalyser",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning)
        return None


def set_combo_by_value(combo, items, value):
    for i, item in enumerate(items):
        if item[1] == value:
            combo.SelectedIndex = i
            return
    combo.SelectedIndex = 0


def get_combo_value(combo, items, default_value):
    try:
        idx = combo.SelectedIndex
        if idx >= 0:
            return items[idx][1]
    except Exception:
        pass
    return default_value


class SettingsForm(Form):
    CONTENT_W = 1040

    def __init__(self):
        self.cfg = get_config()

        try:
            work = Screen.PrimaryScreen.WorkingArea
            form_w = min(1120, max(880, work.Width - 80))
            form_h = min(860, max(680, work.Height - 80))
        except Exception:
            form_w = 1120
            form_h = 860

        self.Text = "PrefabAnalyser - Settings"
        self.Size = Size(form_w, form_h)
        self.MinimumSize = Size(880, 680)
        self.StartPosition = FormStartPosition.CenterScreen
        self.FormBorderStyle = FormBorderStyle.Sizable
        self.MaximizeBox = True
        self.MinimizeBox = False
        self.BackColor = Color.FromArgb(245, 245, 245)
        self.AutoScaleMode = getattr(AutoScaleMode, "None")

        self.font_title = Font("Segoe UI", 15, FontStyle.Bold)
        self.font_subtitle = Font("Segoe UI", 10, FontStyle.Regular)
        self.font_section = Font("Segoe UI", 11, FontStyle.Bold)
        self.font_label = Font("Segoe UI", 10, FontStyle.Regular)
        self.font_input = Font("Segoe UI", 10, FontStyle.Regular)
        self.font_info = Font("Segoe UI", 9, FontStyle.Regular)

        self.host_checks = {}
        self.clearance_boxes = {}

        # Only show the currently selected host categories in the settings panel.
        # Non-selected host categories are hidden from the UI.
        self.visible_hosts = [h for h in parse_hosts(cfg_get(self.cfg, "hosts", DEFAULT_HOSTS)) if h in HOSTS]
        if not self.visible_hosts:
            self.visible_hosts = parse_hosts(DEFAULT_HOSTS)

        self._build_ui()
        self._load_values()

    def make_label(self, parent, text, x, y, w, h, font=None, color=None):
        lbl = Label()
        lbl.Text = text
        lbl.Location = Point(x, y)
        lbl.Size = Size(w, h)
        lbl.Font = font or self.font_label
        lbl.TextAlign = ContentAlignment.MiddleLeft
        lbl.AutoEllipsis = False
        if color:
            lbl.ForeColor = color
        parent.Controls.Add(lbl)
        return lbl

    def make_section(self, parent, title, y, height):
        box = Panel()
        box.Location = Point(20, y)
        box.Size = Size(self.CONTENT_W - 40, height)
        box.BackColor = Color.White
        box.BorderStyle = BorderStyle.FixedSingle
        parent.Controls.Add(box)

        self.make_label(box, title, 20, 14, self.CONTENT_W - 100, 36, self.font_section)
        return box

    def _build_ui(self):
        # Fixed bottom button bar
        self.button_bar = Panel()
        self.button_bar.Dock = DockStyle.Bottom
        self.button_bar.Height = 70
        self.button_bar.BackColor = Color.FromArgb(245, 245, 245)
        self.Controls.Add(self.button_bar)

        self.btn_cancel = Button()
        self.btn_cancel.Text = "Cancel"
        self.btn_cancel.Font = self.font_label
        self.btn_cancel.Size = Size(120, 38)
        self.btn_cancel.Anchor = AnchorStyles.Right | AnchorStyles.Top
        self.btn_cancel.Click += self.on_cancel
        self.button_bar.Controls.Add(self.btn_cancel)

        self.btn_save = Button()
        self.btn_save.Text = "Save"
        self.btn_save.Font = self.font_label
        self.btn_save.Size = Size(120, 38)
        self.btn_save.Anchor = AnchorStyles.Right | AnchorStyles.Top
        self.btn_save.Click += self.on_save
        self.button_bar.Controls.Add(self.btn_save)

        # Scrollable content
        self.scroll = Panel()
        self.scroll.Dock = DockStyle.Fill
        self.scroll.AutoScroll = True
        self.scroll.BackColor = Color.FromArgb(245, 245, 245)
        self.Controls.Add(self.scroll)

        self.content = Panel()
        self.content.Location = Point(0, 0)
        self.content.Size = Size(self.CONTENT_W, 1220)
        self.content.BackColor = Color.FromArgb(245, 245, 245)
        self.scroll.Controls.Add(self.content)

        # Header
        header = Panel()
        header.Location = Point(20, 20)
        header.Size = Size(self.CONTENT_W - 40, 120)
        header.BackColor = Color.FromArgb(245, 245, 245)
        self.content.Controls.Add(header)

        self.make_label(header, "PrefabAnalyser settings", 20, 20, self.CONTENT_W - 90, 60, self.font_title)
        self.make_label(
            header,
            "Central settings for Auto Voids and Update Voids",
            20, 72, self.CONTENT_W - 90, 34,
            self.font_subtitle,
            Color.FromArgb(80, 80, 80)
        )

        # MEP-specific clearances
        clearance_box = self.make_section(self.content, "MEP clearances", 155, 330)

        self.make_label(
            clearance_box,
            "Set a separate clearance for each MEP type.",
            40, 54, 850, 30,
            self.font_info,
            Color.FromArgb(80, 80, 80)
        )

        y = 92
        for label, cfg_name, key in CLEARANCE_ROWS:
            self.make_label(clearance_box, label, 40, y, 310, 34)

            tb = TextBox()
            tb.Font = self.font_input
            tb.Location = Point(380, y - 3)
            tb.Size = Size(260, 32)
            clearance_box.Controls.Add(tb)
            self.clearance_boxes[cfg_name] = tb

            self.make_label(clearance_box, "mm", 665, y, 80, 34)
            y += 38

        # Host categories
        # Only the selected/active host categories are shown.
        visible_host_count = len(self.visible_hosts)
        start_y = 88
        row_height = 38
        bottom_margin = 28
        host_box_height = max(150, start_y + visible_host_count * row_height + bottom_margin)
        hosts_box = self.make_section(self.content, "Active host categories", 505, host_box_height)

        self.make_label(
            hosts_box,
            "Only these host categories are currently active.",
            40, 54, 850, 30,
            self.font_info,
            Color.FromArgb(80, 80, 80)
        )

        for i, host_name in enumerate(self.visible_hosts):
            cb = CheckBox()
            cb.Text = host_name
            cb.Font = self.font_label
            cb.Checked = True
            cb.Location = Point(40, start_y + i * row_height)
            cb.Size = Size(500, 34)
            hosts_box.Controls.Add(cb)
            self.host_checks[host_name] = cb

        # Beam opening rules
        rules_y = 525 + host_box_height + 20
        rules_box = self.make_section(self.content, "Beam opening rules", rules_y, 205)

        self.make_label(rules_box, "Void height > 1/3 of beam height", 40, 68, 410, 38)
        self.cmb_rule = ComboBox()
        self.cmb_rule.Font = self.font_input
        self.cmb_rule.DropDownStyle = ComboBoxStyle.DropDownList
        self.cmb_rule.Location = Point(500, 65)
        self.cmb_rule.Size = Size(430, 32)
        for text, value in RULE_ITEMS:
            self.cmb_rule.Items.Add(text)
        rules_box.Controls.Add(self.cmb_rule)

        self.make_label(rules_box, "Edge distance < 50 mm", 40, 125, 410, 38)
        self.cmb_edge = ComboBox()
        self.cmb_edge.Font = self.font_input
        self.cmb_edge.DropDownStyle = ComboBoxStyle.DropDownList
        self.cmb_edge.Location = Point(500, 122)
        self.cmb_edge.Size = Size(430, 32)
        for text, value in EDGE_ITEMS:
            self.cmb_edge.Items.Add(text)
        rules_box.Controls.Add(self.cmb_edge)

        # Output behavior
        output_y = rules_y + 225
        output_box = self.make_section(self.content, "Output behavior", output_y, 115)

        self.chk_auto_close_output = CheckBox()
        self.chk_auto_close_output.Text = "Automatically close the result window after running"
        self.chk_auto_close_output.Font = self.font_label
        self.chk_auto_close_output.Location = Point(40, 65)
        self.chk_auto_close_output.Size = Size(860, 36)
        output_box.Controls.Add(self.chk_auto_close_output)

        # Info
        self.make_label(
            self.content,
            "Settings are saved in the pyRevit configuration. No Project Information parameters are required.",
            40, output_y + 135, self.CONTENT_W - 90, 34,
            self.font_info,
            Color.FromArgb(80, 80, 80)
        )

        self.content.Height = output_y + 190

        self.Resize += self.on_resize
        self.on_resize(None, None)

    def on_resize(self, sender, event):
        try:
            self.btn_save.Location = Point(self.button_bar.Width - 145, 16)
            self.btn_cancel.Location = Point(self.button_bar.Width - 275, 16)
        except Exception:
            pass

    def _load_values(self):
        # Load new MEP-specific settings
        for label, cfg_name, key in CLEARANCE_ROWS:
            default_value = DEFAULT_CLEARANCES.get(key, "30")
            self.clearance_boxes[cfg_name].Text = cfg_get(self.cfg, cfg_name, default_value)

        # Backward compatibility with older settings panel
        # If the new fields are empty for some reason, use the old round/rect values.
        old_round = cfg_get(self.cfg, "clearance_round_mm", "")
        old_rect = cfg_get(self.cfg, "clearance_rect_mm", "")

        if old_round:
            if not self.clearance_boxes["clearance_round_duct_mm"].Text:
                self.clearance_boxes["clearance_round_duct_mm"].Text = old_round
            if not self.clearance_boxes["clearance_pipe_mm"].Text:
                self.clearance_boxes["clearance_pipe_mm"].Text = old_round
            if not self.clearance_boxes["clearance_conduit_mm"].Text:
                self.clearance_boxes["clearance_conduit_mm"].Text = old_round

        if old_rect:
            if not self.clearance_boxes["clearance_rectangular_duct_mm"].Text:
                self.clearance_boxes["clearance_rectangular_duct_mm"].Text = old_rect
            if not self.clearance_boxes["clearance_cable_tray_mm"].Text:
                self.clearance_boxes["clearance_cable_tray_mm"].Text = old_rect

        hosts = parse_hosts(cfg_get(self.cfg, "hosts", DEFAULT_HOSTS))
        rule_mode = cfg_get(self.cfg, "rule_mode", DEFAULT_RULE_MODE)
        edge_mode = cfg_get(self.cfg, "edge_mode", DEFAULT_EDGE_MODE)
        auto_close_output = cfg_get(self.cfg, "auto_close_output", DEFAULT_AUTO_CLOSE_OUTPUT)

        for host_name, checkbox in self.host_checks.items():
            checkbox.Checked = True

        set_combo_by_value(self.cmb_rule, RULE_ITEMS, rule_mode)
        set_combo_by_value(self.cmb_edge, EDGE_ITEMS, edge_mode)

        try:
            self.chk_auto_close_output.Checked = str(auto_close_output).lower() in ["true", "1", "yes", "ja"]
        except Exception:
            pass

    def selected_hosts(self):
        result = []
        for host_name, checkbox in self.host_checks.items():
            if checkbox.Checked:
                result.append(host_name)
        return result

    def save_settings(self):
        # Validate and save MEP-specific clearances
        for label, cfg_name, key in CLEARANCE_ROWS:
            value = validate_mm(self.clearance_boxes[cfg_name].Text, label)
            if value is None:
                return False
            cfg_set(self.cfg, cfg_name, str(value))

        # Backward compatibility for scripts that still read old settings
        cfg_set(self.cfg, "clearance_round_mm", self.clearance_boxes["clearance_round_duct_mm"].Text)
        cfg_set(self.cfg, "clearance_rect_mm", self.clearance_boxes["clearance_rectangular_duct_mm"].Text)
        cfg_set(self.cfg, "clearance_rectangular_mm", self.clearance_boxes["clearance_rectangular_duct_mm"].Text)

        hosts = self.selected_hosts()
        if not hosts:
            MessageBox.Show("Select at least one host category.", "PrefabAnalyser",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return False

        rule_mode = get_combo_value(self.cmb_rule, RULE_ITEMS, DEFAULT_RULE_MODE)
        edge_mode = get_combo_value(self.cmb_edge, EDGE_ITEMS, DEFAULT_EDGE_MODE)
        auto_close_output = "True" if self.chk_auto_close_output.Checked else "False"

        cfg_set(self.cfg, "hosts", ",".join(hosts))
        cfg_set(self.cfg, "rule_mode", rule_mode)
        cfg_set(self.cfg, "edge_mode", edge_mode)
        cfg_set(self.cfg, "auto_close_output", auto_close_output)

        script.save_config()
        return True

    def on_save(self, sender, event):
        if self.save_settings():
            self.DialogResult = DialogResult.OK
            self.Close()

    def on_cancel(self, sender, event):
        self.DialogResult = DialogResult.Cancel
        self.Close()


def main():
    form = SettingsForm()
    result = form.ShowDialog()

    if result == DialogResult.OK:
        MessageBox.Show("Settings saved.", "PrefabAnalyser",
                        MessageBoxButtons.OK, MessageBoxIcon.Information)


if __name__ == "__main__":
    main()
