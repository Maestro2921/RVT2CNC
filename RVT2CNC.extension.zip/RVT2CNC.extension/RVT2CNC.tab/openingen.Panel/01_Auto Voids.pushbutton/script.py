# -*- coding: utf-8 -*-
from __future__ import division

import os
import math
from collections import OrderedDict, defaultdict

from pyrevit import revit, DB, forms, script

doc = revit.doc
uidoc = revit.uidoc
logger = script.get_logger()
output = script.get_output()

# ============================================================
# CONFIG
# ============================================================

ROUND_FAMILY_NAME = "PrefabAnalyser_Void_Round"
RECT_FAMILY_NAME = "PrefabAnalyser_Void_Rect"

ROUND_FAMILY_FILE = "PrefabAnalyser_Void_Round.rfa"
RECT_FAMILY_FILE = "PrefabAnalyser_Void_Rect.rfa"

HOST_CATEGORY_OPTIONS = OrderedDict([
    ("Structural Framing", DB.BuiltInCategory.OST_StructuralFraming),
    ("Structural Columns", DB.BuiltInCategory.OST_StructuralColumns),
    ("Walls", DB.BuiltInCategory.OST_Walls),
    ("Floors", DB.BuiltInCategory.OST_Floors),
    ("Roofs", DB.BuiltInCategory.OST_Roofs),
    ("Ceilings", DB.BuiltInCategory.OST_Ceilings),
    ("Generic Models", DB.BuiltInCategory.OST_GenericModel),
])

CLASH_CATEGORIES = [
    DB.BuiltInCategory.OST_DuctCurves,
    DB.BuiltInCategory.OST_PipeCurves,
    DB.BuiltInCategory.OST_Conduit,
    DB.BuiltInCategory.OST_CableTray,
    DB.BuiltInCategory.OST_DuctAccessory,
    DB.BuiltInCategory.OST_PipeAccessory,
    DB.BuiltInCategory.OST_DuctFitting,
    DB.BuiltInCategory.OST_PipeFitting,
]

DEFAULT_ROUND_CLEARANCE_MM = 30.0
DEFAULT_RECT_CLEARANCE_MM = 30.0

SEARCH_MARGIN_MM = 250.0
MIN_DEPTH_MM = 50.0
# Extra lengte langs MEP-as zodat schuine/bijna-loodrechte voids geen dun hoekje laten staan.
VOID_END_EXTRA_MM = 20.0
DEDUP_TOL_MM = 80.0
MIN_HOST_SIZE_MM = 50.0
MIN_INTERSECTION_VOL = 1e-7
MAX_VOID_HEIGHT_RATIO = 1.0 / 3.0
MIN_EDGE_CLEAR_MM = 50.0

DEDUPLICATE = True

# ============================================================
# SETTINGS FROM PREFABANALYSER SETTINGS PANEL
# ============================================================

SETTINGS_SECTION = "PrefabAnalyser"

def _cfg_get(cfg, name, default_value):
    try:
        value = getattr(cfg, name)
        if value is None or str(value).strip() == "":
            return default_value
        return str(value).strip()
    except Exception:
        return default_value


def _parse_float(value, default_value):
    try:
        return float(str(value).replace(",", "."))
    except Exception:
        return float(default_value)


def _parse_hosts(value):
    if not value:
        return ["Structural Framing"]
    hosts = [x.strip() for x in str(value).split(",") if x.strip()]
    return hosts if hosts else ["Structural Framing"]


def get_mep_clearance_settings(cfg):
    """
    New settings from the settings panel.
    Values are in mm.
    """
    round_duct_mm = _parse_float(_cfg_get(cfg, "clearance_round_duct_mm", _cfg_get(cfg, "clearance_round_mm", "30")), 30.0)
    rectangular_duct_mm = _parse_float(_cfg_get(cfg, "clearance_rectangular_duct_mm", _cfg_get(cfg, "clearance_rect_mm", "30")), 30.0)
    pipe_mm = _parse_float(_cfg_get(cfg, "clearance_pipe_mm", _cfg_get(cfg, "clearance_round_mm", str(round_duct_mm))), round_duct_mm)
    conduit_mm = _parse_float(_cfg_get(cfg, "clearance_conduit_mm", _cfg_get(cfg, "clearance_round_mm", str(round_duct_mm))), round_duct_mm)
    cable_tray_mm = _parse_float(_cfg_get(cfg, "clearance_cable_tray_mm", _cfg_get(cfg, "clearance_rect_mm", str(rectangular_duct_mm))), rectangular_duct_mm)
    other_mep_mm = _parse_float(_cfg_get(cfg, "clearance_other_mep_mm", "30"), 30.0)

    return {
        "round_duct_mm": round_duct_mm,
        "rectangular_duct_mm": rectangular_duct_mm,
        "pipe_mm": pipe_mm,
        "conduit_mm": conduit_mm,
        "cable_tray_mm": cable_tray_mm,
        "other_mep_mm": other_mep_mm,
    }


def get_prefab_settings():
    cfg = script.get_config(SETTINGS_SECTION)

    mep_clearances = get_mep_clearance_settings(cfg)

    # Backward-compatible general values
    round_mm = mep_clearances["round_duct_mm"]
    rect_mm = mep_clearances["rectangular_duct_mm"]

    hosts = _parse_hosts(_cfg_get(cfg, "hosts", "Structural Framing"))
    host_categories = []
    for host_name in hosts:
        if host_name in HOST_CATEGORY_OPTIONS:
            host_categories.append(HOST_CATEGORY_OPTIONS[host_name])

    if not host_categories:
        host_categories = [HOST_CATEGORY_OPTIONS["Structural Framing"]]

    rule_mode = _cfg_get(cfg, "rule_mode", "MEP")
    if rule_mode not in ["MEP", "BEAM", "NONE"]:
        rule_mode = "MEP"

    edge_mode = _cfg_get(cfg, "edge_mode", "MOVE")
    if edge_mode not in ["MOVE", "NONE"]:
        edge_mode = "MOVE"

    auto_close_output_raw = _cfg_get(cfg, "auto_close_output", "False")
    auto_close_output = str(auto_close_output_raw).lower() in ["true", "1", "yes", "ja"]

    return {
        "clearances": {
            "round_mm": round_mm,
            "rect_mm": rect_mm,
            "round_duct_mm": mep_clearances["round_duct_mm"],
            "rectangular_duct_mm": mep_clearances["rectangular_duct_mm"],
            "pipe_mm": mep_clearances["pipe_mm"],
            "conduit_mm": mep_clearances["conduit_mm"],
            "cable_tray_mm": mep_clearances["cable_tray_mm"],
            "other_mep_mm": mep_clearances["other_mep_mm"],
        },
        "clearance_round_mm": round_mm,
        "clearance_rect_mm": rect_mm,
        "clearance_round_ft": mm_to_ft(round_mm),
        "clearance_rect_ft": mm_to_ft(rect_mm),
        "mep_clearances": mep_clearances,
        "host_categories": host_categories,
        "host_names": hosts,
        "rule_mode": rule_mode,
        "edge_mode": edge_mode,
        "auto_close_output": auto_close_output,
    }


def get_mep_clearance_key(elem, profile=None):
    """
    Returns which clearance setting should be used for the given MEP element.
    """
    cname = get_category_name_lower(elem)

    if "pipe" in cname:
        return "pipe_mm"
    if "conduit" in cname:
        return "conduit_mm"
    if "cable tray" in cname or "cabletray" in cname:
        return "cable_tray_mm"
    if "duct" in cname:
        if profile and profile.get("is_round"):
            return "round_duct_mm"
        return "rectangular_duct_mm"

    if profile and profile.get("is_round"):
        return "round_duct_mm"

    return "other_mep_mm"


def get_clearance_mm_for_mep(elem, profile, settings):
    try:
        key = get_mep_clearance_key(elem, profile)
        return float(settings["mep_clearances"].get(key, 30.0))
    except Exception:
        try:
            if profile and profile.get("is_round"):
                return float(settings["clearance_round_mm"])
            return float(settings["clearance_rect_mm"])
        except Exception:
            return 30.0


def get_clearance_ft_for_mep(elem, profile, settings):
    return mm_to_ft(get_clearance_mm_for_mep(elem, profile, settings))


def clearance_key_to_label(key):
    labels = {
        "round_duct_mm": "Round duct",
        "rectangular_duct_mm": "Rectangular duct",
        "pipe_mm": "Pipe",
        "conduit_mm": "Conduit",
        "cable_tray_mm": "Cable tray",
        "other_mep_mm": "Other MEP",
    }
    return labels.get(key, "MEP")

def rule_mode_to_text(rule_mode):
    if rule_mode == "MEP":
        return "MEP + void automatisch verkleinen"
    if rule_mode == "BEAM":
        return "Balk automatisch aanpassen naar 3 x voidhoogte"
    return "Geen automatische actie"


def edge_mode_to_text(edge_mode):
    if edge_mode == "MOVE":
        return "MEP + void automatisch verplaatsen"
    return "Geen automatische actie"


# ============================================================
# UNITS
# ============================================================

def mm_to_ft(mm):
    return mm / 304.8


def ft_to_mm(ft):
    return ft * 304.8


def fmt_mm(ft_val):
    return "{:.0f} mm".format(ft_to_mm(ft_val or 0.0))


def get_element_name(elem, fallback=""):
    try:
        return DB.Element.Name.GetValue(elem)
    except Exception:
        pass
    try:
        return elem.Name
    except Exception:
        pass
    try:
        p = elem.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
        if p:
            val = p.AsString()
            if val:
                return val
    except Exception:
        pass
    return fallback


# ============================================================
# ID HELPERS
# ============================================================

def eid(elem_or_id):
    try:
        obj = elem_or_id.Id
    except Exception:
        obj = elem_or_id

    try:
        return obj.IntegerValue
    except Exception:
        pass

    try:
        return obj.Value
    except Exception:
        pass

    try:
        return str(obj)
    except Exception:
        return "<no-id>"


# ============================================================
# INPUT
# ============================================================

def _ask_positive_mm(title, prompt, default_value):
    res = forms.ask_for_string(default=str(default_value), prompt=prompt, title=title)
    if res is None:
        return None

    try:
        value = float(str(res).replace(",", "."))
        if value < 0:
            forms.alert("Waarde mag niet negatief zijn.", exitscript=True)
            return None
        return value
    except Exception:
        forms.alert("Ongeldige numerieke waarde. Geef een getal in mm op.", exitscript=True)
        return None


def select_host_categories():
    options = list(HOST_CATEGORY_OPTIONS.keys())
    selected = forms.SelectFromList.show(
        options,
        multiselect=True,
        title="Selecteer categorieën waarin voids mogen geplaatst worden"
    )
    if not selected:
        return None
    return [HOST_CATEGORY_OPTIONS[x] for x in selected]


def ask_default_clearances():
    round_mm = _ask_positive_mm(
        "PrefabAnalyser - Round clearance",
        "Geef de default clearance in mm voor ROUND voids:",
        int(DEFAULT_ROUND_CLEARANCE_MM)
    )
    if round_mm is None:
        return None

    rect_mm = _ask_positive_mm(
        "PrefabAnalyser - Rectangular clearance",
        "Geef de default clearance in mm voor RECTANGULAR voids:",
        int(DEFAULT_RECT_CLEARANCE_MM)
    )
    if rect_mm is None:
        return None

    return {"round_mm": round_mm, "rect_mm": rect_mm}


# ============================================================
# XYZ HELPERS
# ============================================================

def xyz_add(a, b):
    return DB.XYZ(a.X + b.X, a.Y + b.Y, a.Z + b.Z)


def xyz_sub(a, b):
    return DB.XYZ(a.X - b.X, a.Y - b.Y, a.Z - b.Z)



def xyz_mul(v, scalar):
    return DB.XYZ(v.X * scalar, v.Y * scalar, v.Z * scalar)

def xyz_dot(a, b):
    return a.X * b.X + a.Y * b.Y + a.Z * b.Z


def xyz_cross(a, b):
    return DB.XYZ(
        a.Y * b.Z - a.Z * b.Y,
        a.Z * b.X - a.X * b.Z,
        a.X * b.Y - a.Y * b.X
    )


def xyz_len(v):
    return math.sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z)


def xyz_norm(v):
    l = xyz_len(v)
    if l < 1e-12:
        return None
    return DB.XYZ(v.X / l, v.Y / l, v.Z / l)


def xyz_distance(a, b):
    return xyz_len(xyz_sub(a, b))


def almost_equal(a, b, tol=1e-9):
    return abs(a - b) <= tol


# ============================================================
# GENERIC HELPERS
# ============================================================

def get_category_name(elem):
    try:
        return elem.Category.Name
    except Exception:
        return "<geen categorie>"


def get_category_name_lower(elem):
    try:
        return str(get_category_name(elem)).strip().lower()
    except Exception:
        return ""


def get_bbox(elem):
    try:
        return elem.get_BoundingBox(None)
    except Exception:
        return None


def bbox_center(bb):
    return DB.XYZ(
        (bb.Min.X + bb.Max.X) / 2.0,
        (bb.Min.Y + bb.Max.Y) / 2.0,
        (bb.Min.Z + bb.Max.Z) / 2.0
    )


def get_bbox_dimensions(bb):
    return (abs(bb.Max.X - bb.Min.X), abs(bb.Max.Y - bb.Min.Y), abs(bb.Max.Z - bb.Min.Z))


def expand_outline_from_bbox(bb, offset_ft):
    return DB.Outline(
        DB.XYZ(bb.Min.X - offset_ft, bb.Min.Y - offset_ft, bb.Min.Z - offset_ft),
        DB.XYZ(bb.Max.X + offset_ft, bb.Max.Y + offset_ft, bb.Max.Z + offset_ft)
    )


def get_param(elem, name):
    try:
        return elem.LookupParameter(name)
    except Exception:
        return None


def set_param(elem, name, value):
    p = get_param(elem, name)
    if not p or p.IsReadOnly:
        return False
    try:
        if p.StorageType == DB.StorageType.Double:
            p.Set(float(value))
            return True
        elif p.StorageType == DB.StorageType.String:
            p.Set(str(value))
            return True
        elif p.StorageType == DB.StorageType.Integer:
            p.Set(int(value))
            return True
    except Exception:
        logger.warning("Kon parameter '{}' niet zetten op {} voor element {}".format(name, value, eid(elem)))
        return False
    return False


def try_get_double_param(elem, names):
    for n in names:
        p = get_param(elem, n)
        if p and p.StorageType == DB.StorageType.Double:
            try:
                return p.AsDouble()
            except Exception:
                pass
    return None


def get_level_for_element(elem):
    try:
        if hasattr(elem, "LevelId") and elem.LevelId != DB.ElementId.InvalidElementId:
            lvl = doc.GetElement(elem.LevelId)
            if lvl:
                return lvl
    except Exception:
        pass

    try:
        p = elem.get_Parameter(DB.BuiltInParameter.FAMILY_LEVEL_PARAM)
        if p and p.AsElementId() != DB.ElementId.InvalidElementId:
            lvl = doc.GetElement(p.AsElementId())
            if lvl:
                return lvl
    except Exception:
        pass

    return DB.FilteredElementCollector(doc).OfClass(DB.Level).FirstElement()


# ============================================================
# GEOMETRY
# ============================================================

def get_solids(element):
    solids = []
    opt = DB.Options()
    opt.ComputeReferences = False
    opt.IncludeNonVisibleObjects = False
    opt.DetailLevel = DB.ViewDetailLevel.Fine

    try:
        geom = element.get_Geometry(opt)
    except Exception:
        geom = None

    if not geom:
        return solids

    def walk(geom_elem):
        for g in geom_elem:
            if isinstance(g, DB.Solid):
                try:
                    if g.Volume and g.Volume > 1e-9:
                        solids.append(g)
                except Exception:
                    pass
            elif isinstance(g, DB.GeometryInstance):
                try:
                    walk(g.GetInstanceGeometry())
                except Exception:
                    pass

    walk(geom)
    return solids


def intersect_solids(solid_a, solid_b):
    try:
        return DB.BooleanOperationsUtils.ExecuteBooleanOperation(
            solid_a,
            solid_b,
            DB.BooleanOperationsType.Intersect
        )
    except Exception:
        return None


# ============================================================
# FAMILY LOADING
# ============================================================

class _FamilyLoadOptions(DB.IFamilyLoadOptions):
    def OnFamilyFound(self, familyInUse, overwriteParameterValues):
        overwriteParameterValues.Value = True
        return True

    def OnSharedFamilyFound(self, sharedFamily, familyInUse, source, overwriteParameterValues):
        overwriteParameterValues.Value = True
        return True


def find_family_symbols_by_family_name(family_name):
    result = []
    col = DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol)
    for sym in col:
        try:
            if sym.Family and sym.Family.Name == family_name:
                result.append(sym)
        except Exception:
            pass
    return result


def ensure_family_loaded(family_name, family_file_name):
    symbols = find_family_symbols_by_family_name(family_name)
    if symbols:
        sym = symbols[0]
        if not sym.IsActive:
            with revit.Transaction("Activate symbol {}".format(family_name)):
                sym.Activate()
                doc.Regenerate()
        return sym

    script_dir = os.path.dirname(__file__)
    family_path = os.path.join(script_dir, family_file_name)
    if not os.path.exists(family_path):
        raise Exception("Family '{}' niet gevonden naast script: {}".format(family_name, family_path))

    with revit.Transaction("Load family {}".format(family_name)):
        opts = _FamilyLoadOptions()
        loaded = doc.LoadFamily(family_path, opts)
        if not loaded:
            raise Exception("Laden van family '{}' mislukt".format(family_name))

    symbols = find_family_symbols_by_family_name(family_name)
    if not symbols:
        raise Exception("Family '{}' geladen maar geen symbol gevonden".format(family_name))

    sym = symbols[0]
    if not sym.IsActive:
        with revit.Transaction("Activate symbol {}".format(family_name)):
            sym.Activate()
            doc.Regenerate()

    return sym


# ============================================================
# COLLECTION
# ============================================================

def host_is_valid(host):
    try:
        if host.Category is None:
            return False
        if host.ViewSpecific:
            return False

        bb = get_bbox(host)
        if not bb:
            return False

        dx, dy, dz = get_bbox_dimensions(bb)
        min_size_ft = mm_to_ft(MIN_HOST_SIZE_MM)
        if max(dx, dy, dz) < min_size_ft:
            return False

        return True
    except Exception:
        return False


def collect_elements_by_categories(bics):
    elems = []
    for bic in bics:
        try:
            col = DB.FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType().ToElements()
            elems.extend(list(col))
        except Exception:
            pass
    return elems


def collect_candidate_hosts(selected_host_categories):
    return [h for h in collect_elements_by_categories(selected_host_categories) if host_is_valid(h)]


# ============================================================
# MEP PROFIEL / RICHTING
# ============================================================

def get_location_curve_direction(elem):
    """ALTIJD exact 1 XYZ teruggeven of None. Geen tuples."""
    try:
        lc = elem.Location
        if isinstance(lc, DB.LocationCurve) and lc.Curve:
            p0 = lc.Curve.GetEndPoint(0)
            p1 = lc.Curve.GetEndPoint(1)
            return xyz_norm(xyz_sub(p1, p0))
    except Exception:
        pass
    return None


def get_element_axis_from_bbox(bb):
    dx, dy, dz = get_bbox_dimensions(bb)
    if dx >= dy and dx >= dz:
        return DB.XYZ(1, 0, 0)
    elif dy >= dx and dy >= dz:
        return DB.XYZ(0, 1, 0)
    return DB.XYZ(0, 0, 1)


def detect_is_round_profile(elem):
    cname = get_category_name(elem)

    if cname in ["Pipes", "Conduits", "Pipe Fittings", "Pipe Accessories"]:
        return True

    diameter = try_get_double_param(elem, ["Diameter", "Nominal Diameter"])
    width = try_get_double_param(elem, ["Width"])
    height = try_get_double_param(elem, ["Height"])

    if diameter and diameter > 0 and not (width and height):
        return True

    return False


def get_mep_profile_dimensions(elem):
    bb = get_bbox(elem)
    if not bb:
        return None

    axis = get_location_curve_direction(elem)
    if axis is None:
        axis = get_element_axis_from_bbox(bb)

    is_round = detect_is_round_profile(elem)

    diameter = try_get_double_param(elem, ["Diameter", "Nominal Diameter"])
    width = try_get_double_param(elem, ["Width"])
    height = try_get_double_param(elem, ["Height"])

    dx, dy, dz = get_bbox_dimensions(bb)
    absax = DB.XYZ(abs(axis.X), abs(axis.Y), abs(axis.Z))

    if absax.X >= absax.Y and absax.X >= absax.Z:
        transverse = [dy, dz]
    elif absax.Y >= absax.X and absax.Y >= absax.Z:
        transverse = [dx, dz]
    else:
        transverse = [dx, dy]

    if is_round:
        if not diameter or diameter <= 0:
            diameter = max(transverse)

        return {
            "is_round": True,
            "host_diameter": diameter,
            "host_width": None,
            "host_height": None,
            "axis": axis,
            "center": bbox_center(bb),
        }

    if not width or width <= 0:
        width = transverse[0]

    if not height or height <= 0:
        height = transverse[1] if len(transverse) > 1 else transverse[0]

    return {
        "is_round": False,
        "host_diameter": None,
        "host_width": width,
        "host_height": height,
        "axis": axis,
        "center": bbox_center(bb),
    }


def get_line_bbox_intersection_length(bb, axis, point):
    """
    Berekent exact hoe lang de MEP-centerline door de host-bounding box loopt.
    Bij schuine doorvoeren is dit langer dan de gewone dikte, maar niet overdreven lang.
    """
    if not bb or not axis or not point:
        return None

    d = xyz_norm(axis)
    if not d:
        return None

    t_min = -1e30
    t_max = 1e30

    checks = [
        (point.X, d.X, bb.Min.X, bb.Max.X),
        (point.Y, d.Y, bb.Min.Y, bb.Max.Y),
        (point.Z, d.Z, bb.Min.Z, bb.Max.Z),
    ]

    for p, v, mn, mx in checks:
        if abs(v) < 1e-12:
            if p < mn or p > mx:
                return None
            continue

        t1 = (mn - p) / v
        t2 = (mx - p) / v

        if t1 > t2:
            t1, t2 = t2, t1

        if t1 > t_min:
            t_min = t1
        if t2 < t_max:
            t_max = t2

        if t_min > t_max:
            return None

    length = abs(t_max - t_min)
    if length <= 1e-9:
        return None

    return length


def _bbox_axis_dimensions(bb):
    return [
        ("X", abs(bb.Max.X - bb.Min.X), DB.XYZ.BasisX),
        ("Y", abs(bb.Max.Y - bb.Min.Y), DB.XYZ.BasisY),
        ("Z", abs(bb.Max.Z - bb.Min.Z), DB.XYZ.BasisZ),
    ]


def _abs_dot(a, b):
    try:
        return abs(xyz_dot(xyz_norm(a), xyz_norm(b)))
    except Exception:
        return 0.0


def get_host_thickness_axis_and_depth(host, axis):
    """
    Bepaalt welke host-richting de echte dikte is die de void moet doorsnijden.

    Waarom niet de volledige bbox-snijafstand?
    Bij balken kan de MEP-richting bij een schuine snede een component in de
    lengterichting krijgen. Een bbox-line-intersection gebruikt dan soms de
    volledige balklengte, waardoor de void veel te lang wordt.

    Deze functie kiest daarom eerst de echte dikterichting:
    - floors/roofs/ceilings: Z-dikte
    - walls: wall.Width + wall.Orientation waar mogelijk
    - framing/columns/generic: langste bbox-as wordt als lengte uitgesloten
      als die duidelijk langer is dan de andere assen. Daarna kiest hij de
      cross-section-as die het best bij de MEP-richting past.
    """
    bb = get_bbox(host)
    if not bb:
        return DB.XYZ.BasisZ, mm_to_ft(MIN_DEPTH_MM)

    cname = get_category_name_lower(host)
    d = xyz_norm(axis) if axis is not None else DB.XYZ.BasisZ

    dx, dy, dz = get_bbox_dimensions(bb)

    if cname in ["floors", "roofs", "ceilings"]:
        return DB.XYZ.BasisZ, dz if dz > 0 else mm_to_ft(MIN_DEPTH_MM)

    if cname == "walls":
        try:
            if hasattr(host, "Orientation") and host.Orientation:
                n = xyz_norm(host.Orientation)
                if hasattr(host, "Width") and host.Width and host.Width > 0:
                    return n, host.Width
        except Exception:
            pass
        try:
            if hasattr(host, "Width") and host.Width and host.Width > 0:
                # fallback: kies de bbox-as die het dichtst bij de MEP-richting ligt
                axes = _bbox_axis_dimensions(bb)
                best = max(axes, key=lambda item: _abs_dot(d, item[2]))
                return best[2], host.Width
        except Exception:
            pass

    axes = _bbox_axis_dimensions(bb)
    axes_sorted = sorted(axes, key=lambda item: item[1], reverse=True)

    # Voor balken is de grootste afmeting meestal de lengterichting.
    # Sluit die uit zodat een schuine MEP niet plots de volledige balklengte als depth krijgt.
    candidate_axes = axes
    if len(axes_sorted) >= 3:
        longest = axes_sorted[0]
        second = axes_sorted[1]
        if longest[1] > second[1] * 1.75:
            candidate_axes = axes_sorted[1:]

    # Kies van de overblijvende dikte-assen degene die het meest in de MEP-richting ligt.
    best = max(candidate_axes, key=lambda item: _abs_dot(d, item[2]))
    if best[1] <= 0:
        return best[2], mm_to_ft(MIN_DEPTH_MM)

    return best[2], best[1]


def get_bbox_simple_depth_for_host(host, axis):
    """
    Exacte hostdikte voor loodrechte doorvoeren.
    """
    n, depth = get_host_thickness_axis_and_depth(host, axis)
    return depth if depth and depth > 0 else mm_to_ft(MIN_DEPTH_MM)


def get_host_depth_along_axis(host, axis, center_point=None, profile_radius_ft=None):
    """
    Void depth volgens de echte hostdikte en de actuele MEP-hoek.

    - Loodrecht: exact hostdikte.
    - Schuin: t / cos(theta) + profielmarge.
      De profielmarge houdt rekening met diameter/breedte van de opening zodat
      ook de buitenste hoeken/randen door de host snijden.
    - Geen volledige bbox-snijafstand meer, want dat maakte balken veel te lang.
    """
    if axis is None:
        axis = DB.XYZ.BasisZ

    d = xyz_norm(axis)
    if not d:
        return mm_to_ft(MIN_DEPTH_MM)

    thickness_axis, thickness = get_host_thickness_axis_and_depth(host, d)
    if not thickness or thickness <= 0:
        thickness = mm_to_ft(MIN_DEPTH_MM)

    n = xyz_norm(thickness_axis)
    if not n:
        return max(thickness, mm_to_ft(MIN_DEPTH_MM))

    cosang = abs(xyz_dot(d, n))

    # Loodrecht / bijna loodrecht: exact hostdikte, geen marge.
    if cosang >= 0.9995:
        return max(thickness, mm_to_ft(MIN_DEPTH_MM))

    # Als de richting bijna parallel met het hostvlak loopt, wordt de theoretische
    # lengte oneindig. Beperk dit zodat de void niet absurd lang wordt.
    cos_eff = max(cosang, 0.20)

    base_depth = thickness / cos_eff

    # Profielmarge: cylinder/box moet met zijn buitenrand ook door beide zijden.
    # Benadering: extra lengte = 2 * profielradius * tan(theta)
    if profile_radius_ft is None or profile_radius_ft <= 0:
        profile_radius_ft = mm_to_ft(25.0)

    tanang = math.sqrt(max(0.0, 1.0 - cos_eff * cos_eff)) / cos_eff
    profile_margin = 2.0 * profile_radius_ft * tanang

    # Kleine productiemarge, alleen bij schuin.
    safety_margin = mm_to_ft(VOID_END_EXTRA_MM * 2.0)

    depth = base_depth + profile_margin + safety_margin

    # Redelijke bovengrens tegen extreme bijna-parallelle gevallen.
    max_depth = max(thickness * 6.0, thickness + profile_radius_ft * 8.0 + mm_to_ft(VOID_END_EXTRA_MM * 2.0), mm_to_ft(1200.0))
    if depth > max_depth:
        depth = max_depth

    return max(depth, thickness, mm_to_ft(MIN_DEPTH_MM))



def get_location_point(elem):
    try:
        loc = elem.Location
        if isinstance(loc, DB.LocationPoint):
            return loc.Point
        if isinstance(loc, DB.LocationCurve) and loc.Curve:
            return loc.Curve.Evaluate(0.5, True)
    except Exception:
        pass

    bb = get_bbox(elem)
    if bb:
        return bbox_center(bb)
    return None


def get_mep_center_anchor_point(mep_elem, reference_pt=None):
    try:
        loc = mep_elem.Location
        if isinstance(loc, DB.LocationPoint):
            return loc.Point
        if isinstance(loc, DB.LocationCurve) and loc.Curve:
            curve = loc.Curve
            if reference_pt is not None:
                try:
                    proj = curve.Project(reference_pt)
                    if proj:
                        return proj.XYZPoint
                except Exception:
                    pass
            try:
                return curve.Evaluate(0.5, True)
            except Exception:
                pass
    except Exception:
        pass

    return get_location_point(mep_elem)


def get_host_thickness_center_value(host, thickness_axis):
    bb = get_bbox(host)
    if not bb:
        pt = get_location_point(host)
        if pt:
            return xyz_dot(pt, thickness_axis)
        return None

    corners = [
        DB.XYZ(bb.Min.X, bb.Min.Y, bb.Min.Z),
        DB.XYZ(bb.Min.X, bb.Min.Y, bb.Max.Z),
        DB.XYZ(bb.Min.X, bb.Max.Y, bb.Min.Z),
        DB.XYZ(bb.Min.X, bb.Max.Y, bb.Max.Z),
        DB.XYZ(bb.Max.X, bb.Min.Y, bb.Min.Z),
        DB.XYZ(bb.Max.X, bb.Min.Y, bb.Max.Z),
        DB.XYZ(bb.Max.X, bb.Max.Y, bb.Min.Z),
        DB.XYZ(bb.Max.X, bb.Max.Y, bb.Max.Z),
    ]
    dots = [xyz_dot(c, thickness_axis) for c in corners]
    if not dots:
        return None
    return (min(dots) + max(dots)) / 2.0


def get_target_void_center_on_host_center(host, mep_elem, mep_axis, fallback_pt=None):
    """
    Center the void on the center plane of the host thickness.

    This fixes walls: the solid-intersection bounding box can produce a point
    near one wall face. For a clean opening, the void family origin must sit on
    the host center plane while still lying on the MEP centerline.
    """
    if host is None or mep_elem is None:
        return fallback_pt

    d = xyz_norm(mep_axis)
    if not d:
        return fallback_pt

    thickness_axis, thickness = get_host_thickness_axis_and_depth(host, d)
    n = xyz_norm(thickness_axis)
    if not n:
        return fallback_pt

    target_d = get_host_thickness_center_value(host, n)
    if target_d is None:
        return fallback_pt

    # Prefer exact intersection of the MEP line with the host center plane.
    try:
        loc = mep_elem.Location
        if isinstance(loc, DB.LocationCurve) and loc.Curve:
            curve = loc.Curve
            p0 = curve.GetEndPoint(0)
            p1 = curve.GetEndPoint(1)
            line_vec = xyz_sub(p1, p0)
            denom = xyz_dot(line_vec, n)

            if abs(denom) > 1e-9:
                t = (target_d - xyz_dot(p0, n)) / denom
                # Allow a bit outside the original segment for fittings/accessories.
                if t < -0.25:
                    t = -0.25
                if t > 1.25:
                    t = 1.25
                return xyz_add(p0, xyz_mul(line_vec, t))
    except Exception:
        pass

    # Fallback: project a point on the MEP to the host center plane along host thickness normal.
    anchor = get_mep_center_anchor_point(mep_elem, fallback_pt)
    if anchor is None:
        anchor = fallback_pt
    if anchor is None:
        return None

    current_d = xyz_dot(anchor, n)
    delta = target_d - current_d
    return xyz_add(anchor, xyz_mul(n, delta))


def get_structural_framing_height_param(host):
    for n in ["h", "Height", "Depth", "d"]:
        p = get_param(host, n)
        if p and (not p.IsReadOnly) and p.StorageType == DB.StorageType.Double:
            return p
    return None


def get_host_vertical_range(host):
    bb = get_bbox(host)
    if not bb:
        return None
    return bb.Min.Z, bb.Max.Z


def get_host_vertical_height(host):
    vr = get_host_vertical_range(host)
    if not vr:
        return None
    return abs(vr[1] - vr[0])


def get_mep_vertical_size_ft(mep):
    if not mep:
        return None
    if mep["is_round"]:
        return mep.get("host_diameter")
    return mep.get("host_height")


def get_void_vertical_size_ft(mep, clearances_or_settings, clash_elem=None):
    if not mep:
        return None

    # Accept both the new full settings dict and the old clearances dict.
    if isinstance(clearances_or_settings, dict) and "mep_clearances" in clearances_or_settings:
        clearance_ft = get_clearance_ft_for_mep(clash_elem, mep, clearances_or_settings)
    else:
        if mep["is_round"]:
            clearance_ft = mm_to_ft(clearances_or_settings["round_mm"])
        else:
            clearance_ft = mm_to_ft(clearances_or_settings["rect_mm"])

    if mep["is_round"]:
        return (mep.get("host_diameter") or 0.0) + 2.0 * clearance_ft
    return (mep.get("host_height") or 0.0) + 2.0 * clearance_ft


def set_mep_vertical_size(clash_elem, mep, new_size_ft):
    if not mep or new_size_ft is None or new_size_ft <= 0:
        return False, "Ongeldige nieuwe MEP-grootte"

    names = ["Diameter", "Nominal Diameter"] if mep["is_round"] else ["Height"]
    for n in names:
        p = get_param(clash_elem, n)
        if p and (not p.IsReadOnly) and p.StorageType == DB.StorageType.Double:
            try:
                p.Set(float(new_size_ft))
                return True, "MEP-parameter '{}' aangepast".format(n)
            except Exception as ex:
                return False, "Kon MEP-parameter '{}' niet aanpassen: {}".format(n, ex)

    return False, "Geen schrijfbare hoogte/diameter-parameter gevonden op MEP-element"


INITIALS_CACHE = None
OVERSIZE_RESOLUTION_CACHE = None


def get_family_symbol_of_host(host):
    try:
        if isinstance(host, DB.FamilyInstance) and host.Symbol:
            return host.Symbol
    except Exception:
        pass
    try:
        tid = host.GetTypeId()
        if tid and tid != DB.ElementId.InvalidElementId:
            t = doc.GetElement(tid)
            if isinstance(t, DB.ElementType):
                return t
    except Exception:
        pass
    return None


def get_first_writable_double_param(elem, names):
    for n in names:
        p = get_param(elem, n)
        if p and (not p.IsReadOnly) and p.StorageType == DB.StorageType.Double:
            return p
    return None


def ensure_initials():
    global INITIALS_CACHE
    if INITIALS_CACHE:
        return INITIALS_CACHE
    initials = forms.ask_for_string(
        default="TM",
        prompt="Geef de initialen voor de nieuwe balktype naam op:",
        title="PrefabAnalyser - initialen"
    )
    if initials is None:
        return None
    initials = str(initials).strip().replace(" ", "")
    if not initials:
        forms.alert("Geen geldige initialen opgegeven.")
        return None
    INITIALS_CACHE = initials
    return INITIALS_CACHE


def build_unique_type_name(base_name):
    existing = set()
    try:
        for et in DB.FilteredElementCollector(doc).OfClass(DB.ElementType):
            try:
                nm = get_element_name(et, "")
                if nm:
                    existing.add(nm)
            except Exception:
                pass
    except Exception:
        pass

    if base_name not in existing:
        return base_name

    idx = 1
    while True:
        candidate = "{}_{}".format(base_name, idx)
        if candidate not in existing:
            return candidate
        idx += 1


def safe_duplicate_symbol(symbol, preferred_name):
    try_name = preferred_name
    idx = 1
    while True:
        try:
            dup = symbol.Duplicate(try_name)
            try:
                dup = doc.GetElement(dup.Id) if hasattr(dup, "Id") else dup
            except Exception:
                pass
            return dup, try_name
        except Exception:
            idx += 1
            try_name = "{}_{}".format(preferred_name, idx)


def apply_family_symbol_to_host(host, new_symbol):
    try:
        if isinstance(host, DB.FamilyInstance):
            host.Symbol = new_symbol
            doc.Regenerate()
            return host.Symbol and host.Symbol.Id == new_symbol.Id
    except Exception:
        pass

    try:
        host.ChangeTypeId(new_symbol.Id)
        doc.Regenerate()
        return host.GetTypeId() == new_symbol.Id
    except Exception:
        pass

    try:
        return host.GetTypeId() == new_symbol.Id
    except Exception:
        return False


def find_existing_beam_symbol(symbol, target_width_ft, target_height_ft):
    family = None
    try:
        family = symbol.Family
    except Exception:
        family = None

    if not family:
        return None

    try:
        symbol_ids = family.GetFamilySymbolIds()
    except Exception:
        symbol_ids = []

    for sid in symbol_ids:
        try:
            cand = doc.GetElement(sid)
            if not cand:
                continue
            cand_width = try_get_double_param(cand, ["b", "Width", "Breedte", "w"])
            cand_height = try_get_double_param(cand, ["h", "Height", "Depth", "Hoogte", "d"])
            if cand_width is None or cand_height is None:
                continue
            if abs(cand_width - target_width_ft) <= mm_to_ft(1.0) and abs(cand_height - target_height_ft) <= mm_to_ft(1.0):
                return cand
        except Exception:
            pass

    return None


def resize_structural_framing_height(host, required_height_ft):
    symbol = get_family_symbol_of_host(host)
    if not symbol:
        return False, "Kon balktype niet vinden"

    width_param = get_first_writable_double_param(symbol, ["b", "Width", "Breedte", "w"])
    height_param = get_first_writable_double_param(symbol, ["h", "Height", "Depth", "Hoogte", "d"])
    if not width_param:
        return False, "Geen schrijfbare breedteparameter gevonden op het balktype"
    if not height_param:
        return False, "Geen schrijfbare hoogteparameter gevonden op het balktype"

    try:
        width_ft = width_param.AsDouble()
    except Exception:
        return False, "Kon breedteparameter niet uitlezen"

    existing_symbol = find_existing_beam_symbol(symbol, width_ft, required_height_ft)
    if existing_symbol:
        applied = apply_family_symbol_to_host(host, existing_symbol)
        if not applied:
            return False, "Bestaand balktype gevonden maar niet kunnen toepassen op de balk"
        return True, "Bestaand balktype '{}' toegepast | breedte {} | hoogte {}".format(
            get_element_name(existing_symbol, "<type>"), fmt_mm(width_ft), fmt_mm(required_height_ft)
        )

    width_mm = int(round(ft_to_mm(width_ft)))
    height_mm = int(round(ft_to_mm(required_height_ft)))
    base_name = "{}x{}mm".format(width_mm, height_mm)
    preferred_name = build_unique_type_name(base_name)

    new_symbol, used_name = safe_duplicate_symbol(symbol, preferred_name)
    if not new_symbol:
        return False, "Kon balktype niet dupliceren"

    new_height_param = get_first_writable_double_param(new_symbol, ["h", "Height", "Depth", "Hoogte", "d"])
    if not new_height_param:
        return False, "Nieuw balktype aangemaakt maar hoogteparameter niet gevonden"

    try:
        new_height_param.Set(float(required_height_ft))
        doc.Regenerate()
    except Exception as ex:
        return False, "Kon hoogte van nieuw balktype niet aanpassen: {}".format(ex)

    try:
        applied_height_ft = new_height_param.AsDouble()
    except Exception:
        applied_height_ft = None

    if applied_height_ft is None or abs(applied_height_ft - required_height_ft) > mm_to_ft(1.0):
        return False, "Nieuw balktype aangemaakt maar hoogte niet correct aangepast"

    applied = apply_family_symbol_to_host(host, new_symbol)
    if not applied:
        return False, "Nieuw balktype aangemaakt maar niet kunnen toepassen op de balk"

    return True, "Nieuw balktype '{}' toegepast | breedte {} | hoogte {}".format(
        used_name, fmt_mm(width_ft), fmt_mm(required_height_ft)
    )


def move_element_vertical(clash_elem, delta_z_ft):
    if abs(delta_z_ft) <= mm_to_ft(1.0):
        return True, "Geen verplaatsing nodig"

    was_pinned = False
    try:
        was_pinned = bool(getattr(clash_elem, "Pinned", False))
    except Exception:
        was_pinned = False

    try:
        if was_pinned:
            try:
                clash_elem.Pinned = False
            except Exception:
                pass

        move_vec = DB.XYZ(0, 0, delta_z_ft)

        try:
            loc = clash_elem.Location
            if loc and hasattr(loc, "Move"):
                loc.Move(move_vec)
            else:
                DB.ElementTransformUtils.MoveElement(doc, clash_elem.Id, move_vec)
        except Exception:
            DB.ElementTransformUtils.MoveElement(doc, clash_elem.Id, move_vec)

        return True, "Element verticaal verplaatst met {}".format(fmt_mm(abs(delta_z_ft)))
    except Exception as ex:
        return False, "Kon element niet verticaal verplaatsen: {}".format(ex)
    finally:
        if was_pinned:
            try:
                clash_elem.Pinned = True
            except Exception:
                pass


def ask_user_resolution(title, message, options):
    try:
        choice = forms.CommandSwitchWindow.show(options, message=message, title=title)
        return choice
    except Exception:
        forms.alert(message)
        return None


def enforce_beam_void_rules(host, clash_elem, mep, center, settings):
    host_cat = get_category_name(host)
    if host_cat != "Structural Framing":
        return True, center, mep, []

    actions = []
    min_edge_clear_ft = mm_to_ft(MIN_EDGE_CLEAR_MM)

    while True:
        doc.Regenerate()
        mep = get_mep_profile_dimensions(clash_elem)
        if not mep:
            return False, center, None, ["Kon profiel na aanpassing niet opnieuw bepalen"]

        host_height_ft = get_host_vertical_height(host)
        if not host_height_ft or host_height_ft <= 0:
            return False, center, mep, ["Kon balkhoogte niet bepalen"]

        mep_vertical_ft = get_mep_vertical_size_ft(mep) or 0.0
        void_vertical_ft = get_void_vertical_size_ft(mep, settings, clash_elem) or 0.0
        max_void_ft = host_height_ft * MAX_VOID_HEIGHT_RATIO

        if void_vertical_ft > max_void_ft + 1e-9:
            settings = get_prefab_settings()
            rule_mode = settings["rule_mode"]

            if rule_mode == "MEP":
                clearance_ft = get_clearance_ft_for_mep(clash_elem, mep, settings)
                allowed_mep_ft = max_void_ft - 2.0 * clearance_ft
                if allowed_mep_ft <= 0:
                    return False, center, mep, actions + ["Onvoldoende ruimte om MEP + void tot 1/3 van balkhoogte te verkleinen"]
                ok, msg = set_mep_vertical_size(clash_elem, mep, allowed_mep_ft)
                actions.append("Instelling toegepast: MEP + void verkleinen | {}".format(msg))
                if not ok:
                    return False, center, mep, actions
                continue

            if rule_mode == "BEAM":
                required_height_ft = 3.0 * void_vertical_ft
                ok, msg = resize_structural_framing_height(host, required_height_ft)
                actions.append("Instelling toegepast: balk aanpassen | {}".format(msg))
                if not ok:
                    return False, center, mep, actions
                continue

            actions.append("Geen automatische actie: voidhoogte > 1/3 balkhoogte")
            return True, center, mep, actions

        host_range = get_host_vertical_range(host)
        if not host_range:
            return False, center, mep, actions + ["Kon verticale balkgrenzen niet bepalen"]

        void_bottom = center.Z - (void_vertical_ft / 2.0)
        void_top = center.Z + (void_vertical_ft / 2.0)
        dist_bottom = void_bottom - host_range[0]
        dist_top = host_range[1] - void_top

        if dist_bottom + 1e-9 < min_edge_clear_ft or dist_top + 1e-9 < min_edge_clear_ft:
            desired_center_z = center.Z
            if dist_bottom < min_edge_clear_ft:
                desired_center_z = max(desired_center_z, host_range[0] + min_edge_clear_ft + (void_vertical_ft / 2.0))
            if dist_top < min_edge_clear_ft:
                desired_center_z = min(desired_center_z, host_range[1] - min_edge_clear_ft - (void_vertical_ft / 2.0))

            feasible_min = host_range[0] + min_edge_clear_ft + (void_vertical_ft / 2.0)
            feasible_max = host_range[1] - min_edge_clear_ft - (void_vertical_ft / 2.0)
            if feasible_min > feasible_max + 1e-9:
                return False, center, mep, actions + [
                    "Void kan niet op minstens 50 mm van boven- en onderrand geplaatst worden binnen huidige balkhoogte"
                ]

            settings = get_prefab_settings()
            edge_mode = settings["edge_mode"]

            if edge_mode == "MOVE":
                delta_z = desired_center_z - center.Z
                ok, msg = move_element_vertical(clash_elem, delta_z)
                actions.append("Instelling toegepast: MEP + void verplaatsen | {}".format(msg))
                if not ok:
                    return False, center, mep, actions

                doc.Regenerate()
                inter_after, _ = find_best_intersection(host, clash_elem)
                if inter_after:
                    center = get_intersection_center(inter_after, DB.XYZ(center.X, center.Y, desired_center_z))
                else:
                    center = DB.XYZ(center.X, center.Y, desired_center_z)
                continue

            actions.append("Geen automatische actie: randafstand < 50 mm")
            return True, center, mep, actions

        return True, center, mep, actions


# ============================================================
# CLASH DETECTION
# ============================================================

def collect_nearby_clash_elements(host):
    bb = get_bbox(host)
    if not bb:
        return []

    outline = expand_outline_from_bbox(bb, mm_to_ft(SEARCH_MARGIN_MM))
    bb_filter = DB.BoundingBoxIntersectsFilter(outline)

    elems = []
    for bic in CLASH_CATEGORIES:
        try:
            col = (
                DB.FilteredElementCollector(doc)
                .OfCategory(bic)
                .WhereElementIsNotElementType()
                .WherePasses(bb_filter)
                .ToElements()
            )
            elems.extend(list(col))
        except Exception:
            pass

    return elems


def find_best_intersection(host, clash_elem):
    host_solids = get_solids(host)
    clash_solids = get_solids(clash_elem)

    best = None
    best_vol = 0.0

    for hs in host_solids:
        for cs in clash_solids:
            inter = intersect_solids(hs, cs)
            if inter:
                try:
                    if inter.Volume > best_vol:
                        best = inter
                        best_vol = inter.Volume
                except Exception:
                    pass

    if best and best_vol > MIN_INTERSECTION_VOL:
        return best, best_vol

    return None, 0.0


def get_intersection_center(intersection_solid, fallback_center):
    try:
        bb = intersection_solid.GetBoundingBox()
        if bb:
            tr = bb.Transform
            local_center = DB.XYZ(
                (bb.Min.X + bb.Max.X) / 2.0,
                (bb.Min.Y + bb.Max.Y) / 2.0,
                (bb.Min.Z + bb.Max.Z) / 2.0
            )
            if tr:
                return tr.OfPoint(local_center)
    except Exception:
        pass

    return fallback_center


# ============================================================
# ROTATION
# ============================================================

def angle_on_plane_signed(source, target, plane_normal):
    source_n = xyz_norm(source)
    target_n = xyz_norm(target)
    normal_n = xyz_norm(plane_normal)
    if not source_n or not target_n or not normal_n:
        return 0.0

    dot = max(-1.0, min(1.0, xyz_dot(source_n, target_n)))
    ang = math.acos(dot)
    cross = xyz_cross(source_n, target_n)
    if xyz_dot(cross, normal_n) < 0:
        ang = -ang
    return ang


def rotate_element_around_axis(elem_id, origin, axis_dir, angle):
    """
    Safe rotation.

    Revit can raise a non-ignorable failure when a family instance cannot be
    rotated into a certain position. If this happens inside the main transaction,
    the whole Auto Voids run fails. Therefore every rotation is isolated inside
    a SubTransaction. If the rotation is not accepted, only that rotation is
    rolled back and the script continues safely.
    """
    axis_dir = xyz_norm(axis_dir)
    if not axis_dir or abs(angle) <= 1e-9:
        return True, "Geen rotatie nodig"

    axis = DB.Line.CreateBound(origin, xyz_add(origin, axis_dir))

    sub_t = DB.SubTransaction(doc)
    try:
        sub_t.Start()
        DB.ElementTransformUtils.RotateElement(doc, elem_id, axis, angle)
        sub_t.Commit()
        return True, "Geroteerd"
    except Exception as ex:
        try:
            if sub_t.HasStarted():
                sub_t.RollBack()
        except Exception:
            pass

        logger.warning("Rotatie overgeslagen voor element {}: {}".format(eid(elem_id), ex))
        return False, "Rotatie overgeslagen: {}".format(ex)

def rotate_instance_local_y_to_direction(instance, origin, target_dir):
    """
    Zorgt ervoor dat de void de richting van het MEP-element volgt.

    We doen dit in 2 veilige stappen:
    1. azimut in het XY-vlak
    2. helling t.o.v. het horizontale vlak

    Dat is stabieler dan 1 arbitraire 3D-rotatie en vermijdt in veel gevallen de typische
    Revit-foutmelding over een onmogelijke rotatiepositie.
    """
    target = xyz_norm(target_dir)
    if not target:
        return True, "Geen geldige doeldirection"

    # Stap 1: horizontale richting (planrotatie rond Z)
    horiz_len = math.sqrt(target.X * target.X + target.Y * target.Y)
    if horiz_len > 1e-9:
        target_xy = DB.XYZ(target.X / horiz_len, target.Y / horiz_len, 0)
        angle_xy = angle_on_plane_signed(DB.XYZ.BasisY, target_xy, DB.XYZ.BasisZ)
        if abs(angle_xy) > 1e-9:
            ok, msg = rotate_element_around_axis(instance.Id, origin, DB.XYZ.BasisZ, angle_xy)
            if not ok:
                return False, msg
            doc.Regenerate()

        # Stap 2: helling t.o.v. horizontale richting
        slope_angle = math.atan2(target.Z, horiz_len)
        if abs(slope_angle) > 1e-9:
            tilt_axis = xyz_cross(target_xy, DB.XYZ.BasisZ)
            if xyz_len(tilt_axis) > 1e-9:
                ok, msg = rotate_element_around_axis(instance.Id, origin, tilt_axis, slope_angle)
                if not ok:
                    return False, msg
                doc.Regenerate()
    else:
        # Volledig verticaal element: roteer vanuit lokale Y naar Z via X-as
        angle_vert = angle_on_plane_signed(DB.XYZ.BasisY, DB.XYZ(0, 0, 1 if target.Z >= 0 else -1), DB.XYZ.BasisX)
        if abs(angle_vert) > 1e-9:
            ok, msg = rotate_element_around_axis(instance.Id, origin, DB.XYZ.BasisX, angle_vert)
            if not ok:
                return False, msg
            doc.Regenerate()

    return True, "Void geroteerd volgens MEP-richting"



def rotate_void_for_host_and_mep(instance, origin, host, mep_axis):
    """
    Host-aware rotation.

    Problem:
    Revit often refuses to rotate level-based Generic Model void families around
    a non-vertical axis. This creates the non-ignorable Revit error:
    "Can't rotate element into this position."

    Fix:
    - For walls, rotate only in plan around global Z.
      The void only needs to follow the wall thickness direction to cut the wall.
      This avoids forbidden 3D tilt rotations.
    - For other hosts, keep the existing MEP-axis rotation.
    """
    cname = get_category_name_lower(host)

    if cname == "walls":
        axis, thickness = get_host_thickness_axis_and_depth(host, mep_axis)
        target = xyz_norm(axis)
        if not target:
            return True, "Geen geldige wandrichting"

        horiz_len = math.sqrt(target.X * target.X + target.Y * target.Y)
        if horiz_len <= 1e-9:
            return True, "Wandrichting verticaal: geen planrotatie nodig"

        target_xy = DB.XYZ(target.X / horiz_len, target.Y / horiz_len, 0)
        angle_xy = angle_on_plane_signed(DB.XYZ.BasisY, target_xy, DB.XYZ.BasisZ)

        if abs(angle_xy) <= 1e-9:
            return True, "Wandvoid al juist georiënteerd"

        return rotate_element_around_axis(instance.Id, origin, DB.XYZ.BasisZ, angle_xy)

    return rotate_instance_local_y_to_direction(instance, origin, mep_axis)

# ============================================================
# VOID CREATION / CUT
# ============================================================

def create_void_instance(symbol, insertion_point, level):
    if not symbol.IsActive:
        symbol.Activate()
        doc.Regenerate()

    return doc.Create.NewFamilyInstance(
        insertion_point,
        symbol,
        level,
        DB.Structure.StructuralType.NonStructural
    )



def move_void_geometry_center_to_point(void_inst, target_point):
    """
    Moves the void instance so the visible void geometry/bounding-box center
    sits exactly on the calculated host/MEP center.

    This is needed for wall openings because some void families do not have
    their insertion/origin point exactly in the geometric center after rotation.
    """
    if void_inst is None or target_point is None:
        return False, "geen target"

    doc.Regenerate()

    bb = get_bbox(void_inst)
    if not bb:
        return False, "geen void bounding box"

    current_center = bbox_center(bb)
    delta = xyz_sub(target_point, current_center)

    if xyz_len(delta) <= mm_to_ft(1.0):
        return False, "void geometry al gecentreerd"

    try:
        DB.ElementTransformUtils.MoveElement(doc, void_inst.Id, delta)
        doc.Regenerate()
        return True, "void geometry gecentreerd op host/MEP-center"
    except Exception as ex:
        logger.warning("Void-center correctie mislukt voor {}: {}".format(eid(void_inst), ex))
        return False, str(ex)


def axis_text_from_vector(v):
    av = DB.XYZ(abs(v.X), abs(v.Y), abs(v.Z))
    if av.X >= av.Y and av.X >= av.Z:
        return "Doorvoer X-as"
    elif av.Y >= av.X and av.Y >= av.Z:
        return "Doorvoer Y-as"
    return "Doorvoer Z-as"


def priority_text_from_size_ft(size_ft):
    mm = ft_to_mm(size_ft)
    if mm >= 400:
        return "H"
    elif mm >= 200:
        return "M"
    return "L"


def set_round_void_params(inst, host_diameter_ft, depth_ft, clearance_ft, mark_text, axis_text, source_host_id, source_mep_id):
    set_param(inst, "HostDiameter", host_diameter_ft)
    set_param(inst, "Clearance", clearance_ft)
    set_param(inst, "Depth", depth_ft)
    set_param(inst, "SourceHostId", str(source_host_id))
    set_param(inst, "SourceMEPId", str(source_mep_id))
    set_param(inst, "Comments", "PrefabAnalyser auto opening | HostDiameter={} | Clearance={} | Depth={}".format(
        fmt_mm(host_diameter_ft), fmt_mm(clearance_ft), fmt_mm(depth_ft)
    ))
    set_param(inst, "Description", axis_text)
    set_param(inst, "Mark", mark_text)


def set_rect_void_params(inst, host_width_ft, host_height_ft, depth_ft, clearance_ft, mark_text, axis_text, source_host_id, source_mep_id):
    set_param(inst, "HostWidth", host_width_ft)
    set_param(inst, "HostHeight", host_height_ft)
    set_param(inst, "Clearance", clearance_ft)
    set_param(inst, "Depth", depth_ft)
    set_param(inst, "SourceHostId", str(source_host_id))
    set_param(inst, "SourceMEPId", str(source_mep_id))
    set_param(inst, "Comments", "PrefabAnalyser auto opening | HostWidth={} | HostHeight={} | Clearance={} | Depth={}".format(
        fmt_mm(host_width_ft), fmt_mm(host_height_ft), fmt_mm(clearance_ft), fmt_mm(depth_ft)
    ))
    set_param(inst, "Description", axis_text)
    set_param(inst, "Mark", mark_text)


def can_cut_with_instance_void(host):
    try:
        return DB.InstanceVoidCutUtils.CanBeCutWithVoid(host)
    except Exception:
        return False


def try_apply_cut(host, void_inst):
    try:
        if can_cut_with_instance_void(host):
            if not DB.InstanceVoidCutUtils.InstanceVoidCutExists(host, void_inst):
                DB.InstanceVoidCutUtils.AddInstanceVoidCut(doc, host, void_inst)
            return True, "InstanceVoidCut"
    except Exception as ex:
        logger.warning("InstanceVoidCut mislukt: {}".format(ex))

    try:
        if DB.SolidSolidCutUtils.CanElementCutElement(void_inst, host):
            DB.SolidSolidCutUtils.AddCutBetweenSolids(doc, host, void_inst)
            return True, "SolidSolidCut"
    except Exception as ex:
        logger.warning("SolidSolidCut mislukt: {}".format(ex))

    return False, "Geen cut-methode werkte"


def create_void_for_clash(host, clash_elem, round_symbol, rect_symbol, used_points_by_host, settings):
    inter, vol = find_best_intersection(host, clash_elem)
    if not inter:
        return None, "Geen echte solid clash"

    mep = get_mep_profile_dimensions(clash_elem)
    if not mep:
        return None, "Kon profiel van clash-element niet bepalen"

    raw_center = get_intersection_center(inter, mep["center"])
    axis = mep["axis"]
    if not axis:
        return None, "Geen richting gevonden"

    center = get_target_void_center_on_host_center(host, clash_elem, axis, raw_center)
    if center is None:
        center = raw_center

    is_ok, center, mep, actions = enforce_beam_void_rules(host, clash_elem, mep, center, settings)
    if not is_ok:
        return None, " | ".join(actions) if actions else "Niet voldaan aan balkregels"

    axis = mep["axis"]
    if not axis:
        return None, "Geen richting gevonden na correctie"

    center = get_target_void_center_on_host_center(host, clash_elem, axis, center)
    if center is None:
        return None, "Kon void-center niet bepalen"

    host_key = eid(host)
    if DEDUPLICATE:
        for pt in used_points_by_host[host_key]:
            if xyz_distance(pt, center) <= mm_to_ft(DEDUP_TOL_MM):
                return None, "Overgeslagen: opening bestaat al in buurt"

    lvl = get_level_for_element(host)
    if not lvl:
        return None, "Geen level gevonden"

    # Bepaal de effectieve profielradius voor schuine doorvoeren.
    # Deze radius zorgt ervoor dat niet alleen de centerline, maar ook de buitenrand
    # van de void volledig door de host snijdt.
    if mep["is_round"]:
        _clearance_for_depth = get_clearance_ft_for_mep(clash_elem, mep, settings)
        _diam_for_depth = mep["host_diameter"] or mm_to_ft(100.0)
        profile_radius_for_depth = (_diam_for_depth + 2.0 * _clearance_for_depth) / 2.0
    else:
        _clearance_for_depth = get_clearance_ft_for_mep(clash_elem, mep, settings)
        _w_for_depth = mep["host_width"] or mm_to_ft(100.0)
        _h_for_depth = mep["host_height"] or mm_to_ft(100.0)
        profile_radius_for_depth = math.sqrt((_w_for_depth / 2.0 + _clearance_for_depth) ** 2 + (_h_for_depth / 2.0 + _clearance_for_depth) ** 2)

    depth_ft = get_host_depth_along_axis(host, axis, center, profile_radius_for_depth)
    if not depth_ft or depth_ft <= 0:
        depth_ft = mm_to_ft(MIN_DEPTH_MM)

    axis_text = axis_text_from_vector(axis)

    if mep["is_round"]:
        clearance_ft = get_clearance_ft_for_mep(clash_elem, mep, settings)
        host_diameter_ft = mep["host_diameter"] or mm_to_ft(100.0)
        final_diameter_ft = host_diameter_ft + 2.0 * clearance_ft
        priority = priority_text_from_size_ft(final_diameter_ft)
        mark_text = "PA-{}-{}".format(priority, eid(clash_elem))

        inst = create_void_instance(round_symbol, center, lvl)
        set_round_void_params(inst, host_diameter_ft, depth_ft, clearance_ft, mark_text, axis_text, eid(host), eid(clash_elem))
        doc.Regenerate()
        rot_ok, rot_msg = rotate_void_for_host_and_mep(inst, center, host, axis)
        if not rot_ok:
            try:
                doc.Delete(inst.Id)
            except Exception:
                pass
            return None, "Void geplaatst maar rotatie mislukt: {}".format(rot_msg)
        doc.Regenerate()
        move_void_geometry_center_to_point(inst, center)
        doc.Regenerate()
    else:
        clearance_ft = get_clearance_ft_for_mep(clash_elem, mep, settings)
        host_width_ft = mep["host_width"] or mm_to_ft(100.0)
        host_height_ft = mep["host_height"] or mm_to_ft(100.0)
        final_size_ft = max(host_width_ft + 2.0 * clearance_ft, host_height_ft + 2.0 * clearance_ft)
        priority = priority_text_from_size_ft(final_size_ft)
        mark_text = "PA-{}-{}".format(priority, eid(clash_elem))

        inst = create_void_instance(rect_symbol, center, lvl)
        set_rect_void_params(inst, host_width_ft, host_height_ft, depth_ft, clearance_ft, mark_text, axis_text, eid(host), eid(clash_elem))
        doc.Regenerate()
        rot_ok, rot_msg = rotate_void_for_host_and_mep(inst, center, host, axis)
        if not rot_ok:
            try:
                doc.Delete(inst.Id)
            except Exception:
                pass
            return None, "Void geplaatst maar rotatie mislukt: {}".format(rot_msg)
        doc.Regenerate()
        move_void_geometry_center_to_point(inst, center)
        doc.Regenerate()

    ok, method = try_apply_cut(host, inst)
    if not ok:
        try:
            doc.Delete(inst.Id)
        except Exception:
            pass
        return None, "Void geplaatst maar cut mislukt"

    used_points_by_host[host_key].append(center)
    if actions:
        return inst, method + " | " + " | ".join(actions)
    return inst, method


# ============================================================
# MAIN
# ============================================================


def close_output_if_enabled(settings):
    try:
        enabled = bool(settings.get("auto_close_output", False))
    except Exception:
        enabled = False

    if not enabled:
        return

    # In pyRevit 5.x moet het outputvenster meestal met vertraging gesloten worden,
    # omdat de HTML-output pas op het einde volledig opgebouwd is.
    try:
        output.self_destruct(1)
        return
    except Exception:
        pass

    try:
        output.close()
        return
    except Exception:
        pass

    try:
        output.hide()
        return
    except Exception:
        pass

    try:
        output.window.Close()
        return
    except Exception:
        pass

    try:
        output._window.Close()
        return
    except Exception:
        pass

def main():
    output.print_md("# PrefabAnalyser - automatische voids")
    output.print_md("Alle instellingen en rapportering zijn in **millimeter**.")

    settings = get_prefab_settings()
    selected_host_categories = settings["host_categories"]
    clearances = settings["clearances"]

    output.print_md("## Gekozen instellingen")
    output.print_md("- Host categories: **{}**".format(", ".join(settings["host_names"])))
    output.print_md("- Round duct clearance: **{} mm**".format(int(round(clearances["round_duct_mm"]))))
    output.print_md("- Rectangular duct clearance: **{} mm**".format(int(round(clearances["rectangular_duct_mm"]))))
    output.print_md("- Pipe clearance: **{} mm**".format(int(round(clearances["pipe_mm"]))))
    output.print_md("- Conduit clearance: **{} mm**".format(int(round(clearances["conduit_mm"]))))
    output.print_md("- Cable tray clearance: **{} mm**".format(int(round(clearances["cable_tray_mm"]))))
    output.print_md("- Other MEP clearance: **{} mm**".format(int(round(clearances["other_mep_mm"]))))
    output.print_md("- Regel bij voidhoogte > 1/3 balkhoogte: **{}**".format(rule_mode_to_text(settings["rule_mode"])))
    output.print_md("- Regel bij randafstand < 50 mm: **{}**".format(edge_mode_to_text(settings["edge_mode"])))

    hosts = collect_candidate_hosts(selected_host_categories)
    if not hosts:
        output.print_md("## Geen geschikte hosts gevonden")
        output.print_md("Controleer je host categories in het instellingenpaneel.")
        return

    try:
        round_symbol = ensure_family_loaded(ROUND_FAMILY_NAME, ROUND_FAMILY_FILE)
        rect_symbol = ensure_family_loaded(RECT_FAMILY_NAME, RECT_FAMILY_FILE)
    except Exception as ex:
        output.print_md("## Family-probleem")
        output.print_md(str(ex))
        return

    total_checked_pairs = 0
    total_created = 0
    total_failed = 0
    results = []
    used_points_by_host = defaultdict(list)

    with revit.Transaction("PrefabAnalyser - create voids"):
        for host in hosts:
            nearby = collect_nearby_clash_elements(host)
            for clash_elem in nearby:
                if clash_elem.Id == host.Id:
                    continue

                total_checked_pairs += 1

                try:
                    inst, info = create_void_for_clash(host, clash_elem, round_symbol, rect_symbol, used_points_by_host, settings)

                    if inst:
                        total_created += 1
                        mep = get_mep_profile_dimensions(clash_elem)

                        if mep and mep["is_round"]:
                            final_d_ft = (mep["host_diameter"] or 0.0) + 2.0 * get_clearance_ft_for_mep(clash_elem, mep, settings)
                            size_txt = "Host {} -> Void {}".format(fmt_mm(mep["host_diameter"] or 0.0), fmt_mm(final_d_ft))
                            clearance_txt = "{} mm".format(int(round(get_clearance_mm_for_mep(clash_elem, mep, settings))))
                            void_kind = "Round"
                        elif mep:
                            final_w_ft = (mep["host_width"] or 0.0) + 2.0 * get_clearance_ft_for_mep(clash_elem, mep, settings)
                            final_h_ft = (mep["host_height"] or 0.0) + 2.0 * get_clearance_ft_for_mep(clash_elem, mep, settings)
                            size_txt = "{} x {} -> {} x {}".format(
                                fmt_mm(mep["host_width"] or 0.0),
                                fmt_mm(mep["host_height"] or 0.0),
                                fmt_mm(final_w_ft),
                                fmt_mm(final_h_ft)
                            )
                            clearance_txt = "{} mm".format(int(round(get_clearance_mm_for_mep(clash_elem, mep, settings))))
                            void_kind = "Rectangular"
                        else:
                            size_txt = "Onbekend"
                            clearance_txt = "-"
                            void_kind = "-"

                        results.append({
                            "host_id": eid(host),
                            "clash_id": eid(clash_elem),
                            "void_id": eid(inst),
                            "void_kind": void_kind,
                            "clearance_txt": clearance_txt,
                            "size_txt": size_txt,
                            "depth_txt": fmt_mm(get_host_depth_along_axis(host, mep["axis"], mep["center"], None) if mep else 0.0),
                            "method": info
                        })
                    else:
                        total_failed += 1
                        logger.info("Geen void voor host {} vs clash {}: {}".format(eid(host), eid(clash_elem), info))

                except Exception as ex:
                    total_failed += 1
                    logger.warning("Fout bij host {} vs clash {}: {}".format(eid(host), eid(clash_elem), ex))

    output.print_md("## Resultaat")
    output.print_md("- Gecontroleerde combinaties: **{}**".format(total_checked_pairs))
    output.print_md("- Aangemaakte voids: **{}**".format(total_created))
    output.print_md("- Overgeslagen/mislukt: **{}**".format(total_failed))

    if results:
        output.print_md("## Gemaakte openingen")
        output.print_table(
            table_data=[[
                r["host_id"], r["clash_id"], r["void_kind"], r["clearance_txt"],
                r["size_txt"], r["depth_txt"], r["void_id"], r["method"]
            ] for r in results],
            columns=["Host Id", "MEP Id", "Void type", "Clearance", "Doorsnede", "Depth", "Void Id", "Cut methode"]
        )

    output.print_md("## Klaar")
    close_output_if_enabled(settings)


if __name__ == "__main__":
    main()
