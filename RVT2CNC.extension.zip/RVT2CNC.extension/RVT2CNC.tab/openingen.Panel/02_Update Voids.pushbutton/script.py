# -*- coding: utf-8 -*-
from __future__ import division
import math

from pyrevit import revit, DB, forms, script

doc = revit.doc
logger = script.get_logger()
output = script.get_output()

ROUND_FAMILY_NAME = "PrefabAnalyser_Void_Round"
RECT_FAMILY_NAME = "PrefabAnalyser_Void_Rect"
VOID_FAMILY_NAMES = [ROUND_FAMILY_NAME, RECT_FAMILY_NAME]

CLASH_CATEGORIES = [
    DB.BuiltInCategory.OST_DuctCurves,
    DB.BuiltInCategory.OST_PipeCurves,
    DB.BuiltInCategory.OST_Conduit,
    DB.BuiltInCategory.OST_CableTray,
    DB.BuiltInCategory.OST_DuctAccessory,
    DB.BuiltInCategory.OST_PipeAccessory,
    DB.BuiltInCategory.OST_DuctFitting,
    DB.BuiltInCategory.OST_PipeFitting,
]

HOST_CATEGORIES = [
    DB.BuiltInCategory.OST_StructuralFraming,
    DB.BuiltInCategory.OST_StructuralColumns,
    DB.BuiltInCategory.OST_Walls,
    DB.BuiltInCategory.OST_Floors,
    DB.BuiltInCategory.OST_Roofs,
    DB.BuiltInCategory.OST_Ceilings,
    DB.BuiltInCategory.OST_GenericModel,
]

MIN_DEPTH_MM = 50.0
# Extra lengte langs MEP-as zodat schuine/bijna-loodrechte voids geen dun hoekje laten staan.
VOID_END_EXTRA_MM = 20.0
VALUE_TOL_MM = 1.0
SEARCH_MARGIN_MM = 300.0
MOVE_TOL_MM = 1.0

MAX_VOID_HEIGHT_RATIO = 1.0 / 3.0
MIN_EDGE_CLEAR_MM = 50.0
RULE_TOL_MM = 1.0

# ============================================================
# SETTINGS FROM PREFABANALYSER SETTINGS PANEL
# ============================================================

SETTINGS_SECTION = "PrefabAnalyser"

HOST_CATEGORY_OPTIONS = {
    "Structural Framing": DB.BuiltInCategory.OST_StructuralFraming,
    "Structural Columns": DB.BuiltInCategory.OST_StructuralColumns,
    "Walls": DB.BuiltInCategory.OST_Walls,
    "Floors": DB.BuiltInCategory.OST_Floors,
    "Roofs": DB.BuiltInCategory.OST_Roofs,
    "Ceilings": DB.BuiltInCategory.OST_Ceilings,
    "Generic Models": DB.BuiltInCategory.OST_GenericModel,
}

def _cfg_get(cfg, name, default_value):
    try:
        value = getattr(cfg, name)
        if value is None or str(value).strip() == "":
            return default_value
        return str(value).strip()
    except Exception:
        return default_value


def _parse_float(value, default_value):
    try:
        return float(str(value).replace(",", "."))
    except Exception:
        return float(default_value)


def _parse_hosts(value):
    if not value:
        return ["Structural Framing"]
    hosts = [x.strip() for x in str(value).split(",") if x.strip()]
    return hosts if hosts else ["Structural Framing"]


def get_mep_clearance_settings(cfg):
    """
    New settings from the settings panel.
    Values are in mm.
    """
    round_duct_mm = _parse_float(_cfg_get(cfg, "clearance_round_duct_mm", _cfg_get(cfg, "clearance_round_mm", "30")), 30.0)
    rectangular_duct_mm = _parse_float(_cfg_get(cfg, "clearance_rectangular_duct_mm", _cfg_get(cfg, "clearance_rect_mm", "30")), 30.0)
    pipe_mm = _parse_float(_cfg_get(cfg, "clearance_pipe_mm", _cfg_get(cfg, "clearance_round_mm", str(round_duct_mm))), round_duct_mm)
    conduit_mm = _parse_float(_cfg_get(cfg, "clearance_conduit_mm", _cfg_get(cfg, "clearance_round_mm", str(round_duct_mm))), round_duct_mm)
    cable_tray_mm = _parse_float(_cfg_get(cfg, "clearance_cable_tray_mm", _cfg_get(cfg, "clearance_rect_mm", str(rectangular_duct_mm))), rectangular_duct_mm)
    other_mep_mm = _parse_float(_cfg_get(cfg, "clearance_other_mep_mm", "30"), 30.0)

    return {
        "round_duct_mm": round_duct_mm,
        "rectangular_duct_mm": rectangular_duct_mm,
        "pipe_mm": pipe_mm,
        "conduit_mm": conduit_mm,
        "cable_tray_mm": cable_tray_mm,
        "other_mep_mm": other_mep_mm,
    }


def get_prefab_settings():
    cfg = script.get_config(SETTINGS_SECTION)

    mep_clearances = get_mep_clearance_settings(cfg)

    # Backward-compatible general values
    round_mm = mep_clearances["round_duct_mm"]
    rect_mm = mep_clearances["rectangular_duct_mm"]

    hosts = _parse_hosts(_cfg_get(cfg, "hosts", "Structural Framing"))
    host_categories = []
    for host_name in hosts:
        if host_name in HOST_CATEGORY_OPTIONS:
            host_categories.append(HOST_CATEGORY_OPTIONS[host_name])

    if not host_categories:
        host_categories = [HOST_CATEGORY_OPTIONS["Structural Framing"]]

    rule_mode = _cfg_get(cfg, "rule_mode", "MEP")
    if rule_mode not in ["MEP", "BEAM", "NONE"]:
        rule_mode = "MEP"

    edge_mode = _cfg_get(cfg, "edge_mode", "MOVE")
    if edge_mode not in ["MOVE", "NONE"]:
        edge_mode = "MOVE"

    auto_close_output_raw = _cfg_get(cfg, "auto_close_output", "False")
    auto_close_output = str(auto_close_output_raw).lower() in ["true", "1", "yes", "ja"]

    return {
        "clearances": {
            "round_mm": round_mm,
            "rect_mm": rect_mm,
            "round_duct_mm": mep_clearances["round_duct_mm"],
            "rectangular_duct_mm": mep_clearances["rectangular_duct_mm"],
            "pipe_mm": mep_clearances["pipe_mm"],
            "conduit_mm": mep_clearances["conduit_mm"],
            "cable_tray_mm": mep_clearances["cable_tray_mm"],
            "other_mep_mm": mep_clearances["other_mep_mm"],
        },
        "clearance_round_mm": round_mm,
        "clearance_rect_mm": rect_mm,
        "clearance_round_ft": mm_to_ft(round_mm),
        "clearance_rect_ft": mm_to_ft(rect_mm),
        "mep_clearances": mep_clearances,
        "host_categories": host_categories,
        "host_names": hosts,
        "rule_mode": rule_mode,
        "edge_mode": edge_mode,
        "auto_close_output": auto_close_output,
    }


def get_mep_clearance_key(elem, profile=None):
    """
    Returns which clearance setting should be used for the given MEP element.
    """
    cname = get_category_name_lower(elem)

    if "pipe" in cname:
        return "pipe_mm"
    if "conduit" in cname:
        return "conduit_mm"
    if "cable tray" in cname or "cabletray" in cname:
        return "cable_tray_mm"
    if "duct" in cname:
        if profile and profile.get("is_round"):
            return "round_duct_mm"
        return "rectangular_duct_mm"

    if profile and profile.get("is_round"):
        return "round_duct_mm"

    return "other_mep_mm"


def get_clearance_mm_for_mep(elem, profile, settings):
    try:
        key = get_mep_clearance_key(elem, profile)
        return float(settings["mep_clearances"].get(key, 30.0))
    except Exception:
        try:
            if profile and profile.get("is_round"):
                return float(settings["clearance_round_mm"])
            return float(settings["clearance_rect_mm"])
        except Exception:
            return 30.0


def get_clearance_ft_for_mep(elem, profile, settings):
    return mm_to_ft(get_clearance_mm_for_mep(elem, profile, settings))


def clearance_key_to_label(key):
    labels = {
        "round_duct_mm": "Round duct",
        "rectangular_duct_mm": "Rectangular duct",
        "pipe_mm": "Pipe",
        "conduit_mm": "Conduit",
        "cable_tray_mm": "Cable tray",
        "other_mep_mm": "Other MEP",
    }
    return labels.get(key, "MEP")

def rule_mode_to_text(rule_mode):
    if rule_mode == "MEP":
        return "MEP + void automatisch verkleinen"
    if rule_mode == "BEAM":
        return "Balk automatisch aanpassen naar 3 x voidhoogte"
    return "Geen automatische actie"


def edge_mode_to_text(edge_mode):
    if edge_mode == "MOVE":
        return "MEP + void automatisch verplaatsen"
    return "Geen automatische actie"


def host_allowed_by_settings(host, settings):
    if not host or not settings:
        return False
    try:
        host_cat_id = host.Category.Id
    except Exception:
        return False

    for bic in settings["host_categories"]:
        try:
            if host_cat_id == DB.ElementId(bic):
                return True
        except Exception:
            pass
    return False


def get_settings_clearance_for_void_kind(void_kind, settings):
    # Backward compatibility only. Actual update uses get_clearance_ft_for_mep().
    if void_kind == "round":
        return settings["clearance_round_ft"]
    return settings["clearance_rect_ft"]


def mm_to_ft(mm):
    return mm / 304.8


def ft_to_mm(ft):
    return ft * 304.8


def fmt_mm(ft_val):
    return "{:.0f} mm".format(ft_to_mm(ft_val or 0.0))


def get_element_name(elem, fallback=""):
    try:
        return DB.Element.Name.GetValue(elem)
    except Exception:
        pass
    try:
        return elem.Name
    except Exception:
        pass
    try:
        p = elem.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
        if p:
            val = p.AsString()
            if val:
                return val
    except Exception:
        pass
    return fallback


def eid(elem_or_id):
    try:
        obj = elem_or_id.Id
    except Exception:
        obj = elem_or_id

    try:
        return obj.IntegerValue
    except Exception:
        pass

    try:
        return obj.Value
    except Exception:
        pass

    try:
        return str(obj)
    except Exception:
        return "<no-id>"


def get_param(elem, name):
    try:
        return elem.LookupParameter(name)
    except Exception:
        return None


def set_param(elem, name, value):
    p = get_param(elem, name)
    if not p or p.IsReadOnly:
        return False, "parameter ontbreekt of is readonly"

    try:
        if p.StorageType == DB.StorageType.Double:
            p.Set(float(value))
            return True, "ok"
        elif p.StorageType == DB.StorageType.String:
            p.Set(str(value))
            return True, "ok"
        elif p.StorageType == DB.StorageType.Integer:
            p.Set(int(value))
            return True, "ok"
        elif p.StorageType == DB.StorageType.ElementId:
            p.Set(DB.ElementId(int(value)))
            return True, "ok"
    except Exception as ex:
        logger.warning("Set param mislukt voor {} op element {}: {}".format(name, eid(elem), ex))
        return False, str(ex)

    return False, "unsupported storage type"


def get_double_param_value(elem, name, default=None):
    p = get_param(elem, name)
    if p and p.StorageType == DB.StorageType.Double:
        try:
            return p.AsDouble()
        except Exception:
            pass
    return default


def try_get_double_param(elem, names):
    for n in names:
        p = get_param(elem, n)
        if p and p.StorageType == DB.StorageType.Double:
            try:
                return p.AsDouble()
            except Exception:
                pass
    return None


def get_stored_id_value(elem, name):
    p = get_param(elem, name)
    if not p:
        return None

    try:
        st = p.StorageType
        if st == DB.StorageType.String:
            val = p.AsString()
            if val:
                val = str(val).strip()
                if val:
                    return int(val)
        elif st == DB.StorageType.Integer:
            return int(p.AsInteger())
        elif st == DB.StorageType.ElementId:
            eid_val = p.AsElementId()
            if eid_val and eid_val != DB.ElementId.InvalidElementId:
                try:
                    return int(eid_val.IntegerValue)
                except Exception:
                    return int(eid_val.Value)
    except Exception:
        pass

    return None


def get_element_by_stored_id(raw_id):
    if raw_id in [None, "", 0, -1]:
        return None, None

    try:
        elem_id = DB.ElementId(int(raw_id))
    except Exception:
        return None, None

    try:
        elem = doc.GetElement(elem_id)
        if elem:
            return elem, doc
    except Exception:
        pass

    try:
        link_instances = DB.FilteredElementCollector(doc).OfClass(DB.RevitLinkInstance)
        for link in link_instances:
            try:
                link_doc = link.GetLinkDocument()
                if not link_doc:
                    continue
                elem = link_doc.GetElement(elem_id)
                if elem:
                    return elem, link_doc
            except Exception:
                pass
    except Exception:
        pass

    return None, None


def get_category_name(elem):
    try:
        return elem.Category.Name
    except Exception:
        return "<geen categorie>"


def get_category_name_lower(elem):
    try:
        return str(get_category_name(elem)).strip().lower()
    except Exception:
        return ""


def get_bbox(elem):
    try:
        return elem.get_BoundingBox(None)
    except Exception:
        return None


def bbox_center(bb):
    return DB.XYZ(
        (bb.Min.X + bb.Max.X) / 2.0,
        (bb.Min.Y + bb.Max.Y) / 2.0,
        (bb.Min.Z + bb.Max.Z) / 2.0
    )


def get_bbox_dimensions(bb):
    return (
        abs(bb.Max.X - bb.Min.X),
        abs(bb.Max.Y - bb.Min.Y),
        abs(bb.Max.Z - bb.Min.Z)
    )


def expand_outline_from_bbox(bb, offset_ft):
    return DB.Outline(
        DB.XYZ(bb.Min.X - offset_ft, bb.Min.Y - offset_ft, bb.Min.Z - offset_ft),
        DB.XYZ(bb.Max.X + offset_ft, bb.Max.Y + offset_ft, bb.Max.Z + offset_ft)
    )


def xyz_add(a, b):
    return DB.XYZ(a.X + b.X, a.Y + b.Y, a.Z + b.Z)


def xyz_sub(a, b):
    return DB.XYZ(a.X - b.X, a.Y - b.Y, a.Z - b.Z)


def xyz_mul(v, scalar):
    return DB.XYZ(v.X * scalar, v.Y * scalar, v.Z * scalar)


def xyz_cross(a, b):
    if a is None or b is None:
        return None
    try:
        return DB.XYZ(
            a.Y * b.Z - a.Z * b.Y,
            a.Z * b.X - a.X * b.Z,
            a.X * b.Y - a.Y * b.X
        )
    except Exception:
        return None


def xyz_dot(a, b):
    return a.X * b.X + a.Y * b.Y + a.Z * b.Z


def xyz_len(v):
    return math.sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z)


def xyz_norm(v):
    l = xyz_len(v)
    if l < 1e-12:
        return None
    return DB.XYZ(v.X / l, v.Y / l, v.Z / l)


def xyz_distance(a, b):
    return xyz_len(xyz_sub(a, b))


def get_location_point(elem):
    try:
        loc = elem.Location
        if isinstance(loc, DB.LocationPoint):
            return loc.Point
        if isinstance(loc, DB.LocationCurve) and loc.Curve:
            return loc.Curve.Evaluate(0.5, True)
    except Exception:
        pass

    bb = get_bbox(elem)
    if bb:
        return bbox_center(bb)
    return None


def get_location_curve_direction(elem):
    try:
        lc = elem.Location
        if isinstance(lc, DB.LocationCurve) and lc.Curve:
            p0 = lc.Curve.GetEndPoint(0)
            p1 = lc.Curve.GetEndPoint(1)
            return xyz_norm(xyz_sub(p1, p0))
    except Exception:
        pass
    return None


def get_element_axis_from_bbox(bb):
    dx, dy, dz = get_bbox_dimensions(bb)
    if dx >= dy and dx >= dz:
        return DB.XYZ(1, 0, 0)
    elif dy >= dx and dy >= dz:
        return DB.XYZ(0, 1, 0)
    return DB.XYZ(0, 0, 1)


def detect_is_round_profile(elem):
    cname = get_category_name(elem)
    if cname in ["Pipes", "Conduits", "Pipe Fittings", "Pipe Accessories"]:
        return True

    diameter = try_get_double_param(elem, ["Diameter", "Nominal Diameter"])
    width = try_get_double_param(elem, ["Width"])
    height = try_get_double_param(elem, ["Height"])
    if diameter and diameter > 0 and not (width and height):
        return True

    return False


def get_mep_profile_dimensions(elem):
    bb = get_bbox(elem)
    if not bb:
        return None

    axis = get_location_curve_direction(elem)
    if axis is None:
        axis = get_element_axis_from_bbox(bb)

    is_round = detect_is_round_profile(elem)

    diameter = try_get_double_param(elem, ["Diameter", "Nominal Diameter"])
    width = try_get_double_param(elem, ["Width"])
    height = try_get_double_param(elem, ["Height"])

    dx, dy, dz = get_bbox_dimensions(bb)
    absax = DB.XYZ(abs(axis.X), abs(axis.Y), abs(axis.Z))
    if absax.X >= absax.Y and absax.X >= absax.Z:
        transverse = [dy, dz]
    elif absax.Y >= absax.X and absax.Y >= absax.Z:
        transverse = [dx, dz]
    else:
        transverse = [dx, dy]

    if is_round:
        if not diameter or diameter <= 0:
            diameter = max(transverse)
        return {
            "is_round": True,
            "host_diameter": diameter,
            "host_width": None,
            "host_height": None,
            "axis": axis,
            "center": bbox_center(bb)
        }

    if not width or width <= 0:
        width = transverse[0]
    if not height or height <= 0:
        height = transverse[1] if len(transverse) > 1 else transverse[0]

    return {
        "is_round": False,
        "host_diameter": None,
        "host_width": width,
        "host_height": height,
        "axis": axis,
        "center": bbox_center(bb)
    }



def get_profile_radius_for_depth(profile):
    """
    Effectieve profielradius van de opening inclusief bestaande profielmaat.
    Wordt gebruikt voor extra lengte bij schuine doorvoeren.
    """
    if not profile:
        return mm_to_ft(25.0)

    try:
        if profile.get("is_round"):
            d = profile.get("host_diameter") or mm_to_ft(100.0)
            return d / 2.0
        w = profile.get("host_width") or mm_to_ft(100.0)
        h = profile.get("host_height") or mm_to_ft(100.0)
        return math.sqrt((w / 2.0) ** 2 + (h / 2.0) ** 2)
    except Exception:
        return mm_to_ft(25.0)


def _bbox_axis_dimensions(bb):
    return [
        ("X", abs(bb.Max.X - bb.Min.X), DB.XYZ.BasisX),
        ("Y", abs(bb.Max.Y - bb.Min.Y), DB.XYZ.BasisY),
        ("Z", abs(bb.Max.Z - bb.Min.Z), DB.XYZ.BasisZ),
    ]


def _abs_dot(a, b):
    try:
        return abs(xyz_dot(xyz_norm(a), xyz_norm(b)))
    except Exception:
        return 0.0


def get_host_thickness_axis_and_depth(host, axis):
    """
    Bepaalt welke host-richting de echte dikte is die de void moet doorsnijden.

    Waarom niet de volledige bbox-snijafstand?
    Bij balken kan de MEP-richting bij een schuine snede een component in de
    lengterichting krijgen. Een bbox-line-intersection gebruikt dan soms de
    volledige balklengte, waardoor de void veel te lang wordt.

    Deze functie kiest daarom eerst de echte dikterichting:
    - floors/roofs/ceilings: Z-dikte
    - walls: wall.Width + wall.Orientation waar mogelijk
    - framing/columns/generic: langste bbox-as wordt als lengte uitgesloten
      als die duidelijk langer is dan de andere assen. Daarna kiest hij de
      cross-section-as die het best bij de MEP-richting past.
    """
    bb = get_bbox(host)
    if not bb:
        return DB.XYZ.BasisZ, mm_to_ft(MIN_DEPTH_MM)

    cname = get_category_name_lower(host)
    d = xyz_norm(axis) if axis is not None else DB.XYZ.BasisZ

    dx, dy, dz = get_bbox_dimensions(bb)

    if cname in ["floors", "roofs", "ceilings"]:
        return DB.XYZ.BasisZ, dz if dz > 0 else mm_to_ft(MIN_DEPTH_MM)

    if cname == "walls":
        try:
            if hasattr(host, "Orientation") and host.Orientation:
                n = xyz_norm(host.Orientation)
                if hasattr(host, "Width") and host.Width and host.Width > 0:
                    return n, host.Width
        except Exception:
            pass
        try:
            if hasattr(host, "Width") and host.Width and host.Width > 0:
                # fallback: kies de bbox-as die het dichtst bij de MEP-richting ligt
                axes = _bbox_axis_dimensions(bb)
                best = max(axes, key=lambda item: _abs_dot(d, item[2]))
                return best[2], host.Width
        except Exception:
            pass

    axes = _bbox_axis_dimensions(bb)
    axes_sorted = sorted(axes, key=lambda item: item[1], reverse=True)

    # Voor balken is de grootste afmeting meestal de lengterichting.
    # Sluit die uit zodat een schuine MEP niet plots de volledige balklengte als depth krijgt.
    candidate_axes = axes
    if len(axes_sorted) >= 3:
        longest = axes_sorted[0]
        second = axes_sorted[1]
        if longest[1] > second[1] * 1.75:
            candidate_axes = axes_sorted[1:]

    # Kies van de overblijvende dikte-assen degene die het meest in de MEP-richting ligt.
    best = max(candidate_axes, key=lambda item: _abs_dot(d, item[2]))
    if best[1] <= 0:
        return best[2], mm_to_ft(MIN_DEPTH_MM)

    return best[2], best[1]


def get_bbox_simple_depth_for_host(host, axis):
    """
    Exacte hostdikte voor loodrechte doorvoeren.
    """
    n, depth = get_host_thickness_axis_and_depth(host, axis)
    return depth if depth and depth > 0 else mm_to_ft(MIN_DEPTH_MM)


def get_host_depth_along_axis(host, axis, center_point=None, profile_radius_ft=None):
    """
    Void depth volgens de echte hostdikte en de actuele MEP-hoek.

    - Loodrecht: exact hostdikte.
    - Schuin: t / cos(theta) + profielmarge.
      De profielmarge houdt rekening met diameter/breedte van de opening zodat
      ook de buitenste hoeken/randen door de host snijden.
    - Geen volledige bbox-snijafstand meer, want dat maakte balken veel te lang.
    """
    if axis is None:
        axis = DB.XYZ.BasisZ

    d = xyz_norm(axis)
    if not d:
        return mm_to_ft(MIN_DEPTH_MM)

    thickness_axis, thickness = get_host_thickness_axis_and_depth(host, d)
    if not thickness or thickness <= 0:
        thickness = mm_to_ft(MIN_DEPTH_MM)

    n = xyz_norm(thickness_axis)
    if not n:
        return max(thickness, mm_to_ft(MIN_DEPTH_MM))

    cosang = abs(xyz_dot(d, n))

    # Loodrecht / bijna loodrecht: exact hostdikte, geen marge.
    if cosang >= 0.9995:
        return max(thickness, mm_to_ft(MIN_DEPTH_MM))

    # Als de richting bijna parallel met het hostvlak loopt, wordt de theoretische
    # lengte oneindig. Beperk dit zodat de void niet absurd lang wordt.
    cos_eff = max(cosang, 0.20)

    base_depth = thickness / cos_eff

    # Profielmarge: cylinder/box moet met zijn buitenrand ook door beide zijden.
    # Benadering: extra lengte = 2 * profielradius * tan(theta)
    if profile_radius_ft is None or profile_radius_ft <= 0:
        profile_radius_ft = mm_to_ft(25.0)

    tanang = math.sqrt(max(0.0, 1.0 - cos_eff * cos_eff)) / cos_eff
    profile_margin = 2.0 * profile_radius_ft * tanang

    # Kleine productiemarge, alleen bij schuin.
    safety_margin = mm_to_ft(VOID_END_EXTRA_MM * 2.0)

    depth = base_depth + profile_margin + safety_margin

    # Redelijke bovengrens tegen extreme bijna-parallelle gevallen.
    max_depth = max(thickness * 6.0, thickness + profile_radius_ft * 8.0 + mm_to_ft(VOID_END_EXTRA_MM * 2.0), mm_to_ft(1200.0))
    if depth > max_depth:
        depth = max_depth

    return max(depth, thickness, mm_to_ft(MIN_DEPTH_MM))

def get_mid_thickness_point(current_pt, host, axis):
    """
    Zet een punt op het midden van de HOSTDIKTE.

    axis is de MEP-richting, maar de dikte-center moet berekend worden
    op de echte host-dikte-as. Dit voorkomt dat de void langs de MEP-as
    buiten de balk/host wordt gecentreerd.
    """
    if current_pt is None:
        return None

    bb = get_bbox(host)
    if not bb:
        return current_pt

    thickness_axis, thickness = get_host_thickness_axis_and_depth(host, axis)
    ax = xyz_norm(thickness_axis)
    if not ax:
        return current_pt

    corners = [
        DB.XYZ(bb.Min.X, bb.Min.Y, bb.Min.Z),
        DB.XYZ(bb.Min.X, bb.Min.Y, bb.Max.Z),
        DB.XYZ(bb.Min.X, bb.Max.Y, bb.Min.Z),
        DB.XYZ(bb.Min.X, bb.Max.Y, bb.Max.Z),
        DB.XYZ(bb.Max.X, bb.Min.Y, bb.Min.Z),
        DB.XYZ(bb.Max.X, bb.Min.Y, bb.Max.Z),
        DB.XYZ(bb.Max.X, bb.Max.Y, bb.Min.Z),
        DB.XYZ(bb.Max.X, bb.Max.Y, bb.Max.Z),
    ]

    dots = [xyz_dot(c, ax) for c in corners]
    if not dots:
        return current_pt

    target_d = (min(dots) + max(dots)) / 2.0
    current_d = xyz_dot(current_pt, ax)
    shift = target_d - current_d
    return xyz_add(current_pt, xyz_mul(ax, shift))

def move_void_to_host_mid_thickness(void_inst, host, axis):
    current_pt = get_location_point(void_inst)
    if not current_pt:
        return False, "geen punt"

    target_pt = get_mid_thickness_point(current_pt, host, axis)
    if not target_pt:
        return False, "geen target"

    delta = xyz_sub(target_pt, current_pt)
    if xyz_len(delta) <= mm_to_ft(MOVE_TOL_MM):
        return False, "al gecentreerd"

    try:
        DB.ElementTransformUtils.MoveElement(doc, void_inst.Id, delta)
        return True, "verplaatst"
    except Exception as ex:
        logger.warning("Move van void {} mislukt: {}".format(eid(void_inst), ex))
        return False, str(ex)


def get_mep_center_anchor_point(mep_elem, reference_pt=None):
    try:
        loc = mep_elem.Location
        if isinstance(loc, DB.LocationPoint):
            return loc.Point
        if isinstance(loc, DB.LocationCurve) and loc.Curve:
            curve = loc.Curve
            if reference_pt is not None:
                try:
                    proj = curve.Project(reference_pt)
                    if proj:
                        return proj.XYZPoint
                except Exception:
                    pass
            try:
                return curve.Evaluate(0.5, True)
            except Exception:
                pass
    except Exception:
        pass

    return get_location_point(mep_elem)


def get_target_void_center_from_mep(host, mep_elem, axis, reference_pt=None):
    """
    Nieuw void-center voor Update Voids.

    De void moet:
    1. op de actuele MEP-as liggen
    2. op het midden van de hostdikte liggen

    Bij LocationCurve MEP's berekent deze functie het exacte punt op de MEP-lijn
    waar die de middenvlakte van de hostdikte kruist.
    """
    if host is None or mep_elem is None:
        return None

    thickness_axis, thickness = get_host_thickness_axis_and_depth(host, axis)
    n = xyz_norm(thickness_axis)
    if not n:
        n = xyz_norm(axis)
    if not n:
        return get_mep_center_anchor_point(mep_elem, reference_pt)

    bb = get_bbox(host)
    if bb:
        corners = [
            DB.XYZ(bb.Min.X, bb.Min.Y, bb.Min.Z),
            DB.XYZ(bb.Min.X, bb.Min.Y, bb.Max.Z),
            DB.XYZ(bb.Min.X, bb.Max.Y, bb.Min.Z),
            DB.XYZ(bb.Min.X, bb.Max.Y, bb.Max.Z),
            DB.XYZ(bb.Max.X, bb.Min.Y, bb.Min.Z),
            DB.XYZ(bb.Max.X, bb.Min.Y, bb.Max.Z),
            DB.XYZ(bb.Max.X, bb.Max.Y, bb.Min.Z),
            DB.XYZ(bb.Max.X, bb.Max.Y, bb.Max.Z),
        ]
        dots = [xyz_dot(c, n) for c in corners]
        target_d = (min(dots) + max(dots)) / 2.0
    else:
        host_pt = get_location_point(host) or reference_pt
        if host_pt is None:
            return get_mep_center_anchor_point(mep_elem, reference_pt)
        target_d = xyz_dot(host_pt, n)

    try:
        loc = mep_elem.Location
        if isinstance(loc, DB.LocationCurve) and loc.Curve:
            curve = loc.Curve
            p0 = curve.GetEndPoint(0)
            p1 = curve.GetEndPoint(1)
            d = xyz_sub(p1, p0)
            denom = xyz_dot(d, n)

            if abs(denom) > 1e-9:
                t = (target_d - xyz_dot(p0, n)) / denom
                if t < -0.25:
                    t = -0.25
                if t > 1.25:
                    t = 1.25
                return xyz_add(p0, xyz_mul(d, t))

            ref = reference_pt
            if ref is None:
                ref = bbox_center(bb) if bb else get_location_point(host)
            anchor = get_mep_center_anchor_point(mep_elem, ref)
            return get_mid_thickness_point(anchor, host, axis)
    except Exception:
        pass

    anchor_pt = get_mep_center_anchor_point(mep_elem, reference_pt)
    if anchor_pt is None:
        return None
    return get_mid_thickness_point(anchor_pt, host, axis)

def move_void_center_to_mep_center(void_inst, host, mep_elem, axis):
    current_pt = get_location_point(void_inst)

    # Gebruik host-center als referentie voor projectie op de MEP-as.
    # Dit voorkomt dat een void die al buiten de host staat, opnieuw buiten de host
    # geprojecteerd wordt door zijn oude/verkeerde positie als referentie te gebruiken.
    try:
        host_pt = bbox_center(get_bbox(host))
    except Exception:
        host_pt = None
    if host_pt is None:
        host_pt = get_location_point(host)

    ref_pt = host_pt or current_pt
    target_pt = get_target_void_center_from_mep(host, mep_elem, axis, ref_pt)
    if target_pt is None:
        return False, "geen target"

    if current_pt is None:
        return False, "geen voidpunt"

    delta = xyz_sub(target_pt, current_pt)
    if xyz_len(delta) <= mm_to_ft(MOVE_TOL_MM):
        return False, "al gecentreerd op MEP"

    try:
        DB.ElementTransformUtils.MoveElement(doc, void_inst.Id, delta)
        return True, "voidcentrum uitgelijnd op MEP-centrum"
    except Exception as ex:
        logger.warning("Move van void {} naar MEP-centrum mislukt: {}".format(eid(void_inst), ex))
        return False, str(ex)



def get_family_instance_local_y_direction(inst):
    try:
        tr = inst.GetTransform()
        if tr:
            return xyz_norm(tr.BasisY)
    except Exception:
        pass
    return None


def get_any_perpendicular_axis(v):
    v = xyz_norm(v)
    if not v:
        return DB.XYZ.BasisZ
    ref = DB.XYZ.BasisZ
    if abs(xyz_dot(v, ref)) > 0.95:
        ref = DB.XYZ.BasisX
    axis = xyz_cross(v, ref)
    axis = xyz_norm(axis)
    return axis or DB.XYZ.BasisX


def rotate_element_around_axis(elem_id, origin, axis_dir, angle):
    axis_dir = xyz_norm(axis_dir)
    if not axis_dir or abs(angle) <= 1e-9:
        return True, "geen rotatie nodig"

    axis = DB.Line.CreateBound(origin, xyz_add(origin, axis_dir))
    try:
        DB.ElementTransformUtils.RotateElement(doc, elem_id, axis, angle)
        return True, "geroteerd"
    except Exception as ex:
        return False, "rotatie mislukt: {}".format(ex)


def rotate_void_local_y_to_mep_axis(void_inst, mep_axis):
    """
    Update-variant: align de HUIDIGE lokale Y-as van de bestaande void met de actuele MEP-as.
    Dit is anders dan Auto Voids, want een bestaande void kan al geroteerd zijn.
    """
    target = xyz_norm(mep_axis)
    if not target:
        return False, "geen MEP-richting"

    origin = get_location_point(void_inst)
    if not origin:
        return False, "geen voidpunt"

    current = get_family_instance_local_y_direction(void_inst)
    if not current:
        current = DB.XYZ.BasisY

    dot = max(-1.0, min(1.0, xyz_dot(current, target)))

    # Al gelijk genoeg
    if dot > 0.9999:
        return False, "hoek al gelijk"

    # 180 graden omgekeerd
    if dot < -0.9999:
        axis = get_any_perpendicular_axis(current)
        ok, msg = rotate_element_around_axis(void_inst.Id, origin, axis, math.pi)
        if ok:
            return True, "hoek 180 graden gecorrigeerd"
        return False, msg

    axis = xyz_cross(current, target)
    axis = xyz_norm(axis)
    if not axis:
        return False, "geen rotatie-as"

    angle = math.acos(dot)
    ok, msg = rotate_element_around_axis(void_inst.Id, origin, axis, angle)
    if ok:
        return True, "hoek gelijkgezet met MEP"
    return False, msg


def collect_void_instances():
    result = []
    col = DB.FilteredElementCollector(doc).OfClass(DB.FamilyInstance).WhereElementIsNotElementType()
    for inst in col:
        try:
            fam_name = inst.Symbol.Family.Name
            if fam_name in VOID_FAMILY_NAMES:
                result.append(inst)
        except Exception:
            pass
    return result


def get_void_family_kind(void_inst):
    try:
        fam_name = void_inst.Symbol.Family.Name
        if fam_name == ROUND_FAMILY_NAME:
            return "round"
        if fam_name == RECT_FAMILY_NAME:
            return "rect"
    except Exception:
        pass
    return None


def values_different(a, b, tol_ft=None):
    if tol_ft is None:
        tol_ft = mm_to_ft(VALUE_TOL_MM)
    if a is None or b is None:
        return True
    return abs(a - b) > tol_ft


def collect_nearby_candidates(elem, categories):
    bb = get_bbox(elem)
    if not bb:
        return []

    outline = expand_outline_from_bbox(bb, mm_to_ft(SEARCH_MARGIN_MM))
    bb_filter = DB.BoundingBoxIntersectsFilter(outline)

    elems = []
    for bic in categories:
        try:
            col = (
                DB.FilteredElementCollector(doc)
                .OfCategory(bic)
                .WhereElementIsNotElementType()
                .WherePasses(bb_filter)
                .ToElements()
            )
            elems.extend(list(col))
        except Exception:
            pass
    return elems


def bbox_intersects(elem_a, elem_b):
    bb1 = get_bbox(elem_a)
    bb2 = get_bbox(elem_b)
    if not bb1 or not bb2:
        return False

    if bb1.Max.X < bb2.Min.X or bb1.Min.X > bb2.Max.X:
        return False
    if bb1.Max.Y < bb2.Min.Y or bb1.Min.Y > bb2.Max.Y:
        return False
    if bb1.Max.Z < bb2.Min.Z or bb1.Min.Z > bb2.Max.Z:
        return False
    return True


def resolve_host_from_void(void_inst):
    candidates = collect_nearby_candidates(void_inst, HOST_CATEGORIES)
    if not candidates:
        return None

    void_pt = get_location_point(void_inst)
    best_host = None
    best_dist = None

    for host in candidates:
        try:
            if eid(host) == eid(void_inst):
                continue
            if not bbox_intersects(void_inst, host):
                continue

            host_pt = get_location_point(host)
            dist = xyz_distance(void_pt, host_pt) if void_pt and host_pt else 1e9
            if best_dist is None or dist < best_dist:
                best_dist = dist
                best_host = host
        except Exception:
            pass

    return best_host


def score_candidate_for_void(void_inst, candidate, wanted_kind):
    profile = get_mep_profile_dimensions(candidate)
    if not profile:
        return None, None

    if wanted_kind == "round" and not profile["is_round"]:
        return None, None
    if wanted_kind == "rect" and profile["is_round"]:
        return None, None

    void_pt = get_location_point(void_inst)
    cand_pt = get_location_point(candidate)
    dist = xyz_distance(void_pt, cand_pt) if void_pt and cand_pt else 1e9
    return dist, profile


def resolve_mep_element(void_inst, source_mep_id, host, void_kind):
    mep, mep_doc = get_element_by_stored_id(source_mep_id)
    if mep:
        return mep, get_mep_profile_dimensions(mep), "SourceMEPId"

    candidates = []
    if host:
        candidates.extend(collect_nearby_candidates(host, CLASH_CATEGORIES))
    candidates.extend(collect_nearby_candidates(void_inst, CLASH_CATEGORIES))

    seen = set()
    unique_candidates = []
    for cand in candidates:
        cid = eid(cand)
        if cid in seen:
            continue
        seen.add(cid)
        unique_candidates.append(cand)

    best_elem = None
    best_profile = None
    best_dist = None

    for cand in unique_candidates:
        try:
            dist, profile = score_candidate_for_void(void_inst, cand, void_kind)
            if profile is None:
                continue
            if best_dist is None or dist < best_dist:
                best_dist = dist
                best_elem = cand
                best_profile = profile
        except Exception:
            pass

    if best_elem:
        return best_elem, best_profile, "fallback-nearby"

    return None, None, "niet gevonden"


def delete_void_instance(void_inst):
    try:
        doc.Delete(void_inst.Id)
        return True
    except Exception as ex:
        logger.warning("Delete van void {} mislukt: {}".format(eid(void_inst), ex))
        return False


def get_host_vertical_range(host):
    bb = get_bbox(host)
    if not bb:
        return None
    return bb.Min.Z, bb.Max.Z


def get_host_vertical_height(host):
    vr = get_host_vertical_range(host)
    if not vr:
        return None
    return abs(vr[1] - vr[0])



def get_mep_vertical_size_ft(profile):
    if not profile:
        return None
    if profile.get("is_round"):
        return profile.get("host_diameter")
    return profile.get("host_height")

def get_void_vertical_size_ft(profile, clearance_ft):
    if not profile:
        return None
    if profile["is_round"]:
        return (profile.get("host_diameter") or 0.0) + 2.0 * clearance_ft
    return (profile.get("host_height") or 0.0) + 2.0 * clearance_ft


def set_mep_vertical_size(mep_elem, profile, new_size_ft):
    if not profile or new_size_ft is None or new_size_ft <= 0:
        return False, "ongeldige nieuwe MEP-grootte"

    names = ["Diameter", "Nominal Diameter"] if profile["is_round"] else ["Height"]
    for n in names:
        p = get_param(mep_elem, n)
        if p and (not p.IsReadOnly) and p.StorageType == DB.StorageType.Double:
            try:
                p.Set(float(new_size_ft))
                return True, "MEP-parameter '{}' aangepast".format(n)
            except Exception as ex:
                return False, "kon MEP-parameter '{}' niet aanpassen: {}".format(n, ex)

    return False, "geen schrijfbare hoogte/diameter-parameter gevonden op MEP-element"


def find_writable_type_double_param(elem_type, names):
    for n in names:
        p = get_param(elem_type, n)
        if p and (not p.IsReadOnly) and p.StorageType == DB.StorageType.Double:
            return p
    return None


def get_family_symbol_of_host(host):
    try:
        if isinstance(host, DB.FamilyInstance) and host.Symbol:
            return host.Symbol
    except Exception:
        pass

    try:
        tid = host.GetTypeId()
        if tid and tid != DB.ElementId.InvalidElementId:
            t = doc.GetElement(tid)
            if isinstance(t, DB.ElementType):
                return t
    except Exception:
        pass

    return None


def find_existing_beam_symbol(symbol, target_width_ft, target_height_ft):
    family = None
    try:
        family = symbol.Family
    except Exception:
        family = None

    if not family:
        return None

    try:
        symbol_ids = family.GetFamilySymbolIds()
    except Exception:
        symbol_ids = []

    for sid in symbol_ids:
        try:
            cand = doc.GetElement(sid)
            if not cand:
                continue

            cand_width = try_get_double_param(cand, ["b", "Width", "Breedte", "w"])
            cand_height = try_get_double_param(cand, ["h", "Height", "Depth", "Hoogte", "d"])

            if cand_width is None or cand_height is None:
                continue

            if abs(cand_width - target_width_ft) <= mm_to_ft(1.0) and abs(cand_height - target_height_ft) <= mm_to_ft(1.0):
                return cand
        except Exception:
            pass

    return None


def build_unique_type_name(base_name):
    existing = set()

    try:
        for et in DB.FilteredElementCollector(doc).OfClass(DB.ElementType):
            try:
                nm = get_element_name(et, "")
                if nm:
                    existing.add(nm)
            except Exception:
                pass
    except Exception:
        pass

    if base_name not in existing:
        return base_name

    idx = 2
    while True:
        candidate = "{}_{}".format(base_name, idx)
        if candidate not in existing:
            return candidate
        idx += 1


def safe_duplicate_symbol(symbol, preferred_name):
    try_name = preferred_name
    idx = 2

    while True:
        try:
            dup = symbol.Duplicate(try_name)

            # Revit API kan afhankelijk van versie een ElementType of ElementId teruggeven.
            try:
                if isinstance(dup, DB.ElementId):
                    dup = doc.GetElement(dup)
            except Exception:
                pass

            try:
                if hasattr(dup, "Id"):
                    return dup, try_name
            except Exception:
                pass

            return dup, try_name

        except Exception:
            try_name = "{}_{}".format(preferred_name, idx)
            idx += 1


def apply_family_symbol_to_host(host, new_symbol):
    if not host or not new_symbol:
        return False

    try:
        if isinstance(host, DB.FamilyInstance):
            host.Symbol = new_symbol
            doc.Regenerate()
            return host.Symbol and host.Symbol.Id == new_symbol.Id
    except Exception:
        pass

    try:
        host.ChangeTypeId(new_symbol.Id)
        doc.Regenerate()
        return host.GetTypeId() == new_symbol.Id
    except Exception:
        pass

    try:
        return host.GetTypeId() == new_symbol.Id
    except Exception:
        return False


def duplicate_and_resize_beam_type(host, required_height_ft):
    """
    Zelfde logica als Auto Voids:
    1. huidig balktype zoeken
    2. breedte uitlezen
    3. checken of bestaand type met breedte x gevraagde hoogte al bestaat
    4. anders veilig dupliceren
    5. hoogte op nieuw type zetten
    6. nieuw/bestaand type toepassen op de balk
    """
    symbol = get_family_symbol_of_host(host)
    if not symbol:
        return False, "kon huidig balktype niet vinden"

    width_param = find_writable_type_double_param(symbol, ["b", "Width", "Breedte", "w"])
    height_param = find_writable_type_double_param(symbol, ["h", "Height", "Depth", "Hoogte", "d"])

    if not width_param:
        return False, "geen schrijfbare breedteparameter gevonden op balktype"
    if not height_param:
        return False, "geen schrijfbare hoogteparameter gevonden op balktype"

    try:
        width_ft = width_param.AsDouble()
    except Exception:
        return False, "kon breedte van balktype niet lezen"

    existing_symbol = find_existing_beam_symbol(symbol, width_ft, required_height_ft)
    if existing_symbol:
        applied = apply_family_symbol_to_host(host, existing_symbol)
        if not applied:
            return False, "bestaand balktype gevonden maar niet kunnen toepassen op de balk"

        return True, "bestaand balktype '{}' toegepast | breedte {} | hoogte {}".format(
            get_element_name(existing_symbol, "<type>"),
            fmt_mm(width_ft),
            fmt_mm(required_height_ft)
        )

    base_name = "{}x{}mm".format(
        int(round(ft_to_mm(width_ft))),
        int(round(ft_to_mm(required_height_ft)))
    )
    preferred_name = build_unique_type_name(base_name)

    new_symbol, used_name = safe_duplicate_symbol(symbol, preferred_name)
    if not new_symbol:
        return False, "dupliceren van balktype mislukt"

    new_height_param = find_writable_type_double_param(new_symbol, ["h", "Height", "Depth", "Hoogte", "d"])
    if not new_height_param:
        return False, "geen schrijfbare hoogteparameter gevonden op nieuw balktype"

    try:
        new_height_param.Set(float(required_height_ft))
        doc.Regenerate()
    except Exception as ex:
        return False, "aanpassen van balkhoogte mislukt: {}".format(ex)

    try:
        applied_height_ft = new_height_param.AsDouble()
    except Exception:
        applied_height_ft = None

    if applied_height_ft is None or abs(applied_height_ft - required_height_ft) > mm_to_ft(1.0):
        return False, "nieuw balktype aangemaakt maar hoogte niet correct aangepast"

    applied = apply_family_symbol_to_host(host, new_symbol)
    if not applied:
        return False, "nieuw balktype aangemaakt maar niet kunnen toepassen op de balk"

    doc.Regenerate()

    return True, "nieuw balktype '{}' toegepast | breedte {} | hoogte {}".format(
        used_name,
        fmt_mm(width_ft),
        fmt_mm(required_height_ft)
    )

def move_element_vertical(elem, delta_z_ft):
    if abs(delta_z_ft) <= mm_to_ft(MOVE_TOL_MM):
        return True, "geen verplaatsing nodig"

    was_pinned = False
    try:
        was_pinned = bool(getattr(elem, "Pinned", False))
    except Exception:
        was_pinned = False

    try:
        if was_pinned:
            try:
                elem.Pinned = False
            except Exception:
                pass

        move_vec = DB.XYZ(0, 0, delta_z_ft)
        try:
            loc = elem.Location
            if loc and hasattr(loc, "Move"):
                loc.Move(move_vec)
            else:
                DB.ElementTransformUtils.MoveElement(doc, elem.Id, move_vec)
        except Exception:
            DB.ElementTransformUtils.MoveElement(doc, elem.Id, move_vec)
        return True, "element verticaal verplaatst met {}".format(fmt_mm(abs(delta_z_ft)))
    except Exception as ex:
        return False, "kon element niet verticaal verplaatsen: {}".format(ex)
    finally:
        if was_pinned:
            try:
                elem.Pinned = True
            except Exception:
                pass


def ask_user_resolution(title, message, options):
    try:
        return forms.CommandSwitchWindow.show(options, message=message, title=title)
    except Exception:
        forms.alert(message)
        return None


def apply_profile_to_void_params(void_inst, profile):
    kind = get_void_family_kind(void_inst)
    if kind == "round":
        return set_param(void_inst, "HostDiameter", profile["host_diameter"])

    if kind == "rect":
        ok1, msg1 = set_param(void_inst, "HostWidth", profile["host_width"])
        ok2, msg2 = set_param(void_inst, "HostHeight", profile["host_height"])
        if ok1 and ok2:
            return True, "ok"
        errors = []
        if not ok1:
            errors.append("HostWidth: {}".format(msg1))
        if not ok2:
            errors.append("HostHeight: {}".format(msg2))
        return False, "; ".join(errors)

    return False, "onbekend void type"


def enforce_updated_void_rules(void_inst, host, mep_elem, settings):
    actions = []

    profile = get_mep_profile_dimensions(mep_elem)
    if not profile:
        return False, None, actions + ["kon MEP-profiel niet bepalen"]

    void_kind = get_void_family_kind(void_inst)
    clearance_ft = get_clearance_ft_for_mep(mep_elem, profile, settings)
    ok_clearance, msg_clearance = set_param(void_inst, "Clearance", clearance_ft)
    if ok_clearance:
        actions.append("Clearance uit instellingen toegepast ({})".format(fmt_mm(clearance_ft)))

    if get_category_name(host) != "Structural Framing":
        apply_profile_to_void_params(void_inst, profile)
        return True, profile, actions

    min_edge_clear_ft = mm_to_ft(MIN_EDGE_CLEAR_MM)
    ratio_tol_ft = mm_to_ft(RULE_TOL_MM)

    while True:
        doc.Regenerate()
        profile = get_mep_profile_dimensions(mep_elem)
        if not profile:
            return False, None, actions + ["kon MEP-profiel niet opnieuw bepalen"]

        # Eerst altijd de void synchroniseren met de actuele MEP-maat.
        ok_void, msg_void = apply_profile_to_void_params(void_inst, profile)
        if not ok_void:
            return False, profile, actions + [msg_void]
        doc.Regenerate()

        host_height_ft = get_host_vertical_height(host)
        if not host_height_ft or host_height_ft <= 0:
            return False, profile, actions + ["kon balkhoogte niet bepalen"]

        void_height_ft = get_void_vertical_size_ft(profile, clearance_ft) or 0.0
        max_allowed_void_ft = host_height_ft * MAX_VOID_HEIGHT_RATIO
        target_host_height_ft = 3.0 * void_height_ft

        if void_height_ft > max_allowed_void_ft + ratio_tol_ft:
            rule_mode = settings["rule_mode"]

            if rule_mode == "MEP":
                allowed_mep_ft = max_allowed_void_ft - 2.0 * clearance_ft
                if allowed_mep_ft <= mm_to_ft(1.0):
                    return False, profile, actions + ["onvoldoende ruimte om MEP + void tot 1/3-regel aan te passen"]
                old_mep_ft = get_mep_vertical_size_ft(profile) or 0.0
                ok, msg = set_mep_vertical_size(mep_elem, profile, allowed_mep_ft)
                if not ok:
                    return False, profile, actions + [msg]
                direction = "verkleind" if allowed_mep_ft < old_mep_ft else "vergroot"
                actions.append("Instelling toegepast: MEP + void {} tot 1/3-regel ({})".format(direction, fmt_mm(allowed_mep_ft)))
                continue

            if rule_mode == "BEAM":
                ok, msg = duplicate_and_resize_beam_type(host, target_host_height_ft)
                actions.append("Instelling toegepast: balk aanpassen | {}".format(msg))
                if not ok:
                    return False, profile, actions
                continue

            actions.append("Instelling: geen automatische actie bij voidhoogte > 1/3 balkhoogte")
            # Geen automatische actie, dus niet blijven loopen.
            break

        void_pt = get_location_point(void_inst)
        host_range = get_host_vertical_range(host)
        if not void_pt or not host_range:
            return False, profile, actions + ["kon positie van void of balk niet bepalen"]

        void_bottom = void_pt.Z - (void_height_ft / 2.0)
        void_top = void_pt.Z + (void_height_ft / 2.0)
        dist_bottom = void_bottom - host_range[0]
        dist_top = host_range[1] - void_top

        if dist_bottom + 1e-9 < min_edge_clear_ft or dist_top + 1e-9 < min_edge_clear_ft:
            edge_mode = settings["edge_mode"]

            if edge_mode == "MOVE":
                desired_center_z = void_pt.Z
                if dist_bottom < min_edge_clear_ft:
                    desired_center_z = max(desired_center_z, host_range[0] + min_edge_clear_ft + (void_height_ft / 2.0))
                if dist_top < min_edge_clear_ft:
                    desired_center_z = min(desired_center_z, host_range[1] - min_edge_clear_ft - (void_height_ft / 2.0))
                delta_z = desired_center_z - void_pt.Z

                ok, msg = move_element_vertical(mep_elem, delta_z)
                actions.append("Instelling toegepast: MEP + void verplaatsen | {}".format(msg))
                if not ok:
                    return False, profile, actions

                try:
                    DB.ElementTransformUtils.MoveElement(doc, void_inst.Id, DB.XYZ(0, 0, delta_z))
                except Exception:
                    pass
                doc.Regenerate()
                continue

            actions.append("Instelling: geen automatische actie bij randafstand < 50 mm")
            break

        break

    profile = get_mep_profile_dimensions(mep_elem)
    if profile:
        apply_profile_to_void_params(void_inst, profile)
        set_param(void_inst, "Clearance", clearance_ft)
    doc.Regenerate()
    return True, profile, actions

def update_void_from_linked_ids(void_inst, settings):
    void_kind = get_void_family_kind(void_inst)
    if not void_kind:
        return False, "Onbekend family type", None

    source_host_id = get_stored_id_value(void_inst, "SourceHostId")
    source_mep_id = get_stored_id_value(void_inst, "SourceMEPId")

    details = {
        "void_id": eid(void_inst),
        "host_id": source_host_id if source_host_id is not None else "-",
        "mep_id": source_mep_id if source_mep_id is not None else "-",
        "summary": "-",
        "changed": []
    }

    # Belangrijk:
    # Gebruik eerst altijd de opgeslagen host uit SourceHostId.
    # Als de void door een vorige update buiten de host is geraakt, mag resolve_host_from_void()
    # NIET bepalen welke host "dichtbij" is, want dan kan hij de verkeerde host kiezen.
    host, host_doc = get_element_by_stored_id(source_host_id)

    if host:
        details["host_id"] = eid(host)
        source_host_id = eid(host)
    else:
        # Alleen fallback als de opgeslagen host echt niet meer bestaat.
        real_host = resolve_host_from_void(void_inst)
        if real_host:
            host = real_host
            details["host_id"] = eid(real_host)
            source_host_id = eid(real_host)

    mep, profile, source_label = resolve_mep_element(void_inst, source_mep_id, host, void_kind)
    if not mep or not profile:
        deleted = delete_void_instance(void_inst)
        if deleted:
            return True, "Verwijderd: void snijdt geen geldige host/MEP meer", {
                "void_id": details["void_id"],
                "host_id": details["host_id"],
                "mep_id": details["mep_id"],
                "summary": "Void verwijderd",
                "changed": ["Deleted"]
            }
        return False, "Geen MEP gevonden en verwijderen mislukt", details

    details["mep_id"] = eid(mep)

    if void_kind == "round" and not profile["is_round"]:
        return False, "Void is round maar bron-MEP is niet round", details
    if void_kind == "rect" and profile["is_round"]:
        return False, "Void is rect maar bron-MEP is round", details

    if not host:
        deleted = delete_void_instance(void_inst)
        if deleted:
            return True, "Verwijderd: void snijdt geen host meer", {
                "void_id": details["void_id"],
                "host_id": "-",
                "mep_id": details["mep_id"],
                "summary": "Void verwijderd",
                "changed": ["Deleted"]
            }
        return False, "Geen host gevonden en verwijderen mislukt", details

    if not host_allowed_by_settings(host, settings):
        details["summary"] = "Host category niet actief in instellingen"
        details["changed"] = []
        return True, "Overgeslagen volgens instellingen", details

    current_depth = get_double_param_value(void_inst, "Depth", None)
    initial_center_for_depth = get_target_void_center_from_mep(host, mep, profile["axis"], get_location_point(void_inst)) or profile.get("center")
    depth_ft = get_host_depth_along_axis(host, profile["axis"], initial_center_for_depth, get_profile_radius_for_depth(profile))
    if not depth_ft or depth_ft <= 0:
        depth_ft = mm_to_ft(MIN_DEPTH_MM)

    changed = []
    write_errors = []

    settings_clearance_ft = get_clearance_ft_for_mep(mep, profile, settings)
    current_clearance = get_double_param_value(void_inst, "Clearance", None)
    if values_different(current_clearance, settings_clearance_ft):
        ok, msg = set_param(void_inst, "Clearance", settings_clearance_ft)
        if ok:
            changed.append("Clearance")
        else:
            write_errors.append("Clearance: {}".format(msg))


    if void_kind == "round":
        current_host_diameter = get_double_param_value(void_inst, "HostDiameter", None)
        new_host_diameter = profile["host_diameter"]
        if values_different(current_host_diameter, new_host_diameter):
            ok, msg = set_param(void_inst, "HostDiameter", new_host_diameter)
            if ok:
                changed.append("HostDiameter")
            else:
                write_errors.append("HostDiameter: {}".format(msg))
    else:
        current_host_width = get_double_param_value(void_inst, "HostWidth", None)
        current_host_height = get_double_param_value(void_inst, "HostHeight", None)
        new_host_width = profile["host_width"]
        new_host_height = profile["host_height"]

        if values_different(current_host_width, new_host_width):
            ok, msg = set_param(void_inst, "HostWidth", new_host_width)
            if ok:
                changed.append("HostWidth")
            else:
                write_errors.append("HostWidth: {}".format(msg))

        if values_different(current_host_height, new_host_height):
            ok, msg = set_param(void_inst, "HostHeight", new_host_height)
            if ok:
                changed.append("HostHeight")
            else:
                write_errors.append("HostHeight: {}".format(msg))

    if values_different(current_depth, depth_ft):
        ok, msg = set_param(void_inst, "Depth", depth_ft)
        if ok:
            changed.append("Depth")
        else:
            write_errors.append("Depth: {}".format(msg))

    moved, move_msg = move_void_center_to_mep_center(void_inst, host, mep, profile["axis"])
    if moved:
        changed.append("Location")
        doc.Regenerate()

    rotated, rot_msg = rotate_void_local_y_to_mep_axis(void_inst, profile["axis"])
    if rotated:
        changed.append("Angle")
        doc.Regenerate()

    ok_rules, profile_after_rules, rule_actions = enforce_updated_void_rules(void_inst, host, mep, settings)
    if not ok_rules:
        return False, " | ".join(rule_actions), details

    if profile_after_rules:
        profile = profile_after_rules

    moved_final, move_msg_final = move_void_center_to_mep_center(void_inst, host, mep, profile["axis"])
    if moved_final:
        changed.append("Location(final)")
        doc.Regenerate()

    rotated_final, rot_msg_final = rotate_void_local_y_to_mep_axis(void_inst, profile["axis"])
    if rotated_final:
        changed.append("Angle(final)")
        doc.Regenerate()

    # sync final values after potential rule-driven changes
    if void_kind == "round":
        final_host_diameter = profile["host_diameter"]
        if values_different(get_double_param_value(void_inst, "HostDiameter", None), final_host_diameter):
            ok, msg = set_param(void_inst, "HostDiameter", final_host_diameter)
            if ok:
                changed.append("HostDiameter(final)")
            else:
                write_errors.append("HostDiameter(final): {}".format(msg))
    else:
        final_host_width = profile["host_width"]
        final_host_height = profile["host_height"]

        if values_different(get_double_param_value(void_inst, "HostWidth", None), final_host_width):
            ok, msg = set_param(void_inst, "HostWidth", final_host_width)
            if ok:
                changed.append("HostWidth(final)")
            else:
                write_errors.append("HostWidth(final): {}".format(msg))

        if values_different(get_double_param_value(void_inst, "HostHeight", None), final_host_height):
            ok, msg = set_param(void_inst, "HostHeight", final_host_height)
            if ok:
                changed.append("HostHeight(final)")
            else:
                write_errors.append("HostHeight(final): {}".format(msg))

    final_center_for_depth = get_target_void_center_from_mep(host, mep, profile["axis"], get_location_point(host)) or get_location_point(void_inst) or profile.get("center")
    depth_ft = get_host_depth_along_axis(host, profile["axis"], final_center_for_depth, get_profile_radius_for_depth(profile))
    if not depth_ft or depth_ft <= 0:
        depth_ft = mm_to_ft(MIN_DEPTH_MM)

    if values_different(get_double_param_value(void_inst, "Depth", None), depth_ft):
        ok, msg = set_param(void_inst, "Depth", depth_ft)
        if ok:
            changed.append("Depth(final)")
        else:
            write_errors.append("Depth(final): {}".format(msg))

    set_param(void_inst, "SourceHostId", source_host_id)
    set_param(void_inst, "SourceMEPId", eid(mep))

    clearance_ft = get_double_param_value(void_inst, "Clearance", 0.0)

    if void_kind == "round":
        set_param(
            void_inst,
            "Comments",
            "Update | Bron={} | HostDiameter={} | Clearance={} | Depth={} | Centered={} | Rules={}".format(
                source_label,
                fmt_mm(profile["host_diameter"]),
                fmt_mm(clearance_ft),
                fmt_mm(depth_ft),
                "Yes" if moved else "No",
                " | ".join(rule_actions) if rule_actions else "None"
            )
        )
        details["summary"] = "HostDiameter -> {} | Depth -> {}".format(
            fmt_mm(profile["host_diameter"]),
            fmt_mm(depth_ft)
        )
    else:
        set_param(
            void_inst,
            "Comments",
            "Update | Bron={} | HostWidth={} | HostHeight={} | Clearance={} | Depth={} | Centered={} | Rules={}".format(
                source_label,
                fmt_mm(profile["host_width"]),
                fmt_mm(profile["host_height"]),
                fmt_mm(clearance_ft),
                fmt_mm(depth_ft),
                "Yes" if moved else "No",
                " | ".join(rule_actions) if rule_actions else "None"
            )
        )
        details["summary"] = "{} x {} | Depth {}".format(
            fmt_mm(profile["host_width"]),
            fmt_mm(profile["host_height"]),
            fmt_mm(depth_ft)
        )

    details["changed"] = changed + rule_actions
    doc.Regenerate()

    if write_errors:
        return False, "; ".join(write_errors), details

    if move_msg == "al gecentreerd":
        return True, "OK ({})".format(source_label), details
    return True, "OK ({}, {})".format(source_label, move_msg), details



def close_output_if_enabled(settings):
    try:
        enabled = bool(settings.get("auto_close_output", False))
    except Exception:
        enabled = False

    if not enabled:
        return

    # In pyRevit 5.x moet het outputvenster meestal met vertraging gesloten worden,
    # omdat de HTML-output pas op het einde volledig opgebouwd is.
    try:
        output.self_destruct(1)
        return
    except Exception:
        pass

    try:
        output.close()
        return
    except Exception:
        pass

    try:
        output.hide()
        return
    except Exception:
        pass

    try:
        output.window.Close()
        return
    except Exception:
        pass

    try:
        output._window.Close()
        return
    except Exception:
        pass

def main():
    output.print_md("# Update Voids")

    settings = get_prefab_settings()
    output.print_md("## Gekozen instellingen")
    output.print_md("- Host categories: **{}**".format(", ".join(settings["host_names"])))
    clearances = settings["clearances"]
    output.print_md("- Round duct clearance: **{} mm**".format(int(round(clearances["round_duct_mm"]))))
    output.print_md("- Rectangular duct clearance: **{} mm**".format(int(round(clearances["rectangular_duct_mm"]))))
    output.print_md("- Pipe clearance: **{} mm**".format(int(round(clearances["pipe_mm"]))))
    output.print_md("- Conduit clearance: **{} mm**".format(int(round(clearances["conduit_mm"]))))
    output.print_md("- Cable tray clearance: **{} mm**".format(int(round(clearances["cable_tray_mm"]))))
    output.print_md("- Other MEP clearance: **{} mm**".format(int(round(clearances["other_mep_mm"]))))
    output.print_md("- Regel bij voidhoogte > 1/3 balkhoogte: **{}**".format(rule_mode_to_text(settings["rule_mode"])))
    output.print_md("- Regel bij randafstand < 50 mm: **{}**".format(edge_mode_to_text(settings["edge_mode"])))

    voids = collect_void_instances()
    if not voids:
        output.print_md("Geen geplaatste voids gevonden.")
        return

    updated = 0
    unchanged = 0
    failed = 0
    deleted = 0
    rows = []

    with revit.Transaction("Update voids"):
        for void_inst in voids:
            try:
                success, info, details = update_void_from_linked_ids(void_inst, settings)

                if success:
                    changed_fields = details["changed"] if details else []
                    if "Deleted" in changed_fields:
                        deleted += 1
                        status = "Verwijderd"
                    elif changed_fields:
                        updated += 1
                        status = "Bijgewerkt"
                    else:
                        unchanged += 1
                        status = "Geen wijziging"

                    rows.append([
                        details["void_id"] if details else "-",
                        details["host_id"] if details else "-",
                        details["mep_id"] if details else "-",
                        details["summary"] if details else "-",
                        status,
                        info
                    ])
                else:
                    failed += 1
                    rows.append([
                        details["void_id"] if details else "-",
                        details["host_id"] if details else "-",
                        details["mep_id"] if details else "-",
                        details["summary"] if details else "-",
                        "Mislukt",
                        info
                    ])

            except Exception as ex:
                failed += 1
                logger.warning("Fout bij void {}: {}".format(eid(void_inst), ex))
                rows.append(["-", "-", "-", "-", "Fout", str(ex)])

    output.print_md("## Resultaat")
    output.print_md("- Totaal: **{}**".format(len(voids)))
    output.print_md("- Bijgewerkt: **{}**".format(updated))
    output.print_md("- Geen wijziging: **{}**".format(unchanged))
    output.print_md("- Verwijderd: **{}**".format(deleted))
    output.print_md("- Mislukt: **{}**".format(failed))

    if rows:
        output.print_md("## Overzicht")
        output.print_table(
            table_data=rows,
            columns=[
                "Void Id",
                "Host Id",
                "MEP Id",
                "Vergelijking",
                "Status",
                "Info"
            ]
        )

    output.print_md("## Klaar")
    close_output_if_enabled(settings)


if __name__ == "__main__":
    main()
